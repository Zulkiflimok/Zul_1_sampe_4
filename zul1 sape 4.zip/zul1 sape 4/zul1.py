#================================================
# ☬ TEAM TERMUX 01 ☬
# Support Bye: Zul Mokoagow
#================================================
from TEAM_TERMUX import *
from thrift.protocol import TCompactProtocol
from thrift.transport import THttpClient
from akad.ttypes import IdentityProvider, LoginResultType, LoginRequest, LoginType
from gtts import gTTS
from bs4 import BeautifulSoup
from bs4.element import Tag
import requests as uReq
from datetime import datetime
from googletrans import Translator
from zalgo_text import zalgo
import ast, codecs, json, os, pytz, re, LineService, random, sys, time, urllib.parse, subprocess, threading, pyqrcode, pafy, asyncio, humanize, os.path, traceback
from threading import Thread
from io import StringIO
from multiprocessing import Pool,Process
import subprocess as cmd
import platform
import requests, json
from urllib.parse import urlencode
from random import randint
from shutil import copyfile
from thrift import transport, protocol, server
from TEAM_TERMUX.thrift.Thrift import *
from TEAM_TERMUX.thrift.TMultiplexedProcessor import *
from TEAM_TERMUX.thrift.TSerialization import *
from TEAM_TERMUX.thrift.TRecursive import *
from TEAM_TERMUX.thrift.protocol import TCompactProtocol
from TEAM_TERMUX.thrift.transport import THttpClient
from Naked.toolshed.shell import execute_js 
from threading import Thread,Event
from shutil import copyfile
#import requests, uvloop
import wikipedia as wiki
from youtube_dl import YoutubeDL
import subprocess, youtube_dl, humanize, traceback
requests.packages.urllib3.disable_warnings()
import html5lib
import requests,json,urllib3
from datetime import timedelta, date
from datetime import datetime
#import time, random, sys, json, null, pafy, codecs, html5lib ,shutil ,threading, glob, re, base64, string, os, requests, six, ast, pytz, wikipedia, urllib, urllib.parse, atexit, asyncio, traceback
#from humanfriendly import format_timespan, format_size, format_number, format_length
#import pytz, pafy, livejson, time, asyncio, random, multiprocessing, timeit, sys, json, ctypes, tweepy, codecs, threading, glob, re, ast, six, os, subprocess, wikipedia, atexit, goslate, urllib, urllib.parse, urllib3, string, tempfile, shutil, unicodedata
_session = requests.session()
try:
    import urllib.request as urllib2
except ImportError:
    import urllib2

#loop = uvloop.new_event_loop()
#===============================================


cl = LINE("zullinux1@gmail.com","COTONTO01@") #isi imel line mu disini dan kata sandi

#===============================================
print("╔•══════════════════════\n╠•✡ LOGIN TEMPLATE SUKSES \n╚•══════════════════════")

oepoll = OEPoll(cl)
call = cl
creator = ["u9727b803de99902fcf8be21af2ccb59e"]
owner = ["u9727b803de99902fcf8be21af2ccb59e"]
aadmin = ["u9727b803de99902fcf8be21af2ccb59e"]
staff = ["u9727b803de99902fcf8be21af2ccb59e"]
lineProfile = cl.getProfile()
mid = cl.getProfile().mid
KAC = [cl]
Bots = [mid]
Saints = aadmin + owner + staff
admin = creator + owner + aadmin + staff + Bots
Setbot = codecs.open("setting.json","r","utf-8")
Setmain = json.load(Setbot)
#==================================
welcome = []
protectqr = []
protectkick = []
protectjoin = []
protectinvite = []
protectcancel = []
targets = []
protectname = []
prohibitedWords = ['Asu', 'Jancuk', 'Tai', 'Kickall', 'Ratakan', 'Cleanse']
userTemp = {}
userKicked = []
msg_dict = {}
msg_dict1 = {}
dt_to_str = {}
temp_flood = {}
groupName = {}
groupImage = {}
list = []
ban_list = []
offbot = []

settings = {
    "welcome": False,
    "leave": False,
    "mid": False,
    "Aip": True,
    "replySticker": False,
    "stickerOn": False,
    "checkContact": False,
    "postEndUrl": {},
    "postingan":{},
    "checkPost": False,
    "autoRead": False,
    "autoJoinTicket": False,
    "setKey": False,
    "restartPoint": False,
    "checkSticker": False,
    "userMentioned": False,
    "messageSticker": False,
    "changeGroupPicture": [],
    "keyCommand": "",
    "AddstickerTag": {
        "sid": "",
        "spkg": "",
        "status": False
            },
    "Addsticker":{
            "name": "",
            "status":False
            },
    "stk":{},
    "selfbot":True,
    "Images":{},
    "Img":{},
    "Addimage":{
            "name": "",
            "status":False
            },
    "Videos":{},
    "Addaudio":{
            "name": "",
            "status":False
            },
    "Addvideo":{
            "name": "",
            "status":False
            },
    "myProfile": {
        "displayName": "",
        "coverId": "",
        "pictureStatus": "",
        "statusMessage": ""
    },
    "mimic": {
        "copy": False,
        "status": False,
        "target": {}
    }, 
    "unsendMessage": False,
    "Picture":False,
    "group":{},
    "groupPicture":False,
    "changevp": False,
    "changeCover":False,
    "changePicture":False,
    "changeProfileVideo": False,
    "ChangeVideoProfilevid":{},
    "ChangeVideoProfilePicture":{},
    "displayName": "",
    "userAgent": [
        "Mozilla/5.0 (Linux; Android 5.1.1; ASUS_X014D Build/LMY47V; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/79.0.3945.93 Mobile Safari/537.36 Line/9.22.2"
        "Mozilla/5.0 (X11; U; Linux i586; de; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; U; Linux amd64; rv:5.0) Gecko/20100101 Firefox/5.0 (Debian)",
        "Mozilla/5.0 (X11; U; Linux amd64; en-US; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 FirePHP/0.5",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux ppc; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux AMD64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; FreeBSD amd64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; rv:6.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1.1; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; U; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; rv:2.0.1) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; rv:5.0) Gecko/20100101 Firefox/5.0"
    ]
}

wait = {
    "limit": 1,
    "owner":{},
    "admin":{},
    "delFriend":False,
    "addadmin":False,
    "delladmin":False,
    "checkmid": False,
    "getMid": False,
    "invite":False,
    "Invi":False,
    "staff":{},
    "Timeline": False,
    "likePost": False,
    "likeOn": True,
    "addstaff":False,
    "dellstaff":False,
    "bots":{},
    "readPoint":{},
    "readMember":{},
    "lang":False,
    "addbots":False,
    "dellbots":False,
    "blacklist":{},
    "wblacklist":False,
    "dblacklist":False,
    "Talkblacklist":{},
    "Talkwblacklist":False,
    "Talkdblacklist":False,
    "talkban":True,
    "tumbal":True,
    "backup":True,
    "contact":False,
    "autoRead": False,
    "autoBlock": True,
    "autoJoin":False,
    "autoAdd":True,
    'autoCancel':{"on":True, "members":1},
    "autoReject":False,
    "autoLeave": False,
    "autoLeave1": False,    
    "detectMention":False,
    "detectMention2":False,
    "detectMention3":False,
    "detectMention4":False,
    "detectMention5":False,
    "arespon":False,
    "Mentionkick":False,
    "welcomeOn":True,
    "welcome": True,
    "responGc":True,
    "responGc1":True,
    "responGc2": True,
    "responGc3":True,
    "responGc4":True,
    "responGc5":True,
    "Unsend":False,
    "youtube":False,
    "sticker":False,
    "ytube":False,
    "selfbot":True,
    "smule":False,
    "tagall": "all",
    "AddstickerTag":False,
    "dagor": "bantai",
    "mention":"ɪɴɪ ᴅɪᴀ ᴛᴜᴋᴀɴɢ ɴʏɪᴍᴀᴋ ɴɪʜ ᴊᴏɴᴇꜱ",
    "Respontag":"ᴀꜱᴇᴍ ᴅɪ ᴛᴀɢ ᴀᴡᴀꜱ ɴʏᴀᴍᴀɴ ʟᴏʜ",
    "Respontag2":"Maklum Jones Tag Lagi Kesepian 😅😅",
    "Respontag3":"ᴀᴡᴀꜱ ᴛᴜᴋᴀɴɢ ᴛᴀɢ ɴɪʜ ɴʏᴀʀɪ ᴋᴏᴊᴏᴍᴀɴ ᴅɪᴀ",
    "Respontag4":"ᴀᴘᴀɴ ᴛᴀɢ ɢᴜᴇ ᴍᴀᴜ ʙᴀʏᴀʀ ʜᴜᴛᴀɴɢ",
    "Respontag5":"ᴀᴡᴀꜱ ᴀᴅᴀ ᴊᴏɴᴇꜱ ᴅɪᴀ ᴛᴀɢ ᴀᴋᴜ",
    "welcome":"Selamat Datang Di Room Kami Semoga Betah Yah Tikungan Cari Sendiri 🤗🤗",
    "autoLeave":"Nah Kan Beper Hayoo Siapa Yang Baperin Anak Orang Tuh 🤣🤣",
    "comment":"──────┅❇͜͡❇͜͡☆͜͡❇͜͡❇┅──────\nᴼᴾᴱᴺ ᴼᴿᴰᴱᴿ\n────────┅┅───────\n➣ꜱᴇʟꜰʙᴏᴛ ᴏɴʟʏ\n➣ꜱᴇʟꜰʙᴏᴛ + ᴀꜱɪꜱᴛ\n➣1 ᴀᴋᴜɴ ᴜᴛᴀᴍᴀ\n➣1 ᴀᴋᴜɴ ᴜᴛᴀᴍᴀ + 2 ᴀꜱɪꜱᴛ\n➣1 ᴀᴋᴜɴ ᴜᴛᴀᴍᴀ + 3 ᴀꜱɪꜱᴛ\n➣1 ᴀᴋᴜɴ ᴜᴛᴀᴍᴀ + 4 ᴀꜱɪꜱᴛ\n➣1 ᴀᴋᴜɴ ᴜᴛᴀᴍᴀ + 5 ᴀꜱɪꜱᴛ\n➣ʙᴏᴛᴘʀᴏᴛᴇᴄᴛ 3-11 ʙᴏᴛ ᴀꜱɪꜱᴛ\n➣ɴᴇᴡ ꜱᴄʀɪᴘᴛ\n➣ʜʀɢᴀ ʙɪꜱᴀ ɴᴇɢᴏ\n─────────┅┅─────────\n  ✯❇͜͡❇͜͡C͜͡r͜͡e͜͡a͜͡t͜͡o͜͡r✯͜͡$͜͡ë͜͡I͜͡F͜͡-͜͡฿͜͜͡͡o͜͡t͜͡ ͜͡❇͜͡❇✯\nline.me/ti/p/~linux.1\nline.me/ti/p/~linux.1\n➣ѕєʟғвот κɪcκєʀ_+_ᴘʀᴏᴛᴇᴄᴛ\n────────┅❇͜͡❇͜͡☆͜͡❇͜͡❇┅────────",
    "message1":"Terimɑ Kɑsih yɑ....\nUdɑh Menɑmbɑhkɑn Sɑyɑ Sebɑgɑi Temɑn ɑndɑ.\nSemogɑ Kitɑ Bisɑ Jɑlin Silɑturɑhmi Dengɑn Bɑik.\n\nвστ вy: TEAM TERMUX 01",
}
protect = {
    "pqr":[],
    "pinv":[],
    "proall":[],
    "antijs":[],
    "protect":[]
}

read = {
    "readPoint":{},
    "readMember":{},
    "readTime":{},
    "ROM":{},
}

cctv = {
    "cyduk":{},
    "point":{},
    "sidermem":{}
}

myProfile = {
	"displayName": "",
	"statusMessage": "",
	"pictureStatus": ""
}
try:
    with open("Log_data.json","r",encoding="utf_8_sig") as f:
        msg_dict = json.loads(f.read())
except:
    print("Couldn't read Log data")
    
clProfile = cl.getProfile()
myProfile["displayName"] = clProfile.displayName
myProfile["statusMessage"] = clProfile.statusMessage
myProfile["pictureStatus"] = clProfile.pictureStatus

contact = cl.getProfile()
backup = cl.getProfile()
backup.displayName = contact.displayName
backup.statusMessage = contact.statusMessage
backup.pictureStatus = contact.pictureStatus


imagesOpen = codecs.open("image.json","r","utf-8")
images = json.load(imagesOpen)
videosOpen = codecs.open("video.json","r","utf-8")
videos = json.load(videosOpen)
stickersOpen = codecs.open("sticker.json","r","utf-8")
stickers = json.load(stickersOpen)
audiosOpen = codecs.open("audio.json","r","utf-8")
audios = json.load(audiosOpen)
mulai = time.time()

msg_dict = {}
msg_dict1 = {}

tz = pytz.timezone("Asia/Jakarta")
timeNow = datetime.now(tz=tz)
           
def cTime_to_datetime(unixtime):
    return datetime.fromtimestamp(int(str(unixtime)[:len(str(unixtime))-3]))

def autolike():
    for zx in range(0,500):
      hasil = cl.activity(limit=500)
      if hasil['result']['posts'][zx]['postInfo']['liked'] == True:
        try:
          cl.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1001)
          cl.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postid'],wait["comment"])
          print ("✪[]► Like Success")
        except:
          pass
      else:
          print ("Already Liked")
    
def dt_to_str(dt):
    return dt.strftime('%H:%M:%S')

#delete log if pass more than 24 hours
def delete_log():
    ndt = datetime.now()
    for data in msg_dict:
        if (datetime.utcnow() - cTime_to_datetime(msg_dict[data]["createdTime"])) > datetime.timedelta(1):
            del msg_dict[msg_id]
        
def delete_log():
    ndt = datetime.now()
    for data in msg_dict:
        if (datetime.utcnow() - cTime_to_datetime(msg_dict[data]["createdTime"])) > timedelta(1):
            if "path" in msg_dict[data]:
                cl.deleteFile(msg_dict[data]["path"])
            del msg_dict[data]

def sendMentionV2(to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = "@zulkifli "
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)

def NoteCreate(to,cmd,msg):
	h = []
	s = []
	if cmd == 'tagnote':
		sakui = cl.getProfile()
		group = cl.getGroup(msg.to);nama = [contact.mid+'||//{}'.format(contact.displayName) for contact in group.members];nama.remove(sakui.mid+'||//{}'.format(sakui.displayName))
		data = nama
		k = len(data)//20
		for aa in range(k+1):
			nos = 0
			if aa == 0:dd = '╭─[ Mention Note ]';no=aa
			else:dd = '';no=aa*20
			msgas = dd
			for i in data[aa*20 : (aa+1)*20]:
				no+=1
				if no == len(data):msgas+='\n│{}. @  \n╰─[ Mention Note ]'.format(no)
				else:msgas+='\n│{}. @'.format(no)
			msgas = msgas
			for i in data[aa*20 : (aa+1)*20]:
				gg = []
				dd = ''
				for ss in msgas:
					if ss == '@':
						dd += str(ss)
						gg.append(dd.index('@'))
						dd = dd.replace('@',' ')
					else:
						dd += str(ss)
				s.append({'type': "RECALL", 'start': gg[nos], 'end': gg[nos]+1, 'mid': str(i.split('||//')[0])})
				nos +=1
			h = cl.createPostGroup(msgas,msg.to,holdingTime=None,textMeta=s)

def logError(text):
    cl.log("[ ERROR ] {}".format(str(text)))
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow,"(%H:%M)")
    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
    inihari = datetime.now(tz=tz)
    hr = inihari.strftime('%A')
    bln = inihari.strftime('%m')
    for i in range(len(day)):
        if hr == day[i]: hasil = hari[i]
    for k in range(0, len(bulan)):
        if bln == str(k): bln = bulan[k-1]
    time = "{}, {} - {} - {} | {}".format(str(hasil), str(inihari.strftime('%d')), str(bln), str(inihari.strftime('%Y')), str(inihari.strftime('%H:%M:%S')))
    with open("logError.txt","a") as error:
        error.write("\n[ {} ] {}".format(str(time), text))

def download_page(url):
    version = (3,0)
    cur_version = sys.version_info
    if cur_version >= version:     
        import urllib,request
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
            req = urllib,request.Request(url, headers = headers)
            resp = urllib,request.urlopen(req)
            respData = str(resp.read())
            return respData
        except Exception as e:
            print(str(e))
    else:                        
        import urllib2
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.27 Safari/537.17"
            req = urllib2.Request(url, headers = headers)
            response = urllib2.urlopen(req)
            page = response.read()
            return page
        except:
            return"Page Not found"

def _images_get_all_items(page):
    items = []
    while True:
        item, end_content = _images_get_next_item(page)
        if item == "no_links":
            break
        else:
            items.append(item)      
            time.sleep(0.1)        
            page = page[end_content:]
    return items

def downloadImageWithURL (mid):
    contact = cl.getContact(mid)
    if contact.videoProfile == None:
        cl.cloneContactProfile(mid)
    else:
        profile = cl.getProfile()
        profile.displayName, profile.statusMessage = contact.displayName, contact.statusMessage
        cl.updateProfile(profile)
        pict = cl.downloadFileURL('http://dl.profile.line-cdn.net/' + contact.pictureStatus, saveAs="tmp/pict.bin")
        vids = cl.downloadFileURL( 'http://dl.profile.line-cdn.net/' + contact.pictureStatus + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = cl.getProfileDetail(mid)['result']['objectId']
    cl.updateProfileCoverById(coverId)
    
def restartBot():
    python = sys.executable
    os.execl(python, python, *sys.argv)

def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)

def runtime(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)
    
def sendImage(to, path, name="image"):
    try:
        if settings["server"] == "VPS":
            cl.sendImageWithURL(to, str(path))
    except Exception as error:
        logError(error)

def changeProfileVideo(to):
    if settings['changevp']['picture'] == True:
        return cl.sendMessage(to, "Foto tidak ditemukan")
    elif settings['changevp']['video'] == True:
        return cl.sendMessage(to, "Video tidak ditemukan")
    else:
        path = settings['changevp']['video']
        files = {'file': open(path, 'rb')}
        obs_params = cl.genOBSParams({'oid': cl.getProfile().mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = cl.server.postContent('{}/talk/vp/upload.nhn'.format(str(cl.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return cl.sendMessage(to, "Gagal update profile")
        path_p = settings['changevp']['picture']
        settings['changevp']['status'] = True
        cl.updateProfilePicture(path_p, 'vp')
                     
def changeVideoAndPictureProfile(pict, vids):
    try:
        files = {'file': open(vids, 'rb')}
        obs_params = cl.genOBSParams({'oid': mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4', 'name': 'GEGE.mp4'})
        data = {'params': obs_params}
        r_vp = cl.server.postContent('{}/talk/vp/upload.nhn'.format(str(cl.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return "Failed update profile"
        cl.updateProfilePicture(pict, 'vp')
        return "Success update profile"
    except Exception as e:
        raise Exception("Error change video and picture profile %s"%str(e))

def cloneProfile(mid):
    contact = cl.getContact(mid)
    if contact.videoProfile == None:
        cl.cloneContactProfile(mid)
    else:
        profile = cl.getProfile()
        profile.displayName, profile.statusMessage = contact.displayName, contact.statusMessage
        cl.updateProfile(profile)
        pict = cl.downloadFileURL('http://dl.profile.line-cdn.net/' + contact.pictureStatus, saveAs="tmp/pict.bin")
        vids = cl.downloadFileURL( 'http://dl.profile.line-cdn.net/' + contact.pictureStatus + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = cl.getProfileDetail(mid)['result']['objectId']
    cl.updateProfileCoverById(coverId)

def restoreProfile():
    profile = cl.getProfile()
    profile.displayName = settings['myProfile']['displayName']
    profile.statusMessage = settings['myProfile']['statusMessage']
    if settings['myProfile']['videoProfile'] == None:
        profile.pictureStatus = settings['myProfile']['pictureStatus']
        cl.updateProfileAttribute(8, profile.pictureStatus)
        cl.updateProfile(profile)
    else:
        cl.updateProfile(profile)
        pict = cl.downloadFileURL('http://dl.profile.line-cdn.net/' + settings['myProfile']['pictureStatus'], saveAs="tmp/pict.bin")
        vids = cl.downloadFileURL( 'http://dl.profile.line-cdn.net/' + settings['myProfile']['pictureStatus'] + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = settings['myProfile']['coverId']
    cl.updateProfileCoverById(coverId)

def mentionMembers(to, mid):
    try:
        arrData = ""
        ginfo = cl.getGroup(to)
        textx = "╔═════[ Pika Members ]═══════\n╠➣   Sini Gabung Chat ka 😊..\n╠☛ 1. "
        arr = []
        no = 1
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            if no < len(mid):
                no += 1
                textx += "╠☛  {}. ".format(str(no))
            else:
                textx += "╚══════════════════\n╔══════════════════\n  「 ᴛᴏᴛᴀʟ ᴍᴇᴍʙᴇʀ : {} 」\n╚══════════════════".format(str(len(mid)))
        cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def siderMembers(to, mid):
    try:
        arrData = ""
        textx = (str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            if no < len(mid):
                no += 1
                textx += "%i. " % (num)
                num=(num)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(cl.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
#===== [ ꜱᴜᴘᴘᴏʀᴛ ʙʏᴇ ᴛᴇᴀᴍ TEAM TERMUX 01
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))
       

def welcomeMembers(to, mid):
    try:
        arrData = ""
        textx = " ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = cl.getGroup(to)
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            if no < len(mid):
                no += 1
                textx += "%i " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(cl.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
       # cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def leaveMembers(to, mid):
    try:
        arrData = ""
        textx = "".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = cl.getGroup(to)
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            if no < len(mid):
                no += 1
                textx += "%i " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n┗━━[ {} ]".format(str(aditmadzs.getGroup(to).name))
                except:
                    no = "\n┗━━[ Success ]"
    #    cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def sendMention(to, mid, firstmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x \n"
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        today = datetime.today()
        future = datetime(2018,3,1)
        hari = (str(future - today))
        comma = hari.find(",")
        hari = hari[:comma]
        teman = cl.getAllContactIds()
        gid = cl.getGroupIdsJoined()
        tz = pytz.timezone("Asia/Jakarta")
        timeNow = datetime.now(tz=tz)
        eltime = time.time() - mulai
        bot = runtime(eltime)
        text += mention+"jam : "+datetime.strftime(timeNow,'%H:%M:%S')+" wib\nNama Group : "+str(len(gid))+"\nTeman : "+str(len(teman))+"\nExpired : In "+hari+"\n Version :「Gaje Bots」  \nTanggal : "+datetime.strftime(timeNow,'%Y-%m-%d')+"\nRuntime : \n • "+bot
        cl.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def sendMention1(to, mid, firstmessage, lastmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        cl.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)                     
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def sendTemplates(to, data):
    data = data
    url = "https://api.line.me/message/v3/share"
    headers = {}
    headers['User-Agent'] = 'Mozilla/5.0 (Linux; Android 8.1.0; Redmi Note 5 Build/OPM1.171019.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/67.0.3396.87 Mobile Safari/537.36 Line/8.1.1'  
    headers['Content-Type'] = 'application/json'  
    headers['Authorization'] = 'Bearer eyJhbGciOiJIUzI1NiJ9.5uMcEEHahauPb5_MKAArvGzEP8dFOeVQeaMEUSjtlvMV9uuGpj827IGArKqVJhiGJy4vs8lkkseiNd-3lqST14THW-SlwGkIRZOrruV4genyXbiEEqZHfoztZbi5kTp9NFf2cxSxPt8YBUW1udeqKu2uRCApqJKzQFfYu3cveyk.GoRKUnfzfj7P2uAX9vYQf9WzVZi8MFcmJk8uFrLtTqU'
    sendPost = requests.post(url, data=json.dumps(data), headers=headers)
    print(sendPost)
    return sendPost


def removeCmd(cmd, text):
	key = settings["keyCommand"]
	if settings["setKey"] == False: key = ''
	rmv = len(key + cmd) + 1
	return text[rmv:]  
	
def sendFlex(to, data):
  token = self.issueLiffView(to)
  url = 'https://api.line.me/message/v3/share'
  headers = {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer %s' % token.accessToken
  }
  data = {
    'messages': [data]
  }
  res = requests.post(url, headers=headers, data=json.dumps(data))
  return res
#===============================================================================================
def sendTextTemplate25(to, text):
    data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX 01 V 1",
                                       "contents": 
{
"type": "bubble",
"size": "micro",
"body": {
"backgroundColor": "#000000",
"type": "box",
"layout": "vertical",
"contents": [
      {
        "contents": [                   
            {            
            "type": "separator",
            "color": "#ffffff"            
      },
      {
        "type": "separator",
        "color": "#ffffff"  
      },
      {         
         "contents": [
          {
          "type": "separator",
          "color": "#ffffff"   
      },
      {
            "contents": [
              {
              "type": "image",
     "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
          },{
 "type": "text",
"text": "TEAM TERMUX 01",
"weight": "bold",
"color": "#ccff00",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": " ȶɛǟʍ",
"weight": "bold",
"color": "#ccff00",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "ɮօȶֆ",
"weight": "bold",
"color": "#ccff00",
"size": "xxs",
"flex": 0
      },
      {
    "type": "image",
     "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#ffffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#ffffff"
         },
         {
       "contents": [
          {
           "type": "separator",
           "color": "#ffffff"
          },
          {
          "type": "image",
          "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
"size": "xxs",
      "aspectMode": "cover",
           "action": {
            "type": "uri",
            "uri": "http://line.me/ti/p/~linux.1",
            },
            "flex": 0
          },
          {
        "type": "separator",
        "color": "#ffffff"
      },
      {      
       "contents": [              
          {
"type": "text",
"text": "➥  {}".format(cl.getContact(mid).displayName),
"weight": "bold",
"color": "#33ffff",
#"align": "center",
"size": "xxs",
"flex": 0
},{
"type": "separator",
"color": "#ffffff"
},{
"type": "text",
"text": "📆 "+ datetime.strftime(timeNow,'%Y-%m-%d'),
"weight": "bold",
"color": "#ffffff",
#"align": "center",
"size": "xxs",
"flex": 0
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"
      },
      {
        "type": "separator",
        "color": "#ffffff"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"
      },
      {
        "type": "separator",
         "color": "#ffffff"
       },
       {     
       "contents": [           
         { 
           "type": "separator",
           "color": "#ffffff"
            },
           {
            "contents": [
              {
          "text": text,
           "size": "xxs",
          # "align": "center",
           "color": "#ccffff",
           "wrap": True,
           "weight": "bold",
           "type": "text"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#ffffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#ffffff"
         },
         {          
        "contents": [
          {
            "type": "separator",
            "color": "#ffffff"
            },
             {
            "type": "image",
            "url": "https://i.ibb.co/XWQd8rj/20190625-201419.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "https://youtube.com"
            },
            "flex": 1
          },
          {
          "type": "image",
            "url": "https://i.ibb.co/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "http://line.me/ti/p/~linux.1",             
           }, 
            "flex": 1            
          },
          {
        "type": "image",
            "url": "https://i.ibb.co/kSMSnWn/20190427-191235.png", #camerahttps://i.ibb.co/hVWDsp8/20190428-232907.png", #smulehttps://i.ibb.co/8YfQVtr/20190427-185626.png", #callinghttps://kepriprov.go.id/assets/img/icon/phone.png", #phone
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "http://line.me/ti/p/~linux.1"
          },
            "flex": 1
            },
          {
          "type": "image",
            "url": "https://i.ibb.co/CntKh4x/20190525-152240.png", #smule
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "Https://smule.com/KSS_OFFICE",
            },         
            "flex": 1          
          },
          {
          "type": "image",
            "url": "https://i.ibb.co/Wf8bQ2Z/20190625-105354.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "http://line.me/ti/p/~linux.1"
            },
            "flex": 1
            },
            {
            "contents": [
            {
            "type": "image",
            "url": "https://i.ibb.co/1sGhJdC/20190428-232658.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "http://line.me/ti/p/~linux.1"
            },
            "flex": 1
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#ffffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#ffffff"
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "xs",
    "layout": "vertical"
  }
}
}
    cl.postTemplate(to, data)
#=================================================================
def sendTextTemplate(to, text):
    data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX 01",
                                       "contents": 
{
"type": "bubble",
"size": "micro",
"body": {
"backgroundColor": "#000000",
"type": "box",
"layout": "vertical",
    "contents": [
      {
        "contents": [
          {
            "contents": [
             {
            "type": "separator",
            "color": "#ffffff"            
            },
            {
            "contents": [
            {
            "type": "separator",
            "color": "#ffffff" 
   },
   {
            "text": text,
           "size": "xxs",
           "color": "#FFFFFF",
           "wrap": True,
           "weight": "bold",
           "type": "text"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#ffffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#ffffff"
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "xs",
    "layout": "vertical"
  }
}
}
    cl.postTemplate(to, data)
                                       	
def sendFooter(to, isi):
    data = {
        "type": "text",
        "text": isi,
        "sentBy": {
            "label": "TEAM TERMUX 01",
            "iconUrl": "https://ae01.alicdn.com/kf/HTB1ZM7kQpXXXXXcXFXXq6xXFXXXg/Sebuah-gelombang-adalah-cahaya-logam-bercahaya-memancing-dansa-berputar-gulungan-laut-memancing-tiang-memancing-roda-roda.jpg",
            "linkUrl": "line://nv/profilePopup/mid=u6459106c8251205f79c2f037cd99b6a4"
        }
    }
    cl.postTemplate(to, data)
    
def sendFooter1(to, isi):
    data = {
        "type": "text",
        "text": isi,
        "sentBy": {
            "label": "TEAM TERMUX 01",
            "iconUrl": "https://ae01.alicdn.com/kf/HTB1ZM7kQpXXXXXcXFXXq6xXFXXXg/Sebuah-gelombang-adalah-cahaya-logam-bercahaya-memancing-dansa-berputar-gulungan-laut-memancing-tiang-memancing-roda-roda.jpg",
            "linkUrl": "line://nv/profilePopup/mid=u6459106c8251205f79c2f037cd99b6a4"
        }
    }
    cl.postTemplate(to, data)
    
def sendFooter2(to, isi):
    data = {
        "type": "text",
        "text": isi,
        "sentBy": {
            "label": "TEAM TERMUX 01",
            "iconUrl": "https://ae01.alicdn.com/kf/HTB1ZM7kQpXXXXXcXFXXq6xXFXXXg/Sebuah-gelombang-adalah-cahaya-logam-bercahaya-memancing-dansa-berputar-gulungan-laut-memancing-tiang-memancing-roda-roda.jpg",
            "linkUrl": "line://nv/profilePopup/mid=u6459106c8251205f79c2f037cd99b6a4"
        }
    }
    cl.postTemplate(to, data)

def desy_Zul(to, text):
    data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX 01",
                                       "contents": 
{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co/mN608mX/IMG-20201021-001642.jpg",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "18:6",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "IMAGE",
                "color": "#ffffff",
                "align": "center",
                "size": "xs",
                "offsetTop": "3px"
              },
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
                "position": "absolute",
                "size": "full",
                "aspectRatio": "1:1",
                "aspectMode": "cover",
                "action": {
                  "type": "uri",
                  "uri": "http://line.me/ti/p/~linux.1"
                }
              }
            ],
            "position": "absolute",
            "offsetTop": "4px",
            "backgroundColor": "#880000",
            "offsetStart": "3px",
            "height": "44px",
            "width": "47px",
            "borderWidth": "1px",
            "borderColor": "#FFFFFF"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "3px",
        "borderColor": "#FFCC00",
        "cornerRadius": "7px"
      }
    },
  {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co/mN608mX/IMG-20201021-001642.jpg",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "18:6",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "IMAGE",
                "color": "#ffffff",
                "align": "center",
                "size": "xs",
                "offsetTop": "3px"
              },
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
                "position": "absolute",
                "size": "full",
                "aspectRatio": "1:1",
                "aspectMode": "cover",
                "action": {
                  "type": "uri",
                  "uri": "http://line.me/ti/p/~linux.1"
                }
              }
            ],
            "position": "absolute",
            "offsetTop": "4px",
            "backgroundColor": "#880000",
            "offsetStart": "3px",
            "height": "44px",
            "width": "47px",
            "borderWidth": "1px",
            "borderColor": "#FFFFFF"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "3px",
        "borderColor": "#FFCC00",
        "cornerRadius": "7px"
      }
    }
  ]
}
}
    cl.postTemplate(to, data)


def sendTextTemplate1(to, text):
    data = {
                                        "type": "flex",
                                        "altText": "TEAM TERMUX 01",
                                        "contents": {
   "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:1",
            "gravity": "top",
            "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRUtI84fguMvVGtCkOr6RAAhGoZFMdqsF3gGA&usqp=CAU"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#00FF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "152px",
            "height": "59px",
            "position": "absolute",
            "offsetStart": "2px",
            "offsetTop": "1px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#FF00FF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "149px",
            "height": "56px",
            "position": "absolute",
            "offsetStart": "3px",
            "offsetTop": "3px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "borderColor": "#FF0000",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "147px",
            "height": "52px",
            "offsetStart": "4px",
            "offsetTop": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://img.utdstc.com/icons/facebook-android.png:l",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "15px",
            "height": "15px",
            "offsetTop": "62px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRZOxjwweYgJHVE6vbzy4UOlZI4drUsz0X_7g&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "width": "15px",
            "height": "15px",
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "position": "absolute",
            "offsetTop": "62px",
            "offsetStart": "20px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRKjMVwBTwaFSNZy2iDRQW16k0xwe3o8ZIPbw&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "width": "15px",
            "height": "15px",
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "offsetTop": "62px",
            "offsetStart": "40px",
            "position": "absolute"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRzGMMdc0ZJzMfcrJ8aN9-pYSQkM2A8V62ZhQ&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "width": "15px",
            "height": "15px",
            "position": "absolute",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "borderColor": "#FFFF00",
            "offsetTop": "62px",
            "offsetStart": "60px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT7UtT979IgGBfO7G8-lJ1CjmrMF2bdKeFJSw&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "width": "15px",
            "height": "15px",
            "position": "absolute",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "borderColor": "#FFFF00",
            "offsetTop": "62px",
            "offsetStart": "80px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSx4LVGh5U_v0-KbAIlKUA9z13IQtDe4QCY5A&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "height": "15px",
            "width": "15px",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "borderColor": "#FFFF00",
            "position": "absolute",
            "offsetTop": "62px",
            "offsetStart": "100px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "size": "full",
                "aspectMode": "cover",
                "url": "https://www.blackxperience.com/assets/blackattitude/blacktips//cover-wa-300x300.jpg"
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "15px",
            "height": "15px",
            "offsetTop": "62px",
            "offsetStart": "120px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ0GNdbUT-boPK9eL8F4RZv9xVUxqBFlZHgGA&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "width": "15px",
            "height": "15px",
            "position": "absolute",
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "offsetTop": "62px",
            "offsetStart": "138px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": []
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEAM TERMUX 01 V 1",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "15px"
              }
            ],
            "position": "absolute",
            "width": "143px",
            "height": "20px",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "borderColor": "#00FF00",
            "offsetTop": "6px",
            "offsetStart": "6px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": text,
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "7px",
                "offsetStart": "10px"
              }
            ],
            "borderColor": "#00FFFF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "145px",
            "height": "29px",
            "position": "absolute",
            "offsetTop": "27px",
            "offsetStart": "4px",
            "backgroundColor": "#4B0082"
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#00FF00",
        "borderWidth": "2px",
        "cornerRadius": "10px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~linux.1"
        }
      }
    }
  ]
}
}
    cl.postTemplate(to, data)
    
def sendTextTemplate2(to, text):
    data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX 01",
                                       "contents": 
{
"type": "bubble",
"size": "nano",
"body": {
"backgroundColor": "#000000",
"type": "box",
"layout": "vertical",
"contents": [
{
"contents": [
{
"type": "separator",
"color": "#000000"
},{
"type": "separator",
"color": "#000000"
},{
"contents": [
{
"type": "separator",
"color": "#80FF00"
},{
"contents": [
{
"text": "TEAM TERMUX 01 V 1",
"size": "xxs",
"align": "center",
"color": "#FFFFFF",
"wrap": True,
"weight": "bold",
"type": "text"
}],
"type": "box",
"spacing": "xs",
"layout": "vertical"
},{
"type": "separator",
"color": "#000000"
}],
"type": "box",
"layout": "horizontal"
},{
"type": "separator",
"color": "#000000"
},{
"contents": [
{
"type": "separator",
"color": "#000000"
},{
"contents": [
{
"text": text,
"size": "xxs",
#"align": "center",
"color": "#FFFFFF",
"wrap": True,
"weight": "bold",
"type": "text"
}],
"type": "box",
"spacing": "xs",
"layout": "vertical"
},{
"type": "separator",
"color": "#000000"
}],
"type": "box",
"layout": "horizontal"
},{
"type": "separator",
"color": "#000000"
},{
"contents": [
          {
            "type": "separator",
            "color": "#80FF00"
            },
             {
            "type": "image",
            "url": "https://i.ibb.co/XWQd8rj/20190625-201419.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "https://youtube.com"
            },
            "flex": 1
          },
          {
          "type": "image",
            "url": "https://i.ibb.co/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "http://line.me/ti/p/~linux.1",             
           }, 
            "flex": 1            
          },
          {
        "type": "image",
            "url": "https://i.ibb.co/kSMSnWn/20190427-191235.png", #camerahttps://i.ibb.co/hVWDsp8/20190428-232907.png", #smulehttps://i.ibb.co/8YfQVtr/20190427-185626.png", #callinghttps://kepriprov.go.id/assets/img/icon/phone.png", #phone
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/camera/"
          },
            "flex": 1
            },
          {
          "type": "image",
            "url": "https://i.ibb.co/CntKh4x/20190525-152240.png", #smule
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "Https://smule.com/KSS_OFFICE",
            },         
            "flex": 1          
          },
          {
          "type": "image",
            "url": "https://i.ibb.co/Wf8bQ2Z/20190625-105354.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/cameraRoll/multi"
            },
            "flex": 1
            },
            {
            "contents": [
            {
            "type": "image",
            "url": "https://i.ibb.co/1sGhJdC/20190428-232658.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/timeline"
            },
            "flex": 1
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#80FF00"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#80FF00"
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "xs",
    "layout": "vertical"
  }
}
}
    cl.postTemplate(to, data)
    
def entog_des(to, text):
    data = {
                                        "type": "flex",
                                        "altText": "TEAM TERMUX 01",
                                        "contents": {
   "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQocF_h93pgbYHwyyysKGeCv6Yuxhmipk-JRQ&usqp=CAU",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♻ SELFBOT TEMPLATE ♻ ",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "8px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": []
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "position": "absolute",
            "width": "152px",
            "height": "20px",
            "offsetTop": "2px",
            "offsetStart": "2px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "NOTIFYOUTUBE",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "50px"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "152px",
            "position": "absolute",
            "height": "20px",
            "offsetTop": "23px",
            "offsetStart": "2px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "40px",
            "height": "120px",
            "offsetTop": "23px",
            "offsetStart": "2px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co/98RJkdy/20190925-164910.png",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "width": "20px",
            "height": "20px",
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "position": "absolute",
            "offsetTop": "30px",
            "offsetStart": "11px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co/F0yX5Yt/20190925-164610.png",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "height": "20px",
            "position": "absolute",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "borderColor": "#FFFF00",
            "offsetTop": "60px",
            "offsetStart": "11px",
            "width": "20px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co/ypkDngF/20190925-164247.png",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "20px",
            "height": "20px",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "borderColor": "#FFFF00",
            "offsetStart": "11px",
            "offsetTop": "90px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co/fvx0z0Q/20190925-164758.png",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "20px",
            "height": "20px",
            "offsetStart": "11px",
            "offsetTop": "119px",
            "position": "absolute"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEAM TERMUX 01 V 1",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "14px"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "150px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "144px",
            "offsetStart": "2px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://cdn5.vectorstock.com/i/1000x1000/62/69/futuristic-music-vector-386269.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "110px",
            "height": "99px",
            "position": "absolute",
            "offsetTop": "44px",
            "offsetStart": "43px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TUNGGU VIDIONYAH",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "16px",
                "offsetStart": "17px"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "150px",
            "height": "46px",
            "position": "absolute",
            "offsetTop": "166px",
            "offsetStart": "2px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "KLIK ORDER SELFBOT",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "15px"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "150px",
            "height": "19px",
            "position": "absolute",
            "offsetTop": "213px",
            "offsetStart": "2px",
            "backgroundColor": "#000000"
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#00FFFF",
        "borderWidth": "2px",
        "cornerRadius": "10px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~linux.1"
        }
      }
    }
  ]
}
}
    cl.postTemplate(to, data)
    
def sendTextTemplate23(to, text):
    data = {
"type": "flex",
"altText": "TEAM TERMUX 01",
"contents": 
{
 "type": "bubble",
"size": "micro",
"body": {
"backgroundColor": "#000000",
"borderWidth": "1px",
"cornerRadius": "3px",
"borderColor": "#800080",
"type": "box",
"borderColor": "#800080",
"layout": "vertical",
"contents": [{
"contents": [{
"contents": [{
"contents": [{
"type": "image",
"url": "https://stickershop.line-scdn.net/stickershop/v1/product/6332071/LINEStorePC/main.png;compress=true",
"size": "4xl",
"aspectRatio": "3:4",
"action": {
"type": "uri",
"uri": "line://nv/profilePopup/mid=u6459106c8251205f79c2f037cd99b6a4"
}},{
"type": "separator",
"color": "#800080"
},{
"contents": [{
"type": "text",
"text": "TEAM TERMUX 01 V 1",
"weight": "bold",
"color": "#ccff00",
"align": "center",
"size": "xxs",
}],
"borderWidth": "1px",
"cornerRadius": "10px",
"borderColor": "#800080",
"type": "box",
"borderColor": "#800080",
"layout": "vertical",
"flex": 7
},{
"type": "separator",
"color": "#ff0000"
},{
"type": "image",
"url": "https://stickershop.line-scdn.net/stickershop/v1/product/6332071/LINEStorePC/main.png;compress=true",
"size": "4xl",
"aspectRatio": "3:4",
"action": {
"type": "uri",
"uri": "line://nv/profilePopup/mid=u6459106c8251205f79c2f037cd99b6a4"
}},{
"type": "separator",
"color": "#800080"
}],
"type": "box",
"layout": "horizontal"
},{
"type": "separator",
"color": "#800080"
}],
"borderWidth": "1px",
"cornerRadius": "2px",
"borderColor": "#800080",
"type": "box",
"borderColor": "#800080",
"layout": "vertical",
"flex": 3,
},{
"type": "separator",
"color": "#800080"
},{
"contents": [{
"type": "separator",
"color": "#800080"
},{
"type": "image",
"url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
"size": "xxs",
"aspectMode": "cover",
"action": {
"type": "uri",
"uri": "http://line.me/ti/p/~linux.1",
},"flex": 0
},{
"type": "separator",
"color": "#800080"
},{      
"contents": [{
"type": "text",
"text": "{}".format(cl.getContact(mid).displayName),
"weight": "bold",
"color": "#FFFFFF",
"align": "center",
"size": "xxs",
"flex": 0
},{
"type": "separator",
"color": "#800080"
},{
"type": "text",
"text": "🗓️"+ datetime.strftime(timeNow,'%Y-%m-%d'),
"weight": "bold",
"color": "#ffffff",
"offsetTop": "3px",
"align": "center",
"size": "xxs",
"flex": 0
}],
"borderWidth": "1px",
"cornerRadius": "10px",
"borderColor": "#800080",
"type": "box",
"borderColor": "#800080",
"layout": "vertical",
"layout": "vertical"
},{
"type": "separator",
"color": "#800080"
}],
"type": "box",
"spacing": "xs",
"layout": "horizontal"
},{
"type": "separator",
"color": "#800080"
},{     
"contents": [{ 
"type": "separator",
"color": "#800080"
},{
"contents": [{
"text": text,
"size": "xxs",
"color": "#FFFFFF",
"wrap": True,
"weight": "bold",
"type": "text"
}],
"borderWidth": "1px",
"cornerRadius": "2px",
"borderColor": "#800080",
"type": "box",
"borderColor": "#800080",
"spacing": "xs",
"layout": "vertical",
},{
"type": "separator",
"color": "#800080"
}],
"type": "box",
"layout": "horizontal"   
},{
"type": "separator",
"color": "#800080"
},{          
"contents": [{
            "type": "separator",
            "color": "#800080"
            },
             {
"type": "image",
"url": "https://i.ibb.co/ypkDngF/20190925-164247.png",
"size": "xxs",
"action": {
"type": "uri",
"uri": "line://nv/profilePopup/mid=uf4417e6754a032b754fc312dd6a4b98a"
            },
            "flex": 1
          },
          {
"type": "image",
"url": "https://i.ibb.co/F0yX5Yt/20190925-164610.png",
"size": "xxs",
"action": {
"type": "uri",
"uri": "line://nv/camera/"
           }, 
            "flex": 1            
          },
          {
"type": "image",
"url": "https://i.ibb.co/98RJkdy/20190925-164910.png",
"size": "xxs",
"action": {
"type": "uri",
"uri": "Https://smule.com/KSS_OFFICE"
          },
            "flex": 1
            },
          {
"type": "image",
"url": "https://i.ibb.co/fvx0z0Q/20190925-164758.png",
"size": "xxs",
"action": {
"type": "uri",
"uri": "line://nv/cameraRoll/single"
            },         
            "flex": 1          
          },
          {
"type": "image",
"url": "https://i.ibb.co/nRKcLQN/20190925-165015.png",
"size": "xxs",
"action": {
"type": "uri",
"uri": "line://nv/chat"
            },
            "flex": 1
            },
            {
            "contents": [
            {
"type": "image",
"url": "https://scontent-cgk1-2.xx.fbcdn.net/v/t1.0-9/85106040_184561645977108_8424969923272376320_o.jpg?_nc_cat=105&ccb=2&_nc_sid=8bfeb9&_nc_eui2=AeGBKBifzBLzNE71hTzLNvAGbbBygnYDuvFtsHKCdgO68UA39j3uu-MqIXOwePcuAszI1esXeSt0V6wlceKLHDgH&_nc_ohc=cAi3ZKewnkoAX_Qg7Lr&_nc_ht=scontent-cgk1-2.xx&oh=088f9c37398ec074aa9346d465143e30&oe=6007FFCB",
"size": "xxs",
"action": {
"type": "uri",
"uri": "line://calls"
            },
            "flex": 1
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#800080"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#800080"
          }
        ],
"borderWidth": "1px",
"cornerRadius": "2px",
"borderColor": "#800080",
"type": "box",
"borderColor": "#800080",
"layout": "vertical",
      }
    ],
"borderWidth": "2px",
"cornerRadius": "10px",
"borderColor": "#800080",
"type": "box",
"borderColor": "#800080",
"spacing": "xs",
"layout": "vertical",
  }
}
}
    cl.postTemplate(to, data)
    
def sendTextZul(to, text):
    data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX 01",
                                       "contents": 
{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "kilo",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://image.freepik.com/vecteurs-libre/fond-abstrait-sombre-couches-chevauchement-concept-design-luxe-paillettes-dorees-points-decoration-element-concept-design-luxe_98702-235.jpg",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:1",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "."
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "borderWidth": "2px",
            "cornerRadius": "10px",
            "width": "240px",
            "offsetStart": "9px",
            "offsetTop": "5px",
            "height": "100px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQnfDjeBPdnAQWjeGl-qJYlZHWqcDH7lTMS9Q&usqp=CAU",
                "size": "full",
                "aspectMode": "cover",
                "aspectRatio": "2:2"
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "borderWidth": "2px",
            "cornerRadius": "5px",
            "offsetStart": "13px",
            "offsetTop": "9px",
            "width": "230px",
            "height": "50px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "NOTIF SMULE",
                "color": "#FFFFFF",
                "offsetStart": "60px",
                "offsetTop": "10px"
              }
            ],
            "position": "absolute",
            "borderColor": "#FF0000",
            "cornerRadius": "5px",
            "borderWidth": "2px",
            "width": "224px",
            "height": "44px",
            "offsetTop": "12px",
            "offsetStart": "16px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTrL6_OWpBPDFXt37Mu-tf-yN53HCcQwpmPHA&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "borderWidth": "1px",
            "offsetTop": "107px",
            "offsetStart": "20px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQ-mEPYZfmukEcUxcgezRBY3FsK5AgHexjRew&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "borderColor": "#FFFF00",
            "width": "20px",
            "height": "20px",
            "offsetTop": "107px",
            "offsetStart": "100px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTg1fhBBBP105VAwZ4ou7U0dPc8aMVjANnHnQ&usqp=CAU"
              }
            ],
            "offsetTop": "107px",
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "position": "absolute",
            "offsetStart": "145px",
            "width": "20px",
            "height": "20px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQi0p8mKetlnBiPJSNGldoV9Sk_h6aZtxW10Q&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "107px",
            "offsetStart": "180px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQ0rFvYay8LyrCQUJfOWzC6y-28jXb1JS3ALg&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "20px",
            "height": "20px",
            "offsetTop": "107px",
            "offsetStart": "220px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQOCIfqq1TEtV6mXUFdS83uR5IUqDkCh0nh2g&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "offsetTop": "107px",
            "height": "20px",
            "width": "20px",
            "offsetStart": "60px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "color": "#FFFFFF",
                "size": "xs",
                "offsetStart": "45px",
                "wrap": True,
                "text": "Keren Kk Suara Nyah",
                "offsetTop": "10px"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "2px",
            "cornerRadius": "7px",
            "width": "233px",
            "position": "absolute",
            "offsetTop": "62px",
            "offsetStart": "12px",
            "height": "40px",
            "backgroundColor": "#000080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "5px",
            "borderWidth": "2px",
            "position": "absolute",
            "width": "40px",
            "offsetTop": "62px",
            "offsetStart": "13px",
            "height": "40px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "2px",
            "position": "absolute",
            "cornerRadius": "5px",
            "offsetTop": "62px",
            "width": "40px",
            "height": "40px",
            "offsetStart": "205px"
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#FFFF00",
        "borderWidth": "2px",
        "cornerRadius": "10px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~linux.1"
        }
      }
    }
  ]
}
}
    cl.postTemplate(to, data)
    
def sendTextTemplate00(to, text):
    data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX 01",
                                       "contents": 
{
"type": "bubble",
"size": "micro",
"body": {
"backgroundColor": "#008B8B",
"type": "box",
"layout": "vertical",
  "contents": [
      {
        "contents": [                   
            {            
            "type": "separator",
            "color": "#ffffff"            
      },
      {
        "type": "separator",
        "color": "#ffffff"  
      },
      {         
         "contents": [
          {
          "type": "separator",
          "color": "#ffffff"   
      },
      {
            "contents": [
              {
              "type": "image",
     "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
          },{
 "type": "text",
"text": "TEAM TERMUX 01",
"weight": "bold",
"color": "#FFFFFF",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "ɬɛąɱ",
"weight": "bold",
"color": "#FFFFFF",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "ცơɬʂ ☬",
"weight": "bold",
"color": "#FFFFFF",
"size": "xxs",
"flex": 0
      },
      {
    "type": "image",
     "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#FFFFFF"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#FFFFFF"
         },
         {
       "contents": [
         {
        "type": "separator",
        "color": "#FFFFFF"
         },
         {
            "text": "📔📔📔",
            "size": "xxs",
            "color": "#FFFFFF",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#ffffff"
           },
             {
            "text": "📔📔📔",
            "size": "xxs",
            "color": "#FFFFFF",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#ffffff"
           },
             {
            "text": "📘📘📘",
            "size": "xxs",
            "color": "#FFFFFF",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"   
            },
         {
        "type": "separator",
        "color": "#ffffff"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#ffffff"
         },
         {
       "contents": [
          {
           "type": "separator",
           "color": "#ffffff"
          },
          {
          "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
            "type": "image",
            "size": "xxs",
            "flex": 0
          },
          {
        "type": "separator",
        "color": "#ffffff"
      },
      {      
       "contents": [              
          {
"type": "text",
"text": "TEAM TERMUX 01",
"weight": "bold",
"color": "#FFFFFF",
"align": "center",
"size": "xxs",
"flex": 0
},{
"type": "separator",
"color": "#ffffff"
},{
"type": "text",
"text": "⏰"+ datetime.strftime(timeNow,'%H:%M:%S'+"⏰"),
"weight": "bold",
"color": "#ffffff",
"align": "center",
"size": "xxs",
"flex": 0
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"
      },
      {
        "type": "separator",
        "color": "#ffffff"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"
      },
      {
        "type": "separator",
         "color": "#ffffff"
       },
       {     
       "contents": [           
         { 
           "type": "separator",
           "color": "#ffffff"
            },
           {
            "contents": [
              {
              "type": "separator",
           "color": "#ffffff"
            },
           {
          "type": "text",
"text": "{}".format(cl.getContact(mid).displayName),
"weight": "bold",
"color": "#FFFFFF",
"align": "center",
"size": "xxs",
"flex": 0
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#ffffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#ffffff"
         },
         {          
         "contents": [
         { 
           "type": "separator",
           "color": "#ffffff"
            },
           {
            "contents": [
              {
              "type": "separator",
           "color": "#ffffff"
            },
           {
          "text": text,
           "size": "xxs",
          #"align": "center",
           "color": "#FFFFFF",
           "wrap": True,
           "weight": "bold",
           "type": "text"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#ffffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#ffffff"
         },
         {
       "contents": [
         {
        "type": "separator",
        "color": "#ffffff"
         },
         {
            "text": "📘📘📘",
            "size": "xxs",
            "color": "#FFFFFF",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#ffffff"
           },
             {
            "text": "📕📕📕",
            "size": "xxs",
            "color": "#FFFFFF",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#ffffff"
           },
             {
            "text": "📔??📔",
            "size": "xxs",
            "color": "#FFFFFF",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"   
          },
         {
        "type": "separator",
        "color": "#ffffff"
         }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#ffffff"
         },
         {
      "contents": [
          {
            "type": "separator",
            "color": "#ffffff"
            },
             {
            "type": "image",
            "url": "https://i.ibb.co/XWQd8rj/20190625-201419.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "https://youtube.com",
           }, 
            "flex": 1
          },
          {
          "type": "image",
            "url": "https://i.ibb.co/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "http://line.me/ti/p/~linux.1",             
           }, 
            "flex": 1            
          },
          {
          "type": "image",
            "url": "https://i.ibb.co/ZHtFDts/20190427-185307.png", #chathttps://i.ibb.co/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/chat" #"http://line.me/ti/p/~linux.1",
            },         
            "flex": 1          
            },
          {
          "type": "image",
            "url": "https://i.ibb.co/CntKh4x/20190525-152240.png", #smule
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "Https://smule.com/KSS_OFFICE",
            },         
            "flex": 1          
          },
          {
          "type": "image",
            "url": "https://i.ibb.co/Wf8bQ2Z/20190625-105354.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/cameraRoll/multi"
            },
            "flex": 1
            },
            {
            "contents": [
            {
            "type": "image",
            "url": "https://i.ibb.co/1sGhJdC/20190428-232658.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/timeline"
          },
            "flex": 1           
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#ffffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#ffffff"
        },{
        "contents": [         
              {
            "type": "separator",
            "color": "#ffffff"
            },
             {          
            "contents": [
               {
    "type": "image",
    "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
    },{
 "type": "text",
"text": "TEAM TERMUX 01",
"weight": "bold",
"color": "#FFFFFF",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "ɬɛąɱ",
"weight": "bold",
"color": "#FFFFFF",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "ცơɬʂ ☬",
"weight": "bold",
"color": "#FFFFFF",
"size": "xxs",
"flex": 0
      },
      {
    "type": "image",
    "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#ffffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator", #batas APK
        "color": "#ffffff"     
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "xs",
    "layout": "vertical"
  }
}
}
    cl.postTemplate(to, data)
   #Def Musik
   
def sendTextTemplate10(to, text):
    data = {
                                "type": "flex",
                                "altText": "TEAM TERMUX 01",
                                "contents": {
"type": "carousel",
"contents": [
{
"type": "bubble",
"size": "nano",
"body": {
"backgroundColor": "#00ff00",
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "image", #Wall 1
"url": "https://content.skyscnr.com/m/7d3992c451e6cf6c/original/color.gif?imbypass=true",
"size": "full",
"aspectMode": "cover",
"aspectRatio": "4:5",
"gravity": "bottom",
"action": {
"uri": "line://nv/profilePopup/mid=u6459106c8251205f79c2f037cd99b6a4",
"type": "uri",
}
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "image", #Wall 2
"url": "https://content.skyscnr.com/m/7d3992c451e6cf6c/original/color.gif?imbypass=true",
"gravity": "bottom",
"size": "xxl",
"aspectMode": "cover",
"aspectRatio": "2:3",
"offsetTop": "0px",
"action": {
"uri": "line://nv/profilePopup/mid=u6459106c8251205f79c2f037cd99b6a4",
"type": "uri",
}
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "5px",
"offsetStart": "5px",
"height": "140px",
"width": "110px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "image", #Wall 2
"url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
"gravity": "bottom",
"size": "xxl",
"aspectMode": "cover",
"aspectRatio": "2:3",
"offsetTop": "0px",
"action": {
"uri": "line://nv/profilePopup/mid=u6459106c8251205f79c2f037cd99b6a4",
"type": "uri",
}
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "5px",
"offsetStart": "5px",
"height": "140px",
"width": "110px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": "Hiburan",
"align": "center",
"color": "#000000",
"weight": "bold",
"size": "xxs",
"weight": "bold",
"offsetTop": "1px"
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "9px",
"backgroundColor": "#ffd700",
"offsetStart": "7px",
"height": "15px",
"width": "45px"
},
{
"type": "box",
"layout": "vertical",
"contents": [ #dsini
{
"type": "image",
"url": "https://thumbs.gfycat.com/UnkemptWhiteKakapo-max-1mb.gif",
"size": "xxl",
"action": {
"type": "uri",
"uri": "https://wa.me/+6285757076639",
},         
"flex": 0
}
],
"position": "absolute",
"offsetTop": "5px",
"offsetStart": "92px",
"height": "43px",
"width": "22px"
},
{
"type": "box",
"layout": "vertical",
"contents": [ #dsini
{
"type": "image",
"url": "https://thumbs.gfycat.com/UnkemptWhiteKakapo-max-1mb.gif",
"size": "xxl",
"action": {
"type": "uri",
"uri": "https://joox.com"
},         
"flex": 0
}
],
"position": "absolute",
"offsetTop": "5px",
"offsetStart": "67px",
"height": "43px",
"width": "22px"
},
{
"type": "box",
"layout": "vertical",
"contents": [ #dsini
{
"type": "image",
"url": "https://i.ibb.co/CntKh4x/20190525-152240.png", #smule
"size": "xl",
"action": {
"type": "uri",
"uri": "Https://smule.com/KSS_OFFICE",
},
"flex": 0
},{
"type": "image",
"url": "https://i.ibb.co/ZHtFDts/20190427-185307.png",
"size": "xl",
"action": {
"type": "uri",
"uri": "line://nv/chat",
},
"flex": 0
},{
"type": "image",
"url": "https://i.ibb.co/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
"size": "full",
"action": {
"type": "uri",
"uri": "http://line.me/ti/p/~linux.1",
},
"flex": 0
},{
"type": "image",
"url": "https://i.ibb.co/XWQd8rj/20190625-201419.png",
"size": "full",
"action": {
"type": "uri",
"uri": "https://youtube.com",
},
"flex": 0
}
],
"position": "absolute",
"offsetTop": "25px",
"offsetStart": "5px",
"height": "180px",
"width": "25px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": "➥   "+ datetime.strftime(timeNow,'%H:%M:%S'),
"weight": "bold",
"color": "#ffffff",
#"align": "center",
"size": "xxs",
"offsetTop": "0px"
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "98px",
"backgroundColor": "#ff0000",
"offsetStart": "50px",
"height": "16px",
"width": "63px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": text, #📆 "+ datetime.strftime(timeNow,'%Y-%m-%d'),
"weight": "bold",
"color": "#ffffff",
"size": "xxs",
"offsetTop": "0px"
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "115px",
"backgroundColor": "#0000ff",
"offsetStart": "33px",
"height": "14px",
"width": "80px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": "TEAM TERMUX 01 V 1",
"weight": "bold",
"color": "#00ff00",
"size": "xxs",
"offsetTop": "0px"
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "130px",
#"backgroundColor": "#33ffff",
"offsetStart": "8px",
"height": "50px",
"width": "110px"
}
],
#"backgroundColor": "#",
"paddingAll": "0px"
}
},
]
}
}
    cl.postTemplate(to, data)
   
def command(text):
    pesan = text.lower()
    if pesan.startswith(Setmain['keyCommand']):
        cmd = pesan.replace(Setmain['keyCommand'],"")
    else:
        cmd = "command"
    return cmd

def keybot():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage = "╭「TEAM TERMUX 01」\n"+\
                  "╠➣  " + key + "sᴇᴛᴛɪɴɢ\n" + \
                  "╠➣  " + key + "ʜᴇʟᴘ ɢʀᴏᴜᴘ\n" + \
                  "╠➣  " + key + "ʜᴇʟᴘ ᴍᴇᴅɪᴀ\n" + \
                  "╠➣  " + key + "ʜᴇʟᴘ ᴀᴅᴍɪɴ\n" + \
                  "╠➣  " + key + "ʜᴇʟᴘ ᴄʀᴇᴀᴛᴏʀ\n" + \
                  "╠➣  " + key + "ʜᴇʟᴘ sᴇᴛᴛɪɴɢ\n" + \
                  "╰「TEAM TERMUX 01 V 1」"
    return helpMessage

def helpcreator():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage1 = "╭「TEAM TERMUX 01」\n"+\
                  "╠➣ " + key + "ᴍᴇ\n" + \
                  "╠➣ " + key + "ᴄᴠᴘ\n" + \
                  "╠➣ " + key + "sᴇᴛᴛɪɴɢ\n" + \
                  "╠➣ " + key + "ʀᴜɴᴛɪᴍᴇ\n" + \
                  "╠➣ " + key + "sᴘᴇᴇᴅ-sᴘ\n" + \
                  "╠➣ " + key + "sᴀɴᴛᴇᴛ ᴍᴀɴᴛᴀɴ\n" + \
                  "╠➣ " + key + "ʙʏᴇᴍᴇ\n" + \
                  "╠➣ " + key + "ʀᴇᴊᴇᴄᴛ\n" + \
                  "╠➣ " + key + "ʟᴇᴀᴠᴇᴀʟʟ\n" + \
                  "╠➣ " + key + "ʟɪsᴛғʀɪᴇɴᴅ\n" + \
                  "╠➣ " + key + "ғʀɪᴇɴᴅʟɪsᴛ\n" + \
                  "╠➣ " + key + "ɢʀᴜᴘʟɪsᴛ\n" + \
                  "╠➣ " + key + "ᴏᴘᴇɴ ǫʀ\n" + \
                  "╠➣ " + key + "ᴄʟᴏsᴇ ǫʀ\n" + \
                  "╠➣ " + key + "ᴛᴀɢᴀʟʟ\n" + \
                  "╠➣ " + key + ".ɪɴᴠɪᴛᴇ @\n" + \
                  "╠➣ " + key + "ʙʟᴏᴄᴋ「@」\n" + \
                  "╠➣ " + key + "ᴀᴅᴅᴍᴇ「@」\n" + \
                  "╠➣ " + key + "ᴍʏʙᴏᴛ\n" + \
                  "╠➣ " + key + "ʟɪsᴛᴘᴇɴᴅɪɴɢ\n" + \
                  "╠➣ " + key + "ʙʟᴏᴄᴋᴄᴏɴᴛᴀᴄᴛ\n" + \
                  "╠➣ " + key + "ʟɪsᴛʙʟᴏᴄᴋ\n" + \
                  "╠➣ " + key + "ʟɪsᴛᴍɪᴅ\n" + \
                  "╠➣ " + key + "ᴀᴅᴅᴀsɪs\n" + \
                  "╠➣ " + key + "ʙʀᴏᴀᴅᴄᴀsᴛ:「ᴛᴇxᴛ」\n" + \
                  "╠➣ " + key + "ʙʀᴏᴀᴅᴄᴀsᴛ1:「ᴛᴇxᴛ」\n" + \
                  "╰「TEAM TERMUX 01 V 1」"
    return helpMessage1

def helpadmin():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage5 = "╭「TEAM TERMUX 01」\n"+\
                  "╠➣ "  + key + "sᴛᴀғғ「@」\n" + \
                  "╠➣ "  + key + "sᴛᴀғᴅᴇʟʟ「@」\n" + \
                  "╠➣ "  + key + "ᴀᴅᴍɪɴ「@」\n" + \
                  "╠➣ "  + key + "ᴀᴅᴍɪɴᴅᴇʟʟ「@」\n" + \
                  "╠➣ "  + key + "ᴅᴇʟʟғʀɪᴇɴᴅ「@」\n" + \
                  "╠➣ "  + key + "sᴛᴀᴛᴜs:「ᴛᴇxᴛ」\n" + \
                  "╠➣ "  + key + "!ᴄᴀɴᴄᴇʟ「ʙᴏᴍ」\n" + \
                  "╠➣ "  + key + "!ᴊs ɢᴏ\n" + \
                  "╠➣ "  + key + "ʀᴇʙᴏᴏᴛ\n" + \
                  "╠➣ "  + key + "ʙᴀɴ「@」\n" + \
                  "╠➣ "  + key + "ᴋɪᴄᴋ「@」\n" + \
                  "╠➣ "  + key + "ɢᴋɪᴄᴋ「@」\n" + \
                  "╠➣ "  + key + "ʙʟᴄ\n" + \
                  "╠➣ "  + key + "ʙᴀɴ:ᴏɴ\n" + \
                  "╠➣ "  + key + "ᴜɴʙᴀɴ:oɴ\n" + \
                  "╠➣ "  + key + "ᴜɴʙᴀɴ「@」\n" + \
                  "╠➣ "  + key + "ʙᴀɴʟɪsᴛ\n" + \
                  "╠➣ "  + key + "ᴄʙᴀɴ\n" + \
                  "╠➣ "  + key + "ʀᴇғʀᴇsʜ\n" + \
                  "╰「TEAM TERMUX 01」"
    return helpMessage5
  
def helpgroup():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage4 = "╭「TEAM TERMUX 01」\n"+\
                  "╠➣ " + key + "ɢᴍɪᴅ @\n" + \
                  "╠➣ " + key + "ɢᴇᴛ ɪᴅ @\n" + \
                  "╠➣ " + key + "ɢᴇᴛᴍɪᴅ @\n" + \
                  "╠➣ " + key + "ɢᴇᴛʙɪᴏ @\n" + \
                  "╠➣ " + key + "ɢᴇᴛɪɴғᴏ @\n" + \
                  "╠➣ " + key + "ɢᴇᴛᴘʀᴏғɪʟᴇ @\n" + \
                  "╠➣ " + key + "ɢᴇᴛᴘɪᴄᴛᴜʀᴇ @\n" + \
                  "╠➣ " + key + "ɪɴғᴏ @\n" + \
                  "╠➣ " + key + "ᴋᴇᴘᴏ @\n" + \
                  "╠➣ " + key + "ᴘᴘᴠɪᴅᴇᴏ @\n" + \
                  "╠➣ " + key + "ᴋᴏɴᴛᴀᴋ @\n" + \
                  "╠➣ " + key + "ᴄᴏɴᴛᴀᴄᴛ:「ᴍɪᴅ」\n" + \
                  "╠➣ " + key + "ɢɴᴀᴍᴇ「ᴛᴇxᴛ」\n" + \
                  "╠➣ " + key + "ᴍʏᴍɪᴅ\n" + \
                  "╠➣ " + key + "ᴍʏʙɪᴏ\n" + \
                  "╠➣ " + key + "ᴍʏғᴏᴛᴏ\n" + \
                  "╠➣ " + key + "ᴍʏɴᴀᴍᴇ\n" + \
                  "╠➣ " + key + "ᴍʏᴘʀᴏғɪʟᴇ\n" + \
                  "╠➣ " + key + "ᴍʏᴘɪᴄᴛᴜʀᴇ\n" + \
                  "╠➣ " + key + "ᴍʏᴄᴏᴠᴇʀ\n" + \
                  "╠➣ " + key + "ᴍʏᴠɪᴅᴇᴏ\n" + \
                  "╠➣ " + key + "ᴋᴀʟᴇɴᴅᴇʀ\n" + \
                  "╠➣ " + key + "ᴍᴇᴍᴘɪᴄᴛ\n" + \
                  "╠➣ " + key + "ᴜᴘᴅᴀᴛᴇɢʀᴜᴘ\n" + \
                  "╠➣ " + key + "ɢʀᴜᴘᴘɪᴄᴛ\n" + \
                  "╠➣ " + key + "ɪɴғᴏɢʀᴏᴜᴘ「ɴᴏ」\n" + \
                  "╠➣ " + key + "ɪɴғᴏᴍᴇᴍ「ɴᴏ」\n" + \
                  "╰「TEAM TERMUX 01」"
    return helpMessage4
def helpsetting():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage2 = "╭「TEAM TERMUX 01」\n"+\
                  "╠➣ " + key + "ᴄᴇᴋ sɪᴅᴇʀ\n" + \
                  "╠➣ " + key + "ᴄᴇᴋ ʟᴇᴀᴠᴇ \n" + \
                  "╠➣ " + key + "ᴄᴇᴋ ᴘᴇsᴀɴ \n" + \
                  "╠➣ " + key + "ᴄᴇᴋ ʀᴇsᴘᴏɴ \n" + \
                  "╠➣ " + key + "ᴄᴇᴋ ʀᴇsᴘᴏɴ² \n" + \
                  "╠➣ " + key + "sᴇᴛ sɪᴅᴇʀ:「ᴛᴇxᴛ」\n" + \
                  "╠➣ " + key + "sᴇᴛ ᴘᴇsᴀɴ:「ᴛᴇxᴛ」\n" + \
                  "╠➣ " + key + "sᴇᴛ ʀᴇsᴘᴏɴ:「ᴛᴇxᴛ」\n" + \
                  "╠➣ " + key + "sᴇᴛ ʀᴇsᴘᴏɴ²:「ᴛᴇxᴛ」\n" + \
                  "╠➣ " + key + "sᴇᴛ ᴡᴇʟᴄᴏᴍᴇ:「ᴛᴇxᴛ」\n" + \
                  "╠➣ " + key + "sᴇᴛᴄᴏᴍᴍᴇɴᴛ:「ᴛᴇxᴛ」\n" + \
                  "╠➣ " + key + "sᴇᴛ ʟᴇᴀᴠᴇ:「ᴛᴇxᴛ」\n" + \
                  "╠➣ " + key + "ʟɪᴋᴇ「ᴏɴ/ᴏғғ」\n" + \
                  "╠➣ " + key + "ᴘᴏsᴛ「oɴ/oғғ」\n" + \
                  "╠➣ " + key + "sᴛɪᴄᴋᴇʀ「oɴ/oғғ」\n" + \
                  "╠➣ " + key + "ɪɴᴠɪᴛᴇ「oɴ/ᴏғғ」\n" + \
                  "╠➣ " + key + "ᴜɴsᴇɴᴅ「oɴ/oғғ」\n" + \
                  "╠➣ " + key + "ᴀᴜᴛᴏʀᴇᴀᴅ「oɴ/oғғ」\n" + \
                  "╠➣ " + key + "ᴅᴇʟғʀɪᴇɴᴅ「oɴ/oғғ」\n" + \
                  "╠➣ " + key + "ʀᴇsᴘᴏɴ「oɴ/oғғ」\n" + \
                  "╠➣ " + key + "ʀᴇsᴘᴏɴ²「oɴ/oғғ」\n" + \
                  "╠➣ " + key + "ᴀᴜᴛᴏᴀᴅᴅ「oɴ/oғғ」\n" + \
                  "╠➣ " + key + "ᴡᴇʟᴄᴏᴍᴇ「oɴ/oғғ」\n" + \
                  "╠➣ " + key + "ᴄᴏɴᴛᴀᴄᴛ「oɴ/oғғ」\n" + \
                  "╠➣ " + key + "ᴀᴜᴛᴏᴊᴏɪɴ「oɴ/oғғ」\n" + \
                  "╠➣ " + key + "ᴀᴜᴛᴏʀᴇᴊᴇᴄᴛ「oɴ/oғғ」\n" + \
                  "╠➣ " + key + "ᴀᴜᴛᴏʟᴇᴀᴠᴇ「oɴ/oғғ」\n" + \
                  "╠➣ " + key + "ᴀᴜᴛᴏʙʟᴏᴄᴋ「oɴ/oғғ」\n" + \
                  "╠➣ " + key + "ᴊᴏɪɴᴛɪᴄᴋᴇᴛ「oɴ/oғғ」\n" + \
				  "╰「TEAM TERMUX 01」"
    return helpMessage2

def media():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage3 = "╭「TEAM TERMUX 01」\n"+\
                  "╠➣ " + key + "ᴀᴅᴅɪᴍɢ\n" + \
                  "╠➣ " + key + "ᴀᴅᴅᴍᴘ3\n" + \
                  "╠➣ " + key + "ᴀᴅᴅᴀᴜᴅɪᴏ\n" + \
                  "╠➣ " + key + "ᴀᴅᴅᴠɪᴅᴇᴏ\n" + \
                  "╠➣ " + key + "ᴀᴅᴅsᴛɪᴄᴋᴇʀ\n" + \
                  "╠➣ " + key + "ᴅᴇʟʟɪᴍɢ\n" + \
                  "╠➣ " + key + "ᴅᴇʟʟᴍᴘ3\n" + \
                  "╠➣ " + key + "ᴅᴇʟʟᴀᴜᴅɪᴏ\n" + \
                  "╠➣ " + key + "ᴅᴇʟʟᴠɪᴅᴇᴏ\n" + \
                  "╠➣ " + key + "ᴅᴇʟʟsᴛɪᴄᴋᴇʀ\n" + \
                  "╠➣ " + key + "ʟɪsᴛᴛɪᴄᴋᴇʀ\n" + \
                  "╠➣ " + key + "ʟɪsᴛɪᴍᴀɢᴇ\n" + \
                  "╠➣ " + key + "ʟɪsᴛᴠɪᴅᴇᴏ\n" + \
                  "╠➣ " + key + "ʟɪsᴛᴀᴜᴅɪᴏ\n" + \
                  "╠➣ " + key + "ʟɪsᴛᴍᴘ3\n" + \
                  "╠➣ " + key + "ᴄᴄᴛᴠ ᴍᴇᴛʀᴏ\n" + \
                  "╠➣ " + key + "ʟɪʜᴀᴛ [no]\n" + \
                  "╠➣ " + key + "sᴍᴜʟᴇ [ɪᴅ]\n" + \
                  "╠➣ " + key + "ᴊᴏᴏx [ᴛᴇxᴛ]\n" + \
                  "╠➣ " + key + "ᴍᴘ3: [ᴛᴇxᴛ]\n" + \
                  "╠➣ " + key + "ᴍᴘ4: [ᴛᴇxᴛ]\n" + \
                  "╠➣ " + key + "ʏᴜᴛᴜʙᴇ [ᴛᴇxᴛ]\n" + \
                  "╠➣ " + key + "ʏᴏᴜᴛᴜʙᴇ [ᴛᴇxᴛ]\n" + \
                  "╰「TEAM TERMUX 01」"
    return helpMessage3


def bot(op):
    global time
    global ast
    global groupParam
    try:
        if op.type == 0:
            return
        if op.type == 5:
            if wait["autoBlock"] == True:
                cl.blockContact(op.param1)
                cl.sendMessage(op.param1,"➥   ꜱᴏʀʀʏ ᴀᴜᴛᴏʙʟᴏᴄᴋ ᴀᴋᴛɪꜰ [ᴍᴀᴛɪ].👁️.★.★.★.👁️.[ᴍᴀᴛɪ].1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.👿.👿.👿 [ᴍᴀᴛɪ].👁️.★.★.★.👁️.[ᴍᴀᴛɪ].1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.☆.👿.👿.👿.\n[ᴍᴀᴛɪ].👁️.★.★.★.👁️.[ᴍᴀᴛɪ].1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.☆.👿.👿.👿.\n[ᴍᴀᴛɪ].👁️.★.★.★.👁️.[ᴍᴀᴛɪ].1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.☆.👿.👿.👿.")
        if op.type == 13 or op.type == 124:
            if mid in op.param3:
                if wait["autoLeave"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        cl.acceptGroupInvitation(op.param1)
                        ginfo = cl.getGroup(op.param1)
                        cl.leaveGroup(op.param1)
                    else:
                        cl.acceptGroupInvitation(op.param1)
                        ginfo = cl.getGroup(op.param1)
        if op.type == 26:
            msg = op.message
            sender = msg._from
            to = msg.to
            if msg.contentType == 6:
             if wait["responGc"] == True:
                 a = cl.getContact(sender)
                 if msg.toType == 2:
                     b = msg.contentMetadata['GC_EVT_TYPE']
                     c = msg.contentMetadata["GC_MEDIA_TYPE"]
                     if c == "VIDEO" and b == "S":                     	
                         tz = pytz.timezone("Asia/Jakarta")
                         timeNow = datetime.now(tz=tz)                                             
                         cl.getGroup(to).name
                         cl.getContact(msg._from).displayName
                         warna1 = ("#ff69b4","#00ffff","#9933ff","#0033CC","#00ff33","#cc00ff","#ff0033","#003333")
                         warnanya1 = random.choice(warna1)   
                         data = {
                                        "type": "flex",
                                        "altText": "TEAM TERMUX 01",
                                        "contents": {

 "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcT67I6CBmlnNYe80zaxsXI4N3jUrQHVlakwHQ&usqp=CAU",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "NOTIFCALL GRUP",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "28px"
              }
            ],
            "borderColor": "#00FFFF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "150px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "2px",
            "offsetStart": "3px",
            "backgroundColor": "#8B0000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": " "+ datetime.strftime(timeNow,'%H:%M:%S'),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "70px",
            "height": "20px",
            "offsetTop": "26px",
            "offsetStart": "2px",
            "backgroundColor": "#008000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": " "+ datetime.strftime(timeNow,'%Y-%m-%d'),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "cornerRadius": "5px",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "width": "75px",
            "height": "20px",
            "offsetTop": "26px",
            "offsetStart": "78px",
            "backgroundColor": "#0000FF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "borderColor": "#FF1493",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "151px",
            "height": "77px",
            "offsetTop": "50px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(msg._from).pictureStatus),
                "size": "full",
                "aspectMode": "cover",
                "aspectRatio": "2:1"
              }
            ],
            "position": "absolute",
            "borderColor": "#00FF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "height": "75px",
            "width": "149px",
            "offsetTop": "51px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": []
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "151px",
            "height": "30px",
            "offsetTop": "130px",
            "offsetStart": "2px",
            "backgroundColor": "#8B0000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://scontent.fsub4-1.fna.fbcdn.net/v/t1.0-9/123136920_1773483959470906_4228992933786075272_n.jpg?_nc_cat=108&ccb=2&_nc_sid=8bfeb9&_nc_eui2=AeHMEQSiqyKdpGrrcUHSMORxTzxiwgMoEadPPGLCAygRp_TfhcdQGLdr1IenKSC14uhDEzIPhUrb4ODjpW5RPMzr&_nc_ohc=tSKuER-nVZMAX9fEqZK&_nc_ht=scontent.fsub4-1.fna&oh=acf52a3d717303ec0dd89f5edd9d860c&oe=5FC3A89D",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "25px",
            "height": "25px",
            "position": "absolute",
            "offsetTop": "133px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://scontent.fsub3-2.fna.fbcdn.net/v/t1.0-9/123166273_1773484166137552_395984840788344060_n.jpg?_nc_cat=105&ccb=2&_nc_sid=8bfeb9&_nc_eui2=AeHwb_cRdplO8k1JHQIo5-ardrsLOwsuXjR2uws7Cy5eNAw3prWmJypnn9WR_GPyL0SwJ5mz3Wrs4ZmdcgEGz_sl&_nc_ohc=hpXb6zz1XB8AX_ei27w&_nc_ht=scontent.fsub3-2.fna&oh=2a2652e91eed1f7a30bc20445dc4f5e1&oe=5FC47CAC",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "25px",
            "height": "25px",
            "position": "absolute",
            "offsetTop": "133px",
            "offsetStart": "35px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://media.cdnandroid.com/item_images/146592/imagen-autorap-by-smule-0big.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "25px",
            "height": "25px",
            "position": "absolute",
            "offsetTop": "133px",
            "offsetStart": "65px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://img.utdstc.com/icons/facebook-android.png:l",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "25px",
            "height": "25px",
            "position": "absolute",
            "offsetTop": "133px",
            "offsetStart": "95px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSSj_Wod4iOqe8RLGTR6-XycscxAi21wSGehA&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "height": "25px",
            "width": "25px",
            "position": "absolute",
            "offsetTop": "133px",
            "offsetStart": "125px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "✬  {}".format(cl.getContact(mid).displayName),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "150px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "162px",
            "offsetStart": "2px",
            "backgroundColor": "#800080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "borderColor": "#FF00FF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "150px",
            "height": "47px",
            "offsetTop": "185px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Wow Jones Naik Temenin Tuh Kasian Anak Orang",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "6px",
                "offsetStart": "9px",
                "wrap": True,
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "position": "absolute",
            "width": "148px",
            "height": "45px",
            "offsetTop": "186px",
            "offsetStart": "4px",
            "backgroundColor": "#008000",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "http://line.me/ti/p/~linux.1"
            }
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#FF1493",
        "borderWidth": "2px",
        "cornerRadius": "10px"
      }
    },
  {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://media.suara.com/pictures/653x366/2015/04/17/o_19j3m1hgthf63ni1h951v366r6a.jpg",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "NOTIFCALL GRUP",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "25px"
              }
            ],
            "width": "149px",
            "height": "20px",
            "borderColor": "#FF0000",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "position": "absolute",
            "offsetTop": "5px",
            "offsetStart": "3px",
            "backgroundColor": "#000080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(msg._from).pictureStatus),
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "150px",
            "height": "90px",
            "position": "absolute",
            "offsetTop": "30px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#FF0000",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "150px",
            "height": "40px",
            "position": "absolute",
            "offsetTop": "147px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Kenapa Turun Udah Dapet Tikungan Yah",
                "size": "xxs",
                "color": "#FFFFFF",
                "wrap": True,
                "offsetStart": "2px",
                "offsetTop": "2px"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "148px",
            "height": "38px",
            "position": "absolute",
            "offsetTop": "148px",
            "offsetStart": "3px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "SUPPORT  BY: Zulkifli",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "7px"
              }
            ],
            "borderColor": "#FF00FF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "150px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "210px",
            "offsetStart": "2px",
            "backgroundColor": "#2E8B57"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "CREATOR",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "6px"
              }
            ],
            "borderColor": "#FF00FF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "70px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "188px",
            "offsetStart": "2px",
            "backgroundColor": "#800080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "ORDER",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "15px"
              }
            ],
            "borderWidth": "1px",
            "borderColor": "#00FFFF",
            "cornerRadius": "5px",
            "width": "76px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "188px",
            "offsetStart": "75px",
            "backgroundColor": "#0000FF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": []
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://www.blackxperience.com/assets/blackattitude/blacktips//cover-wa-300x300.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "height": "20px",
            "width": "20px",
            "cornerRadius": "100px",
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQBeiKDJTqSrl0DE7K8pIaNYe1uUsXNVqz9dg&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "height": "20px",
            "width": "20px",
            "position": "absolute",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "borderColor": "#FFFF00",
            "offsetTop": "124px",
            "offsetStart": "35px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://play-lh.googleusercontent.com/74iMObG1vsR3Kfm82RjERFhf99QFMNIY211oMvN636_gULghbRBMjpVFTjOK36oxCbs",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "70px",
            "height": "20px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRK_yDc42L7ssYuvce24MqTgvesOvYZgQIi8Q&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "100px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTBtVrDomP1KCahV0TSV9hITha-PhnvetHd0g&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "130px"
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#FFFF00",
        "cornerRadius": "10px",
        "borderWidth": "2px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~linux.1"
        }
      }
    }
  ]
}
}
                         cl.postTemplate(to, data)                           

            if msg.contentType == 6:
             if wait["responGc1"] == True:
                 a = cl.getContact(sender)
                 if msg.toType == 2:
                     b = msg.contentMetadata['GC_EVT_TYPE']
                     c = msg.contentMetadata["GC_MEDIA_TYPE"] 
                     if c == "VIDEO" and b == "E":
                         tz = pytz.timezone("Asia/Jakarta")
                         timeNow = datetime.now(tz=tz)
                         cl.getGroup(to).name
                         cl.getContact(msg._from).displayName                            
                         data = {
                                        "type": "flex",
                                        "altText": "TEAM TERMUX 01",
                                        "contents": {

   "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcT67I6CBmlnNYe80zaxsXI4N3jUrQHVlakwHQ&usqp=CAU",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "NOTIFCALL GRUP",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "28px"
              }
            ],
            "borderColor": "#00FFFF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "150px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "2px",
            "offsetStart": "3px",
            "backgroundColor": "#8B0000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": " "+ datetime.strftime(timeNow,'%H:%M:%S'),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "70px",
            "height": "20px",
            "offsetTop": "26px",
            "offsetStart": "2px",
            "backgroundColor": "#008000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": " "+ datetime.strftime(timeNow,'%Y-%m-%d'),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "cornerRadius": "5px",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "width": "75px",
            "height": "20px",
            "offsetTop": "26px",
            "offsetStart": "78px",
            "backgroundColor": "#0000FF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "borderColor": "#FF1493",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "151px",
            "height": "77px",
            "offsetTop": "50px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(msg._from).pictureStatus),
                "size": "full",
                "aspectMode": "cover",
                "aspectRatio": "2:1"
              }
            ],
            "position": "absolute",
            "borderColor": "#00FF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "height": "75px",
            "width": "149px",
            "offsetTop": "51px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": []
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "151px",
            "height": "30px",
            "offsetTop": "130px",
            "offsetStart": "2px",
            "backgroundColor": "#8B0000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://www.blackxperience.com/assets/blackattitude/blacktips//cover-wa-300x300.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "25px",
            "height": "25px",
            "position": "absolute",
            "offsetTop": "133px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRqdcAKxaEaPuGvM_wanEFxAJsknAkQJo11Vg&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "25px",
            "height": "25px",
            "position": "absolute",
            "offsetTop": "133px",
            "offsetStart": "35px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://media.cdnandroid.com/item_images/146592/imagen-autorap-by-smule-0big.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "25px",
            "height": "25px",
            "position": "absolute",
            "offsetTop": "133px",
            "offsetStart": "65px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://img.utdstc.com/icons/facebook-android.png:l",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "25px",
            "height": "25px",
            "position": "absolute",
            "offsetTop": "133px",
            "offsetStart": "95px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSSj_Wod4iOqe8RLGTR6-XycscxAi21wSGehA&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "height": "25px",
            "width": "25px",
            "position": "absolute",
            "offsetTop": "133px",
            "offsetStart": "125px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "✬  {}".format(cl.getContact(mid).displayName),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "150px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "162px",
            "offsetStart": "2px",
            "backgroundColor": "#800080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "borderColor": "#FF00FF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "150px",
            "height": "47px",
            "offsetTop": "185px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Kenapa Turun Udah Dapet Tikungan Yah",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "6px",
                "offsetStart": "9px",
                "wrap": True,
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "position": "absolute",
            "width": "148px",
            "height": "45px",
            "offsetTop": "186px",
            "offsetStart": "4px",
            "backgroundColor": "#008000",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "http://line.me/ti/p/~linux.1"
            }
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#FF1493",
        "borderWidth": "2px",
        "cornerRadius": "10px"
      }
    },
  {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://media.suara.com/pictures/653x366/2015/04/17/o_19j3m1hgthf63ni1h951v366r6a.jpg",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "NOTIFCALL GRUP",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "25px"
              }
            ],
            "width": "149px",
            "height": "20px",
            "borderColor": "#FF0000",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "position": "absolute",
            "offsetTop": "5px",
            "offsetStart": "3px",
            "backgroundColor": "#000080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(msg._from).pictureStatus),
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "150px",
            "height": "90px",
            "position": "absolute",
            "offsetTop": "30px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#FF0000",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "150px",
            "height": "40px",
            "position": "absolute",
            "offsetTop": "147px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Kenapa Turun Udah Dapet Tikungan Yah",
                "size": "xxs",
                "color": "#FFFFFF",
                "wrap": True,
                "offsetStart": "2px",
                "offsetTop": "2px"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "148px",
            "height": "38px",
            "position": "absolute",
            "offsetTop": "148px",
            "offsetStart": "3px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "SUPPORT  BY: Zulkifli",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "7px"
              }
            ],
            "borderColor": "#FF00FF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "150px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "210px",
            "offsetStart": "2px",
            "backgroundColor": "#2E8B57"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "CREATOR",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "6px"
              }
            ],
            "borderColor": "#FF00FF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "70px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "188px",
            "offsetStart": "2px",
            "backgroundColor": "#800080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "ORDER",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "15px"
              }
            ],
            "borderWidth": "1px",
            "borderColor": "#00FFFF",
            "cornerRadius": "5px",
            "width": "76px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "188px",
            "offsetStart": "75px",
            "backgroundColor": "#0000FF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": []
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://www.blackxperience.com/assets/blackattitude/blacktips//cover-wa-300x300.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "height": "20px",
            "width": "20px",
            "cornerRadius": "100px",
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQBeiKDJTqSrl0DE7K8pIaNYe1uUsXNVqz9dg&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "height": "20px",
            "width": "20px",
            "position": "absolute",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "borderColor": "#FFFF00",
            "offsetTop": "124px",
            "offsetStart": "35px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://play-lh.googleusercontent.com/74iMObG1vsR3Kfm82RjERFhf99QFMNIY211oMvN636_gULghbRBMjpVFTjOK36oxCbs",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "70px",
            "height": "20px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRK_yDc42L7ssYuvce24MqTgvesOvYZgQIi8Q&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "100px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTBtVrDomP1KCahV0TSV9hITha-PhnvetHd0g&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "130px"
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#FFFF00",
        "cornerRadius": "10px",
        "borderWidth": "2px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~linux.1"
        }
      }
    }
  ]
}
}
                         cl.postTemplate(to, data)
# NOTIFCALL GRUP EDITAN                         
            if msg.contentType == 6:
             if wait["responGc2"] == True:
                 a = cl.getContact(sender)
                 if msg.toType == 2:
                     b = msg.contentMetadata['GC_EVT_TYPE']
                     c = msg.contentMetadata["GC_MEDIA_TYPE"]                         
                     if c == "AUDIO" and b == "S":
                         tz = pytz.timezone("Asia/Jakarta")
                         timeNow = datetime.now(tz=tz)
                         cl.getGroup(to).name
                         cl.getContact(msg._from).displayName                            
                         data = {
                                        "type": "flex",
                                        "altText": "TEAM TERMUX 01",
                                        "contents": {

  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcT67I6CBmlnNYe80zaxsXI4N3jUrQHVlakwHQ&usqp=CAU",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "NOTIFCALL GRUP",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "28px"
              }
            ],
            "borderColor": "#00FFFF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "150px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "2px",
            "offsetStart": "3px",
            "backgroundColor": "#8B0000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": " "+ datetime.strftime(timeNow,'%H:%M:%S'),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "70px",
            "height": "20px",
            "offsetTop": "26px",
            "offsetStart": "2px",
            "backgroundColor": "#008000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": " "+ datetime.strftime(timeNow,'%Y-%m-%d'),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "cornerRadius": "5px",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "width": "75px",
            "height": "20px",
            "offsetTop": "26px",
            "offsetStart": "78px",
            "backgroundColor": "#0000FF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "borderColor": "#FF1493",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "151px",
            "height": "77px",
            "offsetTop": "50px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(msg._from).pictureStatus),
                "size": "full",
                "aspectMode": "cover",
                "aspectRatio": "2:1"
              }
            ],
            "position": "absolute",
            "borderColor": "#00FF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "height": "75px",
            "width": "149px",
            "offsetTop": "51px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": []
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "151px",
            "height": "30px",
            "offsetTop": "130px",
            "offsetStart": "2px",
            "backgroundColor": "#8B0000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://www.blackxperience.com/assets/blackattitude/blacktips//cover-wa-300x300.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "25px",
            "height": "25px",
            "position": "absolute",
            "offsetTop": "133px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRqdcAKxaEaPuGvM_wanEFxAJsknAkQJo11Vg&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "25px",
            "height": "25px",
            "position": "absolute",
            "offsetTop": "133px",
            "offsetStart": "35px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://media.cdnandroid.com/item_images/146592/imagen-autorap-by-smule-0big.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "25px",
            "height": "25px",
            "position": "absolute",
            "offsetTop": "133px",
            "offsetStart": "65px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://img.utdstc.com/icons/facebook-android.png:l",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "25px",
            "height": "25px",
            "position": "absolute",
            "offsetTop": "133px",
            "offsetStart": "95px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSSj_Wod4iOqe8RLGTR6-XycscxAi21wSGehA&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "height": "25px",
            "width": "25px",
            "position": "absolute",
            "offsetTop": "133px",
            "offsetStart": "125px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "✬  {}".format(cl.getContact(mid).displayName),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "150px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "162px",
            "offsetStart": "2px",
            "backgroundColor": "#800080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "borderColor": "#FF00FF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "150px",
            "height": "47px",
            "offsetTop": "185px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Wow Jones Naik Temenin Tuh Kasian Anak Orang",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "6px",
                "offsetStart": "9px",
                "wrap": True,
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "position": "absolute",
            "width": "148px",
            "height": "45px",
            "offsetTop": "186px",
            "offsetStart": "4px",
            "backgroundColor": "#008000",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "http://line.me/ti/p/~linux.1"
            }
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#FF1493",
        "borderWidth": "2px",
        "cornerRadius": "10px"
      }
    },
 {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://media.suara.com/pictures/653x366/2015/04/17/o_19j3m1hgthf63ni1h951v366r6a.jpg",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "NOTIFCALL GRUP",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "25px"
              }
            ],
            "width": "149px",
            "height": "20px",
            "borderColor": "#FF0000",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "position": "absolute",
            "offsetTop": "5px",
            "offsetStart": "3px",
            "backgroundColor": "#000080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(msg._from).pictureStatus),
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "150px",
            "height": "90px",
            "position": "absolute",
            "offsetTop": "30px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#FF0000",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "150px",
            "height": "40px",
            "position": "absolute",
            "offsetTop": "147px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Kenapa Turun Udah Dapet Tikungan Yah",
                "size": "xxs",
                "color": "#FFFFFF",
                "wrap": True,
                "offsetStart": "2px",
                "offsetTop": "2px"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "148px",
            "height": "38px",
            "position": "absolute",
            "offsetTop": "148px",
            "offsetStart": "3px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "SUPPORT  BY: Zulkifli",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "7px"
              }
            ],
            "borderColor": "#FF00FF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "150px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "210px",
            "offsetStart": "2px",
            "backgroundColor": "#2E8B57"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "CREATOR",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "6px"
              }
            ],
            "borderColor": "#FF00FF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "70px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "188px",
            "offsetStart": "2px",
            "backgroundColor": "#800080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "ORDER",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "15px"
              }
            ],
            "borderWidth": "1px",
            "borderColor": "#00FFFF",
            "cornerRadius": "5px",
            "width": "76px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "188px",
            "offsetStart": "75px",
            "backgroundColor": "#0000FF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": []
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://www.blackxperience.com/assets/blackattitude/blacktips//cover-wa-300x300.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "height": "20px",
            "width": "20px",
            "cornerRadius": "100px",
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQBeiKDJTqSrl0DE7K8pIaNYe1uUsXNVqz9dg&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "height": "20px",
            "width": "20px",
            "position": "absolute",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "borderColor": "#FFFF00",
            "offsetTop": "124px",
            "offsetStart": "35px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://play-lh.googleusercontent.com/74iMObG1vsR3Kfm82RjERFhf99QFMNIY211oMvN636_gULghbRBMjpVFTjOK36oxCbs",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "70px",
            "height": "20px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRK_yDc42L7ssYuvce24MqTgvesOvYZgQIi8Q&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "100px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTBtVrDomP1KCahV0TSV9hITha-PhnvetHd0g&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "130px"
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#FFFF00",
        "cornerRadius": "10px",
        "borderWidth": "2px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~linux.1"
        }
      }
    }
  ]
}
}
                         cl.postTemplate(to, data)
            if msg.contentType == 6:
             if wait["responGc3"] == True:
                 a = cl.getContact(sender)
                 if msg.toType == 2:
                     b = msg.contentMetadata['GC_EVT_TYPE']
                     c = msg.contentMetadata["GC_MEDIA_TYPE"]                         
                     if c == "AUDIO" and b == "E":
                         tz = pytz.timezone("Asia/Jakarta")
                         timeNow = datetime.now(tz=tz)
                         cl.getGroup(to).name
                         cl.getContact(msg._from).displayName                            
                         data = {
                                        "type": "flex",
                                        "altText": "TEAM TERMUX 01",
                                        "contents": {

   "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcT67I6CBmlnNYe80zaxsXI4N3jUrQHVlakwHQ&usqp=CAU",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "NOTIFCALL GRUP",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "28px"
              }
            ],
            "borderColor": "#00FFFF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "150px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "2px",
            "offsetStart": "3px",
            "backgroundColor": "#8B0000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": " "+ datetime.strftime(timeNow,'%H:%M:%S'),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "70px",
            "height": "20px",
            "offsetTop": "26px",
            "offsetStart": "2px",
            "backgroundColor": "#008000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": " "+ datetime.strftime(timeNow,'%Y-%m-%d'),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "cornerRadius": "5px",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "width": "75px",
            "height": "20px",
            "offsetTop": "26px",
            "offsetStart": "78px",
            "backgroundColor": "#0000FF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "borderColor": "#FF1493",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "151px",
            "height": "77px",
            "offsetTop": "50px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(msg._from).pictureStatus),
                "size": "full",
                "aspectMode": "cover",
                "aspectRatio": "2:1"
              }
            ],
            "position": "absolute",
            "borderColor": "#00FF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "height": "75px",
            "width": "149px",
            "offsetTop": "51px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": []
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "151px",
            "height": "30px",
            "offsetTop": "130px",
            "offsetStart": "2px",
            "backgroundColor": "#8B0000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://www.blackxperience.com/assets/blackattitude/blacktips//cover-wa-300x300.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "25px",
            "height": "25px",
            "position": "absolute",
            "offsetTop": "133px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRqdcAKxaEaPuGvM_wanEFxAJsknAkQJo11Vg&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "25px",
            "height": "25px",
            "position": "absolute",
            "offsetTop": "133px",
            "offsetStart": "35px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://media.cdnandroid.com/item_images/146592/imagen-autorap-by-smule-0big.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "25px",
            "height": "25px",
            "position": "absolute",
            "offsetTop": "133px",
            "offsetStart": "65px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://img.utdstc.com/icons/facebook-android.png:l",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "25px",
            "height": "25px",
            "position": "absolute",
            "offsetTop": "133px",
            "offsetStart": "95px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSSj_Wod4iOqe8RLGTR6-XycscxAi21wSGehA&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "height": "25px",
            "width": "25px",
            "position": "absolute",
            "offsetTop": "133px",
            "offsetStart": "125px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "✬  {}".format(cl.getContact(mid).displayName),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "150px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "162px",
            "offsetStart": "2px",
            "backgroundColor": "#800080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "borderColor": "#FF00FF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "150px",
            "height": "47px",
            "offsetTop": "185px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Kenapa Turun Udah Dapet Tikungan Yah",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "6px",
                "offsetStart": "9px",
                "wrap": True,
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "position": "absolute",
            "width": "148px",
            "height": "45px",
            "offsetTop": "186px",
            "offsetStart": "4px",
            "backgroundColor": "#008000",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "http://line.me/ti/p/~linux.1"
            }
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#FF1493",
        "borderWidth": "2px",
        "cornerRadius": "10px"
      }
    },
 {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://media.suara.com/pictures/653x366/2015/04/17/o_19j3m1hgthf63ni1h951v366r6a.jpg",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "NOTIFCALL GRUP",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "25px"
              }
            ],
            "width": "149px",
            "height": "20px",
            "borderColor": "#FF0000",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "position": "absolute",
            "offsetTop": "5px",
            "offsetStart": "3px",
            "backgroundColor": "#000080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(msg._from).pictureStatus),
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "150px",
            "height": "90px",
            "position": "absolute",
            "offsetTop": "30px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#FF0000",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "150px",
            "height": "40px",
            "position": "absolute",
            "offsetTop": "147px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Kenapa Turun Udah Dapet Tikungan Yah",
                "size": "xxs",
                "color": "#FFFFFF",
                "wrap": True,
                "offsetStart": "2px",
                "offsetTop": "2px"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "148px",
            "height": "38px",
            "position": "absolute",
            "offsetTop": "148px",
            "offsetStart": "3px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "SUPPORT  BY: Zulkifli",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "7px"
              }
            ],
            "borderColor": "#FF00FF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "150px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "210px",
            "offsetStart": "2px",
            "backgroundColor": "#2E8B57"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "CREATOR",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "6px"
              }
            ],
            "borderColor": "#FF00FF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "70px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "188px",
            "offsetStart": "2px",
            "backgroundColor": "#800080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "ORDER",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "15px"
              }
            ],
            "borderWidth": "1px",
            "borderColor": "#00FFFF",
            "cornerRadius": "5px",
            "width": "76px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "188px",
            "offsetStart": "75px",
            "backgroundColor": "#0000FF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": []
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://www.blackxperience.com/assets/blackattitude/blacktips//cover-wa-300x300.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "height": "20px",
            "width": "20px",
            "cornerRadius": "100px",
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQBeiKDJTqSrl0DE7K8pIaNYe1uUsXNVqz9dg&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "height": "20px",
            "width": "20px",
            "position": "absolute",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "borderColor": "#FFFF00",
            "offsetTop": "124px",
            "offsetStart": "35px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://play-lh.googleusercontent.com/74iMObG1vsR3Kfm82RjERFhf99QFMNIY211oMvN636_gULghbRBMjpVFTjOK36oxCbs",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "70px",
            "height": "20px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRK_yDc42L7ssYuvce24MqTgvesOvYZgQIi8Q&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "100px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTBtVrDomP1KCahV0TSV9hITha-PhnvetHd0g&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "130px"
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#FFFF00",
        "cornerRadius": "10px",
        "borderWidth": "2px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~linux.1"
        }
      }
    }
  ]
}
}
                         cl.postTemplate(to, data)
            if msg.contentType == 6:
             if wait["responGc4"] == True:
                 a = cl.getContact(sender)
                 if msg.toType == 2:
                     b = msg.contentMetadata['GC_EVT_TYPE']
                     c = msg.contentMetadata["GC_MEDIA_TYPE"]                         
                     if c == "LIVE" and b == "S":
                         tz = pytz.timezone("Asia/Jakarta")
                         timeNow = datetime.now(tz=tz)
                         cl.getGroup(to).name
                         cl.getContact(msg._from).displayName                            
                         data = {
                                        "type": "flex",
                                        "altText": "TEAM TERMUX 01",
                                        "contents": {

  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcT67I6CBmlnNYe80zaxsXI4N3jUrQHVlakwHQ&usqp=CAU",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "NOTIFCALL GRUP",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "28px"
              }
            ],
            "borderColor": "#00FFFF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "150px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "2px",
            "offsetStart": "3px",
            "backgroundColor": "#8B0000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": " "+ datetime.strftime(timeNow,'%H:%M:%S'),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "70px",
            "height": "20px",
            "offsetTop": "26px",
            "offsetStart": "2px",
            "backgroundColor": "#008000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": " "+ datetime.strftime(timeNow,'%Y-%m-%d'),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "cornerRadius": "5px",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "width": "75px",
            "height": "20px",
            "offsetTop": "26px",
            "offsetStart": "78px",
            "backgroundColor": "#0000FF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "borderColor": "#FF1493",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "151px",
            "height": "77px",
            "offsetTop": "50px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(msg._from).pictureStatus),
                "size": "full",
                "aspectMode": "cover",
                "aspectRatio": "2:1"
              }
            ],
            "position": "absolute",
            "borderColor": "#00FF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "height": "75px",
            "width": "149px",
            "offsetTop": "51px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": []
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "151px",
            "height": "30px",
            "offsetTop": "130px",
            "offsetStart": "2px",
            "backgroundColor": "#8B0000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://www.blackxperience.com/assets/blackattitude/blacktips//cover-wa-300x300.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "25px",
            "height": "25px",
            "position": "absolute",
            "offsetTop": "133px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRqdcAKxaEaPuGvM_wanEFxAJsknAkQJo11Vg&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "25px",
            "height": "25px",
            "position": "absolute",
            "offsetTop": "133px",
            "offsetStart": "35px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://media.cdnandroid.com/item_images/146592/imagen-autorap-by-smule-0big.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "25px",
            "height": "25px",
            "position": "absolute",
            "offsetTop": "133px",
            "offsetStart": "65px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://img.utdstc.com/icons/facebook-android.png:l",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "25px",
            "height": "25px",
            "position": "absolute",
            "offsetTop": "133px",
            "offsetStart": "95px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSSj_Wod4iOqe8RLGTR6-XycscxAi21wSGehA&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "height": "25px",
            "width": "25px",
            "position": "absolute",
            "offsetTop": "133px",
            "offsetStart": "125px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "✬  {}".format(cl.getContact(mid).displayName),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "150px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "162px",
            "offsetStart": "2px",
            "backgroundColor": "#800080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "borderColor": "#FF00FF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "150px",
            "height": "47px",
            "offsetTop": "185px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Wow Jones Naik Temenin Tuh Kasian Anak Orang",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "6px",
                "offsetStart": "9px",
                "wrap": True,
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "position": "absolute",
            "width": "148px",
            "height": "45px",
            "offsetTop": "186px",
            "offsetStart": "4px",
            "backgroundColor": "#008000",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "http://line.me/ti/p/~linux.1"
            }
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#FF1493",
        "borderWidth": "2px",
        "cornerRadius": "10px"
      }
    },
 {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://media.suara.com/pictures/653x366/2015/04/17/o_19j3m1hgthf63ni1h951v366r6a.jpg",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "NOTIFCALL GRUP",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "25px"
              }
            ],
            "width": "149px",
            "height": "20px",
            "borderColor": "#FF0000",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "position": "absolute",
            "offsetTop": "5px",
            "offsetStart": "3px",
            "backgroundColor": "#000080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(msg._from).pictureStatus),
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "150px",
            "height": "90px",
            "position": "absolute",
            "offsetTop": "30px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#FF0000",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "150px",
            "height": "40px",
            "position": "absolute",
            "offsetTop": "147px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Kenapa Turun Udah Dapet Tikungan Yah",
                "size": "xxs",
                "color": "#FFFFFF",
                "wrap": True,
                "offsetStart": "2px",
                "offsetTop": "2px"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "148px",
            "height": "38px",
            "position": "absolute",
            "offsetTop": "148px",
            "offsetStart": "3px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "SUPPORT  BY: Zulkifli",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "7px"
              }
            ],
            "borderColor": "#FF00FF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "150px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "210px",
            "offsetStart": "2px",
            "backgroundColor": "#2E8B57"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "CREATOR",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "6px"
              }
            ],
            "borderColor": "#FF00FF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "70px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "188px",
            "offsetStart": "2px",
            "backgroundColor": "#800080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "ORDER",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "15px"
              }
            ],
            "borderWidth": "1px",
            "borderColor": "#00FFFF",
            "cornerRadius": "5px",
            "width": "76px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "188px",
            "offsetStart": "75px",
            "backgroundColor": "#0000FF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": []
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://www.blackxperience.com/assets/blackattitude/blacktips//cover-wa-300x300.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "height": "20px",
            "width": "20px",
            "cornerRadius": "100px",
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQBeiKDJTqSrl0DE7K8pIaNYe1uUsXNVqz9dg&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "height": "20px",
            "width": "20px",
            "position": "absolute",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "borderColor": "#FFFF00",
            "offsetTop": "124px",
            "offsetStart": "35px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://play-lh.googleusercontent.com/74iMObG1vsR3Kfm82RjERFhf99QFMNIY211oMvN636_gULghbRBMjpVFTjOK36oxCbs",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "70px",
            "height": "20px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRK_yDc42L7ssYuvce24MqTgvesOvYZgQIi8Q&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "100px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTBtVrDomP1KCahV0TSV9hITha-PhnvetHd0g&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "130px"
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#FFFF00",
        "cornerRadius": "10px",
        "borderWidth": "2px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~linux.1"
        }
      }
    }
  ]
}
}
                         cl.postTemplate(to, data)
            if msg.contentType == 6:
             if wait["responGc5"] == True:
                 a = cl.getContact(sender)
                 if msg.toType == 2:
                     b = msg.contentMetadata['GC_EVT_TYPE']
                     c = msg.contentMetadata["GC_MEDIA_TYPE"]                         
                     if c == "LIVE" and b == "E":
                         tz = pytz.timezone("Asia/Jakarta")
                         timeNow = datetime.now(tz=tz)
                         cl.getGroup(to).name
                         cl.getContact(msg._from).displayName                            
                         data = {
                                        "type": "flex",
                                        "altText": "TEAM TERMUX 01",
                                        "contents": {

   "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcT67I6CBmlnNYe80zaxsXI4N3jUrQHVlakwHQ&usqp=CAU",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "NOTIFCALL GRUP",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "28px"
              }
            ],
            "borderColor": "#00FFFF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "150px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "2px",
            "offsetStart": "3px",
            "backgroundColor": "#8B0000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": " "+ datetime.strftime(timeNow,'%H:%M:%S'),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "70px",
            "height": "20px",
            "offsetTop": "26px",
            "offsetStart": "2px",
            "backgroundColor": "#008000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": " "+ datetime.strftime(timeNow,'%Y-%m-%d'),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "cornerRadius": "5px",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "width": "75px",
            "height": "20px",
            "offsetTop": "26px",
            "offsetStart": "78px",
            "backgroundColor": "#0000FF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "borderColor": "#FF1493",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "151px",
            "height": "77px",
            "offsetTop": "50px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(msg._from).pictureStatus),
                "size": "full",
                "aspectMode": "cover",
                "aspectRatio": "2:1"
              }
            ],
            "position": "absolute",
            "borderColor": "#00FF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "height": "75px",
            "width": "149px",
            "offsetTop": "51px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": []
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "151px",
            "height": "30px",
            "offsetTop": "130px",
            "offsetStart": "2px",
            "backgroundColor": "#8B0000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://www.blackxperience.com/assets/blackattitude/blacktips//cover-wa-300x300.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "25px",
            "height": "25px",
            "position": "absolute",
            "offsetTop": "133px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRqdcAKxaEaPuGvM_wanEFxAJsknAkQJo11Vg&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "25px",
            "height": "25px",
            "position": "absolute",
            "offsetTop": "133px",
            "offsetStart": "35px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://media.cdnandroid.com/item_images/146592/imagen-autorap-by-smule-0big.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "25px",
            "height": "25px",
            "position": "absolute",
            "offsetTop": "133px",
            "offsetStart": "65px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://img.utdstc.com/icons/facebook-android.png:l",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "25px",
            "height": "25px",
            "position": "absolute",
            "offsetTop": "133px",
            "offsetStart": "95px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSSj_Wod4iOqe8RLGTR6-XycscxAi21wSGehA&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "height": "25px",
            "width": "25px",
            "position": "absolute",
            "offsetTop": "133px",
            "offsetStart": "125px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "✬  {}".format(cl.getContact(mid).displayName),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "150px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "162px",
            "offsetStart": "2px",
            "backgroundColor": "#800080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "borderColor": "#FF00FF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "150px",
            "height": "47px",
            "offsetTop": "185px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Kenapa Turun Udah Dapet Tikungan Yah",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "6px",
                "offsetStart": "9px",
                "wrap": True,
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "position": "absolute",
            "width": "148px",
            "height": "45px",
            "offsetTop": "186px",
            "offsetStart": "4px",
            "backgroundColor": "#008000",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "http://line.me/ti/p/~linux.1"
            }
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#FF1493",
        "borderWidth": "2px",
        "cornerRadius": "10px"
      }
    },
  {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://media.suara.com/pictures/653x366/2015/04/17/o_19j3m1hgthf63ni1h951v366r6a.jpg",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "NOTIFCALL GRUP",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "25px"
              }
            ],
            "width": "149px",
            "height": "20px",
            "borderColor": "#FF0000",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "position": "absolute",
            "offsetTop": "5px",
            "offsetStart": "3px",
            "backgroundColor": "#000080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(msg._from).pictureStatus),
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "150px",
            "height": "90px",
            "position": "absolute",
            "offsetTop": "30px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#FF0000",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "150px",
            "height": "40px",
            "position": "absolute",
            "offsetTop": "147px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Kenapa Turun Udah Dapet Tikungan Yah",
                "size": "xxs",
                "color": "#FFFFFF",
                "wrap": True,
                "offsetStart": "2px",
                "offsetTop": "2px"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "148px",
            "height": "38px",
            "position": "absolute",
            "offsetTop": "148px",
            "offsetStart": "3px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "SUPPORT  BY: Zulkifli",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "7px"
              }
            ],
            "borderColor": "#FF00FF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "150px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "210px",
            "offsetStart": "2px",
            "backgroundColor": "#2E8B57"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "CREATOR",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "6px"
              }
            ],
            "borderColor": "#FF00FF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "70px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "188px",
            "offsetStart": "2px",
            "backgroundColor": "#800080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "ORDER",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "15px"
              }
            ],
            "borderWidth": "1px",
            "borderColor": "#00FFFF",
            "cornerRadius": "5px",
            "width": "76px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "188px",
            "offsetStart": "75px",
            "backgroundColor": "#0000FF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": []
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://www.blackxperience.com/assets/blackattitude/blacktips//cover-wa-300x300.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "height": "20px",
            "width": "20px",
            "cornerRadius": "100px",
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQBeiKDJTqSrl0DE7K8pIaNYe1uUsXNVqz9dg&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "height": "20px",
            "width": "20px",
            "position": "absolute",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "borderColor": "#FFFF00",
            "offsetTop": "124px",
            "offsetStart": "35px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://play-lh.googleusercontent.com/74iMObG1vsR3Kfm82RjERFhf99QFMNIY211oMvN636_gULghbRBMjpVFTjOK36oxCbs",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "70px",
            "height": "20px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRK_yDc42L7ssYuvce24MqTgvesOvYZgQIi8Q&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "100px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTBtVrDomP1KCahV0TSV9hITha-PhnvetHd0g&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "124px",
            "offsetStart": "130px"
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#FFFF00",
        "cornerRadius": "10px",
        "borderWidth": "2px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~linux.1"
        }
      }
    }
  ]
}
}
                         cl.postTemplate(to, data)
                         Zul: Vork      

        if op.type == 13 or op.type == 124:
            if wait["autoJoin"] and mid in op.param3:
                group = cl.getGroup(op.param1)
                group.notificationDisabled = False
                cl.acceptGroupInvitation(op.param1)
                cl.updateGroup(group)
                tz = pytz.timezone("Asia/Jakarta")
                timeNow = datetime.now(tz=tz)
                ginfo = cl.getGroup(op.param1)
                data = {

  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcT67I6CBmlnNYe80zaxsXI4N3jUrQHVlakwHQ&usqp=CAU",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "AUTOJOIN BOTS",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "28px"
              }
            ],
            "borderColor": "#00FF00",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "150px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "2px",
            "offsetStart": "3px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": " "+ datetime.strftime(timeNow,'%H:%M:%S'),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "70px",
            "height": "20px",
            "offsetTop": "26px",
            "offsetStart": "2px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": " "+ datetime.strftime(timeNow,'%Y-%m-%d'),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "cornerRadius": "5px",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "width": "75px",
            "height": "20px",
            "offsetTop": "26px",
            "offsetStart": "78px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(op.param2).pictureStatus),
                "size": "full",
                "aspectMode": "cover",
                "aspectRatio": "2:3"
              }
            ],
            "position": "absolute",
            "borderColor": "#FF1493",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "70px",
            "height": "77px",
            "offsetTop": "50px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": []
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "151px",
            "height": "30px",
            "offsetTop": "153px",
            "offsetStart": "2px",
            "backgroundColor": "#FF0000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://www.blackxperience.com/assets/blackattitude/blacktips//cover-wa-300x300.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "25px",
            "height": "25px",
            "position": "absolute",
            "offsetTop": "156px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRqdcAKxaEaPuGvM_wanEFxAJsknAkQJo11Vg&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "25px",
            "height": "25px",
            "position": "absolute",
            "offsetTop": "156px",
            "offsetStart": "35px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://media.cdnandroid.com/item_images/146592/imagen-autorap-by-smule-0big.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "25px",
            "height": "25px",
            "position": "absolute",
            "offsetTop": "156px",
            "offsetStart": "65px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://img.utdstc.com/icons/facebook-android.png:l",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "25px",
            "height": "25px",
            "position": "absolute",
            "offsetTop": "156px",
            "offsetStart": "95px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSSj_Wod4iOqe8RLGTR6-XycscxAi21wSGehA&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "height": "25px",
            "width": "25px",
            "position": "absolute",
            "offsetTop": "156px",
            "offsetStart": "125px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "borderColor": "#FF00FF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "150px",
            "height": "47px",
            "offsetTop": "185px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Terima Kasih Sudah Undang Kami Salam Kenal Yah",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "6px",
                "offsetStart": "2px",
                "wrap": True,
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "position": "absolute",
            "width": "148px",
            "height": "45px",
            "offsetTop": "186px",
            "offsetStart": "4px",
            "backgroundColor": "#800080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getGroup(op.param1).pictureStatus),
                "size": "full",
                "aspectMode": "cover",
                "aspectRatio": "2:3"
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "height": "75px",
            "offsetTop": "50px",
            "offsetStart": "80px",
            "width": "73px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "🌺  {}".format(cl.getContact(mid).displayName),
                "color": "#FFFFFF",
                "size": "xxs",
                "offsetStart": "2px",
                "offsetTop": "2px"
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "150px",
            "height": "20px",
            "offsetTop": "130px",
            "offsetStart": "2px",
            "backgroundColor": "#008080"
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#FF0000",
        "borderWidth": "2px",
        "cornerRadius": "10px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "line://nv/profilePopup/mid=u6459106c8251205f79c2f037cd99b6a4"
        }
      }
    },
 {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcT67I6CBmlnNYe80zaxsXI4N3jUrQHVlakwHQ&usqp=CAU",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "AUTOJOIN BOTS",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "28px"
              }
            ],
            "borderColor": "#00FF00",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "150px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "2px",
            "offsetStart": "3px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": " "+ datetime.strftime(timeNow,'%H:%M:%S'),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "70px",
            "height": "20px",
            "offsetTop": "26px",
            "offsetStart": "2px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": " "+ datetime.strftime(timeNow,'%Y-%m-%d'),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "cornerRadius": "5px",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "width": "75px",
            "height": "20px",
            "offsetTop": "26px",
            "offsetStart": "78px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(op.param2).pictureStatus),
                "size": "full",
                "aspectMode": "cover",
                "aspectRatio": "2:3"
              }
            ],
            "position": "absolute",
            "borderColor": "#FF1493",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "70px",
            "height": "77px",
            "offsetTop": "50px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": []
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "151px",
            "height": "30px",
            "offsetTop": "153px",
            "offsetStart": "2px",
            "backgroundColor": "#FF0000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://www.blackxperience.com/assets/blackattitude/blacktips//cover-wa-300x300.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "25px",
            "height": "25px",
            "position": "absolute",
            "offsetTop": "156px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRqdcAKxaEaPuGvM_wanEFxAJsknAkQJo11Vg&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "25px",
            "height": "25px",
            "position": "absolute",
            "offsetTop": "156px",
            "offsetStart": "35px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://media.cdnandroid.com/item_images/146592/imagen-autorap-by-smule-0big.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "25px",
            "height": "25px",
            "position": "absolute",
            "offsetTop": "156px",
            "offsetStart": "65px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://img.utdstc.com/icons/facebook-android.png:l",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "25px",
            "height": "25px",
            "position": "absolute",
            "offsetTop": "156px",
            "offsetStart": "95px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSSj_Wod4iOqe8RLGTR6-XycscxAi21wSGehA&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "height": "25px",
            "width": "25px",
            "position": "absolute",
            "offsetTop": "156px",
            "offsetStart": "125px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "borderColor": "#FF00FF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "150px",
            "height": "47px",
            "offsetTop": "185px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Terima Kasih Sudah Undang Kami Salam Kenal Yah",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "6px",
                "offsetStart": "2px",
                "wrap": True,
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "position": "absolute",
            "width": "148px",
            "height": "45px",
            "offsetTop": "186px",
            "offsetStart": "4px",
            "backgroundColor": "#800080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getGroup(op.param1).pictureStatus),
                "size": "full",
                "aspectMode": "cover",
                "aspectRatio": "2:3"
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "height": "75px",
            "offsetTop": "50px",
            "offsetStart": "80px",
            "width": "73px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "🌺  {}".format(cl.getContact(mid).displayName),
                "color": "#FFFFFF",
                "size": "xxs",
                "offsetStart": "2px",
                "offsetTop": "2px"
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "150px",
            "height": "20px",
            "offsetTop": "130px",
            "offsetStart": "2px",
            "backgroundColor": "#008080"
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#FF0000",
        "borderWidth": "2px",
        "cornerRadius": "10px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "line://nv/profilePopup/mid=u6459106c8251205f79c2f037cd99b6a4"
        }
      }
    }
  ]
}

                cl.postFlex(op.param1, data)


        if op.type == 0:
            return
        if op.type == 5:
            if wait["autoAdd"] == True:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    if (wait["message1"] in [" "," ","\n",None]):
                        pass
                    else:
                        cl.sendMessage(op.param1, wait["message1"])

        if op.type == 32 or op.type == 126:
            if wait["backup"] == True:
              if op.param3 in Bots:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    try:
                        if op.param3 not in wait["blacklist"]:
                            cl.kickoutFromGroup(op.param1,[op.param2])
                            cl.inviteIntoGroup(op.param1,[op.param3])
                    except:
                    	pass
                return

        if op.type == 19 or op.type == 133:
            if mid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in creator:
                    pass
                if op.param2 in admin:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        cl.acceptGroupInvitation(op.param1)
                        cl.inviteIntoGroup(op.param1,[op.param3])
                        cl.kickoutFromGroup(op.param1,[op.param2])
                    except:
                    	pass
                return

        if op.type == 19 or op.type == 32:
            if op.param3 in creator:
              if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                cl.findAndAddContactsByMid(op.param3)
                cl.inviteIntoGroup(op.param1,[op.param3])
                cl.kickoutFromGroup(op.param1,[op.param2])
                wait["blacklist"][op.param2] = True

        if op.type == 19 or op.type == 32:
            if op.param3 in admin:
              if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                cl.findAndAddContactsByMid(op.param3)
                cl.inviteIntoGroup(op.param1,[op.param3])
                cl.kickoutFromGroup(op.param1,[op.param2])
                wait["blacklist"][op.param2] = True

        if op.type == 55:            
            try:
                if op.param1 in read["readPoint"]:
                    if op.param2 in read["readMember"][op.param1]:
                        pass
                    else:
                        read["readMember"][op.param1][op.param2] = True
                else:
                   pass
            except:
                pass
                
        if op.type == 55:
            if op.param2 in wait["blacklist"]:
               try:
                   cl.kickoutFromGroup(op.param1,[op.param2])
                   cl.sendMessage(op.param1,"Sia Anjing Asup Backlist Ainx")
               except:
                   pass

        if op.type == 65:
            if wait["Unsend"] == True:
                try:
                    at = op.param1
                    msg_id = op.param2
                    if msg_id in msg_dict:
                        if msg_dict[msg_id]["from"]:
                           if msg_dict[msg_id]["text"] == 'ɢᴀᴍʙᴀʀʏᴀ ɪʟᴀɴɢ':
                                ginfo = cl.getGroup(at)
                                ika = cl.getContact(msg_dict[msg_id]["from"])
                                zx = ""
                                zxc = ""
                                zx2 = []
                                xpesan =  "ᴘᴇsᴀɴ ᴅɪʜᴀᴘᴜs\nᴘᴇɴɢɪʀɪᴍ: "
                                ret_ = "ɴᴀᴍᴀ ɢʀᴜᴘ: {}".format(str(ginfo.name))
                                ret_ += "\nᴊᴀᴍ sʜᴀʀᴇ: {}".format(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"])))
                                ik = str(ika.displayName)
                                pesan = ''
                                pesan2 = pesan+"@x \n"
                                xlen = str(len(zxc)+len(xpesan))
                                xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                zx = {'S':xlen, 'E':xlen2, 'M':ika.mid}
                                zx2.append(zx)
                                zxc += pesan2
                                text = xpesan + zxc + ret_ + ""
                                cl.sendMessage(at, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                           else:
                                ginfo = cl.getGroup(at)
                                ika = cl.getContact(msg_dict[msg_id]["from"])
                                ika1 = "🚹{}".format(str(ika.displayName))
                                ika2 = "🏠:{}".format(str(ginfo.name))
                                ika3 = "🕙{}".format(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"])))
                                seber = "「 ᴘᴇsᴀɴ ᴅɪʜᴀᴘᴜs 」\n{}".format(str(msg_dict[msg_id]["text"]))
                                data = {
                                        "type": "flex",
                                        "altText": "TEAM TERMUX 01",
                                        "contents": {
  "styles": {
    "body": {
      "backgroundColor": "#000000"
    },
    "footer": {
      "backgroundColor": "#2f2f4f"
    }
  },
  "type": "bubble",
 "size": "micro",
      "body": {
  "contents": [
      {
        "contents": [                   
            {            
            "type": "separator",
            "color": "#33ffff"            
      },
      {
        "type": "separator",
        "color": "#33ffff"  
      },
      {         
         "contents": [
          {
          "type": "separator",
          "color": "#33ffff"   
      },
      {
            "contents": [
              {
              "type": "image",
     "url": "https://stickershop.line-scdn.net/stickershop/v1/product/6332071/LINEStorePC/main.png;compress=true",
    "size": "xxs"
          },{
 "type": "text",
"text": "TEAM TERMUX 01",
"weight": "bold",
"color": "#ccff00",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "ȶɛǟʍ",
"weight": "bold",
"color": "#ccff00",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "ცơɬʂ ☬",
"weight": "bold",
"color": "#ccff00",
"size": "xxs",
"flex": 0
      },
      {
    "type": "image",
     "url": "https://stickershop.line-scdn.net/stickershop/v1/product/6332071/LINEStorePC/main.png;compress=true",
    "size": "xxs"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#33ffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#33ffff"
         },
         {
       "contents": [
         {
        "type": "separator",
        "color": "#33ffff"
         },
         {
            "text": "🔵🔵🔵",
            "size": "xxs",
            "color": "#FF9900",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#33ffff"
           },
             {
            "text": "🔵🔵🔵",
            "size": "xxs",
            "color": "#FF9900",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#33ffff"
           },
             {
            "text": "🔵🔵🔵",
            "size": "xxs",
            "color": "#FF9900",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"   
            },
         {
        "type": "separator",
        "color": "#33ffff"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#33ffff"
         },
         {
       "contents": [
          {
           "type": "separator",
           "color": "#33ffff"
          },
          {
          "url": "https://obs.line-scdn.net/{}".format(str(ika.pictureStatus)),
            "type": "image",
            "size": "xxs",
            "flex": 0
          },
          {
        "type": "separator",
        "color": "#33ffff"
      },
      {      
       "contents": [              
          {
"type": "text",
"text": ika1,
"weight": "bold",
"color": "#33ffff",
"align": "center",
"size": "xxs",
"flex": 0
},{
"type": "separator",
"color": "#33ffff"
},{
"type": "text",
"text": ika3, #"🕙"+ datetime.strftime(timeNow,'%H:%M:%S'+"🕙"),
"weight": "bold",
"color": "#ccffff",
#"align": "center",
"size": "xxs",
"flex": 0
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"
      },
      {
        "type": "separator",
        "color": "#33ffff"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"
      },
      {
        "type": "separator",
         "color": "#33ffff"
       },
       {     
       "contents": [           
         { 
           "type": "separator",
           "color": "#33ffff"
            },
           {
            "contents": [
              {
              "type": "separator",
           "color": "#33ffff"
            },
           {
          "type": "text",
"text": ika2, #"{}".format(cl.getContact(mid).displayName),
"weight": "bold",
"color": "#ffff00",
#"align": "center",
"size": "xxs",
"flex": 0
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#33ffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#33ffff"
         },
         {          
         "contents": [
         { 
           "type": "separator",
           "color": "#33ffff"
            },
           {
            "contents": [
              {
              "type": "separator",
           "color": "#33ffff"
            },
           {
          "text": seber,
           "size": "xxs",
       #   "align": "center",
           "color": "#00ff00",
           "wrap": True,
           "weight": "bold",
           "type": "text"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#33ffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#33ffff"
         },
         {
       "contents": [
         {
        "type": "separator",
        "color": "#33ffff"
         },
         {
            "text": "🔴??🔴",
            "size": "xxs",
            "color": "#FF9900",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#33ffff"
           },
             {
            "text": "🔴🔴🔴",
            "size": "xxs",
            "color": "#FF9900",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#33ffff"
           },
             {
            "text": "🔴🔴🔴",
            "size": "xxs",
            "color": "#FF9900",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"   
          },
         {
        "type": "separator",
        "color": "#33ffff"
         }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#33ffff"
         },
         {
      "contents": [
          {
            "type": "separator",
            "color": "#33ffff"
            },
             {
            "type": "image",
            "url": "https://i.ibb.co/ypkDngF/20190925-164247.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "https://youtube.com",
           }, 
            "flex": 1
          },
          {
          "type": "image",
            "url": "https://i.ibb.co/F0yX5Yt/20190925-164610.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "http://line.me/ti/p/~linux.1",             
           }, 
            "flex": 1            
          },
          {
          "type": "image",
            "url": "https://i.ibb.co/98RJkdy/20190925-164910.png", #chathttps://i.ibb.co/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/chat" #"http://line.me/ti/p/~greetolala999",
            },         
            "flex": 1          
            },
          {
          "type": "image",
            "url": "https://i.ibb.co/fvx0z0Q/20190925-164758.png", #smule
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "Https://smule.com/KSS_OFFICE",
            },         
            "flex": 1          
          },
          {
          "type": "image",
            "url": "https://i.ibb.co/nRKcLQN/20190925-165015.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/cameraRoll/multi"
            },
            "flex": 1
            },
            {
            "contents": [
            {
            "type": "image",
            "url": "https://scontent.fsoc2-1.fna.fbcdn.net/v/t1.0-9/118307602_311449039955034_3014889697638355733_o.jpg?_nc_cat=109&ccb=2&_nc_sid=8bfeb9&_nc_eui2=AeGcxvGk-N_q0HUUmaNCjSx0tRiK_G37QGq1GIr8bftAamH9v2pBfxCyI_jw-4F4vykAsqd-uBj4TxvljPkaqYba&_nc_ohc=i5sBqgZdPuEAX9zApKq&_nc_ht=scontent.fsoc2-1.fna&oh=bf0f6ece09166355bb99770c74372b73&oe=5FE6B922",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/timeline"
          },
            "flex": 1           
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#33ffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#33ffff"
        },{
        "contents": [         
              {
            "type": "separator",
            "color": "#33ffff"
            },
             {          
            "contents": [
               {
    "type": "image",
    "url": "https://stickershop.line-scdn.net/stickershop/v1/product/6332071/LINEStorePC/main.png;compress=true",
    "size": "xxs"
    },{
 "type": "text",
"text": "TEAM TERMUX 01",
"weight": "bold",
"color": "#ccff00",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "ȶɛǟʍ",
"weight": "bold",
"color": "#ccff00",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "ცơɬʂ ☬",
"weight": "bold",
"color": "#ccff00",
"size": "xxs",
"flex": 0
      },
      {
    "type": "image",
    "url": "https://stickershop.line-scdn.net/stickershop/v1/product/6332071/LINEStorePC/main.png;compress=true",
    "size": "xxs"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#33ffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator", #batas APK
        "color": "#33ffff"     
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "xs",
    "layout": "vertical"
  }
}
}
                                cl.postTemplate(at, data)
                                cl.sendImage(at, msg_dict[msg_id]["data"])
                        del msg_dict[msg_id]
                except Exception as e:
                    print(e)
        if op.type == 65:
            if wait["Unsend"] == True:
                try:
                    at = op.param1
                    msg_id = op.param2
                    if msg_id in msg_dict1:
                        if msg_dict1[msg_id]["from"]:
                                ginfo = cl.getGroup(at)
                                ryan = cl.getContact(msg_dict1[msg_id]["from"])
                                ret_ =  "╔══「✯sᴛɪᴄᴋᴇʀ ɪɴғᴏ✯」\n"
                                ret_ += "┣[]►🚹: {}".format(str(ryan.displayName))
                                ret_ += "\n┣[]►🏠: {}".format(str(ginfo.name))
                                ret_ += "\n┣[]►🕘: {}".format(dt_to_str(cTime_to_datetime(msg_dict1[msg_id]["createdTime"])))
                                ret_ += "\n╚══「✯ᴜɴsᴇɴᴅ ғɪɴɪsʜ✯」"
                                ret_ += "{}".format(str(msg_dict1[msg_id]["text"]))
                                sendFooter(at, str(ret_))
                                cl.sendImage(at, msg_dict1[msg_id]["data"])
                        del msg_dict1[msg_id]
                except Exception as e:
                    print(e)
        if op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                if msg.toType == 0:
                    if sender != cl.profile.mid:
                        to = sender
                    else:
                        to = receiver
                elif msg.toType == 1:
                    to = receiver
                elif msg.toType == 2:
                    to = receiver
                if msg.contentType == 0:
                    msg_dict[msg.id] = {"text": msg.text, "from": msg._from, "createdTime": msg.createdTime, "contentType": msg.contentType, "contentMetadata": msg.contentMetadata}
                if msg.contentType == 1:
                    path = cl.downloadObjectMsg(msg_id)
                    msg_dict[msg.id] = {"text":'ɢᴀᴍʙᴀʀʏᴀ ᴅɪʙᴀᴡᴀʜ',"data":path,"from":msg._from,"createdTime":msg.createdTime}
                if msg.contentType == 7:
                   stk_id = msg.contentMetadata["STKID"]
                   stk_ver = msg.contentMetadata["STKVER"]
                   pkg_id = msg.contentMetadata["STKPKGID"]
                   ret_ = "\n╔══「✯sᴛɪᴄᴋᴇʀ ɪɴғᴏ✯]"
                   ret_ += "\n┣[]►sᴛɪᴄᴋᴇʀ ɪᴅ: {}".format(stk_id)
                   ret_ += "\n┣[]►sᴛɪᴄᴋᴇʀ ᴠᴇʀsɪᴏɴ: {}".format(stk_ver)
                   ret_ += "\n┣[]►sᴛɪᴄᴋᴇʀ: {}".format(pkg_id)
                   ret_ += "\n┣[]►ᴜʀʟ:{}".format(pkg_id)
                   ret_ += "\n╚══「✯ᴜɴsᴇɴᴅ ғɪɴɪsʜ✯」"
                   query = int(stk_id)
                   if type(query) == int:
                            data = 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(query)+'/ANDROID/sticker.png'
                            path = cl.downloadFileURL(data)
                            msg_dict1[msg.id] = {"text":str(ret_),"data":path,"from":msg._from,"createdTime":msg.createdTime}
#===============================➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  
        if op.type == 17:
            if op.param1 in welcome:
                ginfo = cl.getGroup(op.param1)
             #   cl.updateGroup(group)
                contact = cl.getContact(op.param2)
                cover = cl.getProfileCoverURL(op.param2)
                welcomeMembers(op.param1, [op.param2])
                tz = pytz.timezone("Asia/Jakarta")
                timeNow = datetime.now(tz=tz)
                data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX 01",
                                       "contents": {
"type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTZg-QiWERGmh1VETXaeOiHcDAIgm1rF8k71A&usqp=CAU",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Welcome Grup",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetStart": "40px"
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "cornerRadius": "5px",
            "borderWidth": "2px",
            "width": "152px",
            "offsetStart": "2px",
            "offsetTop": "2px",
            "height": "20px",
            "backgroundColor": "#C71585"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEAM TERMUX 01",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetStart": "13px"
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "borderWidth": "2px",
            "cornerRadius": "5px",
            "offsetTop": "214px",
            "offsetStart": "2px",
            "width": "152px",
            "backgroundColor": "#C71585"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "."
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "borderWidth": "2px",
            "offsetTop": "25px",
            "offsetStart": "2px",
            "width": "152px",
            "cornerRadius": "10px",
            "height": "92px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(op.param2).pictureStatus),
                "size": "full",
                "aspectMode": "cover",
                "aspectRatio": "2:2"
              }
            ],
            "position": "absolute",
            "borderColor": "#00FF00",
            "borderWidth": "2px",
            "cornerRadius": "10px",
            "width": "149px",
            "offsetTop": "27px",
            "offsetStart": "4px",
            "height": "88px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "🚺{} ".format(cl.getContact(op.param2).displayName),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetStart": "10px"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "2px",
            "position": "absolute",
            "cornerRadius": "5px",
            "width": "150px",
            "offsetTop": "119px",
            "offsetStart": "2px",
            "backgroundColor": "#C71585",
            "height": "20px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "size": "full",
                "aspectMode": "cover",
                "aspectRatio": "2:2",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSktbf3ALAbjMxRN_nTge8Ewl41leYpORsYIw&usqp=CAU"
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "10px",
            "width": "33px",
            "height": "33px",
            "offsetTop": "143px",
            "offsetStart": "2px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "line://nv/timeline"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://media.cdnandroid.com/item_images/146592/imagen-autorap-by-smule-0big.jpg",
                "size": "full",
                "aspectMode": "cover",
                "aspectRatio": "2:2"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "10px",
            "borderWidth": "1px",
            "position": "absolute",
            "height": "33px",
            "width": "33px",
            "offsetTop": "143px",
            "offsetStart": "42px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "line://nv/cameraRoll/multi"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://www.facebook.com/images/fb_icon_325x325.png",
                "size": "full",
                "aspectRatio": "2:2",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "position": "absolute",
            "width": "33px",
            "height": "33px",
            "offsetTop": "143px",
            "cornerRadius": "10px",
            "offsetStart": "83px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "Https://smule.com/KSS_OFFICE"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQPY6QlUGRA-OlrBtRc99w88JsSHK4Jf2KHfw&usqp=CAU"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "10px",
            "position": "absolute",
            "width": "32px",
            "height": "32px",
            "borderWidth": "1px",
            "offsetTop": "143px",
            "offsetStart": "121px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "http://line.me/ti/p/~linux.1"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": wait["welcome"],
                "color": "#FFFFFF",
                "size": "xxs",
                "wrap": True,
                "offsetStart": "2px"
              }
            ],
            "borderColor": "#FFFF00",
            "position": "absolute",
            "offsetTop": "178px",
            "borderWidth": "2px",
            "offsetStart": "3px",
            "width": "150px",
            "height": "35px",
            "cornerRadius": "5px",
            "backgroundColor": "#C71585"
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#FFFF00",
        "borderWidth": "2px",
        "cornerRadius": "10px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "line://nv/profilePopup/mid=u6459106c8251205f79c2f037cd99b6a4"
        }
      }
    },
{
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTZg-QiWERGmh1VETXaeOiHcDAIgm1rF8k71A&usqp=CAU",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Welcome Grup",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetStart": "40px"
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "cornerRadius": "5px",
            "borderWidth": "2px",
            "width": "152px",
            "offsetStart": "2px",
            "offsetTop": "2px",
            "height": "20px",
            "backgroundColor": "#C71585"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEAM TERMUX 01",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetStart": "13px"
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "borderWidth": "2px",
            "cornerRadius": "5px",
            "offsetTop": "214px",
            "offsetStart": "2px",
            "width": "152px",
            "backgroundColor": "#C71585"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "."
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "borderWidth": "2px",
            "offsetTop": "25px",
            "offsetStart": "2px",
            "width": "152px",
            "cornerRadius": "10px",
            "height": "92px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(op.param2).pictureStatus),
                "size": "full",
                "aspectMode": "cover",
                "aspectRatio": "2:2"
              }
            ],
            "position": "absolute",
            "borderColor": "#00FF00",
            "borderWidth": "2px",
            "cornerRadius": "10px",
            "width": "149px",
            "offsetTop": "27px",
            "offsetStart": "4px",
            "height": "88px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "🚺{} ".format(cl.getContact(op.param2).displayName),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetStart": "10px"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "2px",
            "position": "absolute",
            "cornerRadius": "5px",
            "width": "150px",
            "offsetTop": "119px",
            "offsetStart": "2px",
            "backgroundColor": "#C71585",
            "height": "20px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "size": "full",
                "aspectMode": "cover",
                "aspectRatio": "2:2",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSktbf3ALAbjMxRN_nTge8Ewl41leYpORsYIw&usqp=CAU"
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "10px",
            "width": "33px",
            "height": "33px",
            "offsetTop": "143px",
            "offsetStart": "2px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "line://nv/timeline"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://media.cdnandroid.com/item_images/146592/imagen-autorap-by-smule-0big.jpg",
                "size": "full",
                "aspectMode": "cover",
                "aspectRatio": "2:2"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "10px",
            "borderWidth": "1px",
            "position": "absolute",
            "height": "33px",
            "width": "33px",
            "offsetTop": "143px",
            "offsetStart": "42px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "line://nv/cameraRoll/multi"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://www.facebook.com/images/fb_icon_325x325.png",
                "size": "full",
                "aspectRatio": "2:2",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "position": "absolute",
            "width": "33px",
            "height": "33px",
            "offsetTop": "143px",
            "cornerRadius": "10px",
            "offsetStart": "83px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "Https://smule.com/KSS_OFFICE"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQPY6QlUGRA-OlrBtRc99w88JsSHK4Jf2KHfw&usqp=CAU"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "10px",
            "position": "absolute",
            "width": "32px",
            "height": "32px",
            "borderWidth": "1px",
            "offsetTop": "143px",
            "offsetStart": "121px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "http://line.me/ti/p/~linux.1"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": wait["welcome"],
                "color": "#FFFFFF",
                "size": "xxs",
                "wrap": True,
                "offsetStart": "2px"
              }
            ],
            "borderColor": "#FFFF00",
            "position": "absolute",
            "offsetTop": "178px",
            "borderWidth": "2px",
            "offsetStart": "3px",
            "width": "150px",
            "height": "35px",
            "cornerRadius": "5px",
            "backgroundColor": "#C71585"
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#FFFF00",
        "borderWidth": "2px",
        "cornerRadius": "10px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "line://nv/profilePopup/mid=u6459106c8251205f79c2f037cd99b6a4"
        }
      }
    }
  ]
}
}
                cl.postTemplate(op.param1, data)
        if op.type == 15:
            if op.param1 in welcome:
                ginfo = cl.getGroup(op.param1)
              #ꜱᴜᴘᴘᴏʀᴛ ʙʏᴇ: ᴅᴇꜱʏ ʟᴜꜱʏᴀɴᴀ
                contact = cl.getContact(op.param2)
                cover = cl.getProfileCoverURL(op.param2)
                leaveMembers(op.param1, [op.param2])
                tz = pytz.timezone("Asia/Jakarta")
                timeNow = datetime.now(tz=tz)
                data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX 01",
                                       "contents": {
"type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTZg-QiWERGmh1VETXaeOiHcDAIgm1rF8k71A&usqp=CAU",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Autoleave Grup",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetStart": "40px"
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "cornerRadius": "5px",
            "borderWidth": "2px",
            "width": "152px",
            "offsetStart": "2px",
            "offsetTop": "2px",
            "height": "20px",
            "backgroundColor": "#C71585"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEAM TERMUX 01",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetStart": "13px"
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "borderWidth": "2px",
            "cornerRadius": "5px",
            "offsetTop": "214px",
            "offsetStart": "2px",
            "width": "152px",
            "backgroundColor": "#C71585"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "."
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "borderWidth": "2px",
            "offsetTop": "25px",
            "offsetStart": "2px",
            "width": "152px",
            "cornerRadius": "10px",
            "height": "92px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(op.param2).pictureStatus),
                "size": "full",
                "aspectMode": "cover",
                "aspectRatio": "2:2"
              }
            ],
            "position": "absolute",
            "borderColor": "#00FF00",
            "borderWidth": "2px",
            "cornerRadius": "10px",
            "width": "149px",
            "offsetTop": "27px",
            "offsetStart": "4px",
            "height": "88px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "🚺{} ".format(cl.getContact(op.param2).displayName),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetStart": "10px"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "2px",
            "position": "absolute",
            "cornerRadius": "5px",
            "width": "150px",
            "offsetTop": "119px",
            "offsetStart": "2px",
            "backgroundColor": "#C71585",
            "height": "20px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "size": "full",
                "aspectMode": "cover",
                "aspectRatio": "2:2",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSktbf3ALAbjMxRN_nTge8Ewl41leYpORsYIw&usqp=CAU"
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "10px",
            "width": "33px",
            "height": "33px",
            "offsetTop": "143px",
            "offsetStart": "2px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "line://nv/timeline"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://media.cdnandroid.com/item_images/146592/imagen-autorap-by-smule-0big.jpg",
                "size": "full",
                "aspectMode": "cover",
                "aspectRatio": "2:2"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "10px",
            "borderWidth": "1px",
            "position": "absolute",
            "height": "33px",
            "width": "33px",
            "offsetTop": "143px",
            "offsetStart": "42px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "line://nv/cameraRoll/multi"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://www.facebook.com/images/fb_icon_325x325.png",
                "size": "full",
                "aspectRatio": "2:2",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "position": "absolute",
            "width": "33px",
            "height": "33px",
            "offsetTop": "143px",
            "cornerRadius": "10px",
            "offsetStart": "83px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "Https://smule.com/KSS_OFFICE"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQPY6QlUGRA-OlrBtRc99w88JsSHK4Jf2KHfw&usqp=CAU"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "10px",
            "position": "absolute",
            "width": "32px",
            "height": "32px",
            "borderWidth": "1px",
            "offsetTop": "143px",
            "offsetStart": "121px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "http://line.me/ti/p/~linux.1"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": wait["autoLeave"],
                "color": "#FFFFFF",
                "size": "xxs",
                "wrap": True,
                "offsetStart": "2px"
              }
            ],
            "borderColor": "#FFFF00",
            "position": "absolute",
            "offsetTop": "178px",
            "borderWidth": "2px",
            "offsetStart": "3px",
            "width": "150px",
            "height": "35px",
            "cornerRadius": "5px",
            "backgroundColor": "#C71585"
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#FFFF00",
        "borderWidth": "2px",
        "cornerRadius": "10px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "line://nv/profilePopup/mid=u6459106c8251205f79c2f037cd99b6a4"
        }
      }
    },
 {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTZg-QiWERGmh1VETXaeOiHcDAIgm1rF8k71A&usqp=CAU",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Autoleave Grup",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetStart": "40px"
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "cornerRadius": "5px",
            "borderWidth": "2px",
            "width": "152px",
            "offsetStart": "2px",
            "offsetTop": "2px",
            "height": "20px",
            "backgroundColor": "#C71585"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEAM TERMUX 01",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetStart": "13px"
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "borderWidth": "2px",
            "cornerRadius": "5px",
            "offsetTop": "214px",
            "offsetStart": "2px",
            "width": "152px",
            "backgroundColor": "#C71585"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "."
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "borderWidth": "2px",
            "offsetTop": "25px",
            "offsetStart": "2px",
            "width": "152px",
            "cornerRadius": "10px",
            "height": "92px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(op.param2).pictureStatus),
                "size": "full",
                "aspectMode": "cover",
                "aspectRatio": "2:2"
              }
            ],
            "position": "absolute",
            "borderColor": "#00FF00",
            "borderWidth": "2px",
            "cornerRadius": "10px",
            "width": "149px",
            "offsetTop": "27px",
            "offsetStart": "4px",
            "height": "88px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "🚺{} ".format(cl.getContact(op.param2).displayName),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetStart": "10px"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "2px",
            "position": "absolute",
            "cornerRadius": "5px",
            "width": "150px",
            "offsetTop": "119px",
            "offsetStart": "2px",
            "backgroundColor": "#C71585",
            "height": "20px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "size": "full",
                "aspectMode": "cover",
                "aspectRatio": "2:2",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSktbf3ALAbjMxRN_nTge8Ewl41leYpORsYIw&usqp=CAU"
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "10px",
            "width": "33px",
            "height": "33px",
            "offsetTop": "143px",
            "offsetStart": "2px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "line://nv/timeline"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://media.cdnandroid.com/item_images/146592/imagen-autorap-by-smule-0big.jpg",
                "size": "full",
                "aspectMode": "cover",
                "aspectRatio": "2:2"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "10px",
            "borderWidth": "1px",
            "position": "absolute",
            "height": "33px",
            "width": "33px",
            "offsetTop": "143px",
            "offsetStart": "42px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "line://nv/cameraRoll/multi"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://www.facebook.com/images/fb_icon_325x325.png",
                "size": "full",
                "aspectRatio": "2:2",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "position": "absolute",
            "width": "33px",
            "height": "33px",
            "offsetTop": "143px",
            "cornerRadius": "10px",
            "offsetStart": "83px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "Https://smule.com/KSS_OFFICE"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQPY6QlUGRA-OlrBtRc99w88JsSHK4Jf2KHfw&usqp=CAU"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "10px",
            "position": "absolute",
            "width": "32px",
            "height": "32px",
            "borderWidth": "1px",
            "offsetTop": "143px",
            "offsetStart": "121px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "http://line.me/ti/p/~linux.1"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": wait["autoLeave"],
                "color": "#FFFFFF",
                "size": "xxs",
                "wrap": True,
                "offsetStart": "2px"
              }
            ],
            "borderColor": "#FFFF00",
            "position": "absolute",
            "offsetTop": "178px",
            "borderWidth": "2px",
            "offsetStart": "3px",
            "width": "150px",
            "height": "35px",
            "cornerRadius": "5px",
            "backgroundColor": "#C71585"
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#FFFF00",
        "borderWidth": "2px",
        "cornerRadius": "10px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "line://nv/profilePopup/mid=u6459106c8251205f79c2f037cd99b6a4"
        }
      }
    }
  ]
}
}
                cl.postTemplate(op.param1, data)
        
        if op.type == 55:
            if cctv['cyduk'][op.param1]==True:
                if op.param1 in cctv['point']:
                    Name = cl.getContact(op.param2).displayName
                    if Name in cctv['sidermem'][op.param1]:
                        pass
                    else:
                        cctv['sidermem'][op.param1] += "\n~ " + Name
                        siderMembers(op.param1, [op.param2])
                        contact = cl.getContact(op.param2)
                        cover = cl.getProfileCoverURL(op.param2)
                        tz = pytz.timezone("Asia/Jakarta")
                        timeNow = datetime.now(tz=tz)
                        data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX 01",
                                       "contents": {
                                       
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS4EHbxAIv86EkedPB45QJaXIirvByt5RTZcg&usqp=CAU",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "SIDER MEMBER",
                "color": "#FFFFFF",
                "size": "xxs",
                "offsetTop": "2px",
                "offsetStart": "35px"
              }
            ],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "152px",
            "height": "20px",
            "offsetTop": "2px",
            "offsetStart": "2px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#7CFC00",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "152px",
            "height": "88px",
            "position": "absolute",
            "offsetTop": "23px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#FF00FF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "position": "absolute",
            "height": "85px",
            "width": "150px",
            "offsetTop": "25px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(op.param2).pictureStatus),
                "size": "full",
                "aspectMode": "cover",
                "aspectRatio": "2:2"
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "height": "83px",
            "width": "148px",
            "offsetTop": "26px",
            "offsetStart": "4px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "  "+ datetime.strftime(timeNow,'%H:%M:%S'),
                "color": "#FFFFFF",
                "size": "xxs",
                "offsetTop": "2px",
                "offsetStart": "10px"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "2px",
            "width": "70px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "112px",
            "offsetStart": "2px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "  "+ datetime.strftime(timeNow,'%Y-%m-%d'),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "borderColor": "#00FFFF",
            "cornerRadius": "2px",
            "borderWidth": "1px",
            "width": "80px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "112px",
            "offsetStart": "74px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "❒    {} ".format(cl.getContact(op.param2).displayName),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "3px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "width": "152px",
            "height": "22px",
            "offsetTop": "133px",
            "offsetStart": "2px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "CREATOR",
                "color": "#FFFFFF",
                "size": "xxs",
                "offsetTop": "2px",
                "offsetStart": "5px"
              }
            ],
            "borderWidth": "1px",
            "borderColor": "#00FFFF",
            "position": "absolute",
            "width": "70px",
            "height": "20px",
            "offsetTop": "212px",
            "offsetStart": "2px",
            "backgroundColor": "#800080",
            "cornerRadius": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "ORDER",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "17px"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "width": "80px",
            "height": "20px",
            "position": "absolute",
            "backgroundColor": "#4B0082",
            "offsetTop": "212px",
            "offsetStart": "73px",
            "cornerRadius": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "width": "152px",
            "height": "33px",
            "position": "absolute",
            "offsetTop": "155px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSqaS60Dv8DBRF7xpsODJT-7UPdt5PdWCtOiBV9xDfvvndPARGBZQf6cpQqJ_k1QajGmmChLjO_MELOmiml7YyYpfzK5_6z5AE&usqp=CAU&ec=45725302",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "height": "20px",
            "width": "20px",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "offsetTop": "190px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": wait["mention"],
                "size": "xxs",
                "color": "#FFFFFF",
                "wrap": True,
                "offsetTop": "1px",
                "offsetStart": "3px"
              }
            ],
            "position": "absolute",
            "borderColor": "#FF0000",
            "borderWidth": "1px",
            "width": "150px",
            "height": "32px",
            "offsetTop": "156px",
            "offsetStart": "3px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTrL6_OWpBPDFXt37Mu-tf-yN53HCcQwpmPHA&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "20px",
            "height": "20px",
            "borderColor": "#00FFFF",
            "offsetTop": "190px",
            "borderWidth": "1px",
            "offsetStart": "25px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "size": "full",
                "aspectMode": "cover",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQRzUbZPwMHcKGnRudeq6VCtiW3Mla0MQ5eBOPZEeGNIXd8ypsdhTVU-PAfAumHIcPerNSew8p53aKX1qZaOBBSnA3zRezSrwQ&usqp=CAU&ec=45725302"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "height": "20px",
            "width": "20px",
            "position": "absolute",
            "offsetTop": "190px",
            "offsetStart": "49px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "aspectMode": "cover",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSWwPoxnFCmfGNNu8bckmjLVlO2OKIebl8v47Xj4vExmDMt42Wz8C6vePLb9ruVsq1UKAtsBwJbmTgyEuD1QuhmniHO99j3JwM&usqp=CAU&ec=45725302"
              }
            ],
            "height": "20px",
            "width": "20px",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "position": "absolute",
            "offsetTop": "190px",
            "offsetStart": "77px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "aspectMode": "cover",
                "url": "https://pbs.twimg.com/profile_images/1308010958862905345/-SGZioPb.jpg"
              }
            ],
            "offsetTop": "190px",
            "offsetStart": "106px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "borderColor": "#00FFFF",
            "borderWidth": "1px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://assets.stickpng.com/images/580b57fcd9996e24bc43c545.png",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#00FFFF",
            "position": "absolute",
            "width": "20px",
            "height": "20px",
            "borderWidth": "1px",
            "offsetTop": "190px",
            "offsetStart": "133px"
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#00FFFF",
        "cornerRadius": "10px",
        "borderWidth": "2px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~linux.1"
        }
      }
    }
  ]
}
}
                        cl.postTemplate(op.param1, data),
#===============================➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  
        if op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if settings ["Aip"] == True:
                if msg.text in ["byepass"]:
                    cl.kickoutFromGroup(receiver,[sender])
            if wait["selfbot"] == True:
               if msg._from not in Bots:
                 if wait["talkban"] == True:
                   if msg._from in wait["Talkblacklist"]:
                      try:
                          cl.kickoutFromGroup(msg.to, [msg._from])
                      except:
                          try:
                              cl.kickoutFromGroup(msg.to, [msg._from])
                          except:
                              try:
                                  cl.kickoutFromGroup(msg.to, [msg._from])
                              except:
                                  try:
                                  	cl.kickoutFromGroup(msg.to, [msg._from])
                                  except:
                                      pass
               if msg.contentMetadata and 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["detectMention"] == True:
                   contact = cl.getContact(msg._from)
                   tz = pytz.timezone("Asia/Jakarta")
                   timeNow = datetime.now(tz=tz)
                   cover = cl.getProfileCoverURL(sender)
                   name = re.findall(r'@(\w+)', msg.text)
                   image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in mid:
                           data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX 01",
                                       "contents": {
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS4EHbxAIv86EkedPB45QJaXIirvByt5RTZcg&usqp=CAU",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "AUTORESPON",
                "color": "#FFFFFF",
                "size": "xxs",
                "offsetTop": "2px",
                "offsetStart": "13px"
              }
            ],
            "position": "absolute",
            "width": "100px",
            "height": "20px",
            "borderColor": "#00FF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "offsetStart": "28px",
            "offsetTop": "4px",
            "backgroundColor": "#8B008B"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRlWNMHX6faWZgVks3B42p4w0LU1nizBYJysQ&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#00FF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "height": "25px",
            "width": "25px",
            "position": "absolute",
            "offsetTop": "2px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRqdcAKxaEaPuGvM_wanEFxAJsknAkQJo11Vg&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "borderColor": "#00FF00",
            "height": "25px",
            "width": "25px",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "offsetTop": "2px",
            "offsetStart": "129px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "JAM",
                "size": "xs",
                "color": "#FFFFFF",
                "offsetTop": "1px",
                "offsetStart": "20px"
              }
            ],
            "position": "absolute",
            "borderColor": "#FF00FF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "75px",
            "height": "20px",
            "offsetTop": "30px",
            "offsetStart": "2px",
            "backgroundColor": "#008000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "  "+ datetime.strftime(timeNow,'%H:%M:%S'),
                "size": "xs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "5px"
              }
            ],
            "borderColor": "#FF00FF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "75px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "53px",
            "offsetStart": "2px",
            "backgroundColor": "#00008B"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TGL",
                "size": "xs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "20px"
              }
            ],
            "position": "absolute",
            "width": "75px",
            "height": "20px",
            "borderColor": "#FF00FF",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "offsetTop": "74px",
            "offsetStart": "2px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "  "+ datetime.strftime(timeNow,'%Y-%m-%d'),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "borderWidth": "1px",
            "borderColor": "#FFFF00",
            "width": "75px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "95px",
            "offsetStart": "2px",
            "cornerRadius": "5px",
            "backgroundColor": "#FF0000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "77px",
            "height": "88px",
            "offsetStart": "1px",
            "offsetTop": "28px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "borderColor": "#00FF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "74px",
            "height": "87px",
            "offsetTop": "29px",
            "offsetStart": "80px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#FFFF00",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "70px",
            "height": "83px",
            "position": "absolute",
            "offsetTop": "31px",
            "offsetStart": "82px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                "size": "full",
                "aspectMode": "cover",
                "aspectRatio": "2:3"
              }
            ],
            "position": "absolute",
            "borderColor": "#FF1493",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "68px",
            "height": "80px",
            "offsetTop": "33px",
            "offsetStart": "83px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "100px",
            "height": "50px",
            "offsetTop": "120px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": wait["Respontag"],
                "size": "xxs",
                "color": "#FFFFFF",
                "wrap": True,
                "offsetTop": "5px",
                "offsetStart": "2px"
              }
            ],
            "borderColor": "#FF0000",
            "borderWidth": "1px",
            "width": "98px",
            "height": "46px",
            "position": "absolute",
            "offsetTop": "122px",
            "offsetStart": "3px",
            "cornerRadius": "5px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "width": "48px",
            "height": "111px",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "borderColor": "#FFFF00",
            "offsetTop": "122px",
            "offsetStart": "105px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "borderColor": "#FF0000",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "offsetTop": "124px",
            "height": "108px",
            "width": "44px",
            "offsetStart": "107px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co/fvx0z0Q/20190925-164758.png",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "127px",
            "offsetStart": "118px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co/98RJkdy/20190925-164910.png",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "height": "20px",
            "position": "absolute",
            "width": "20px",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "offsetTop": "155px",
            "offsetStart": "118px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co/F0yX5Yt/20190925-164610.png",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "height": "20px",
            "width": "20px",
            "position": "absolute",
            "offsetTop": "180px",
            "offsetStart": "118px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co/ypkDngF/20190925-164247.png",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "offsetTop": "209px",
            "offsetStart": "118px",
            "width": "20px",
            "height": "20px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "➥  {} ".format(contact.displayName),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "100px",
            "height": "20px",
            "offsetTop": "169px",
            "offsetStart": "2px",
            "backgroundColor": "#800080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Selfbot Template",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "7px"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "100px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "191px",
            "offsetStart": "2px",
            "backgroundColor": "#228B22"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "CREATOR",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "23px"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "width": "100px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "213px",
            "offsetStart": "2px",
            "cornerRadius": "5px",
            "backgroundColor": "#8B0000"
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#FF00FF",
        "borderWidth": "2px",
        "cornerRadius": "10px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~linux.1"
        }
      }
    }
  ]
}
}
                           cl.postTemplate(to, data)
                        #   cl.sendMessage(msg.to, None, contentMetadata={"STKID":"155808605","STKPKGID":"6700627","STKVER":"1"}, contentType=7)
                           break
               if msg.contentMetadata and 'MENTION' in msg.contentMetadata.keys() != None:
                if msg._from not in Bots:
                 if wait["Mentionkick"] == True:
                   name = re.findall(r'@(\w+)', msg.text)
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in Bots:
                           sendTextTemplate1(msg.to,"JANGAN TAG GUE TEK JITAK LOE")
                           cl.kickoutFromGroup(msg.to, [msg._from])
                           break

               if msg.contentMetadata and 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["detectMention2"] == True:
                   contact = cl.getContact(msg._from)
                   tz = pytz.timezone("Asia/Jakarta")
                   timeNow = datetime.now(tz=tz)
                   cover = cl.getProfileCoverURL(sender)
                   name = re.findall(r'@(\w+)', msg.text)
                   image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in mid:
                           data = {
                                "type": "flex",
                                "altText": "TEAM TERMUX 01",
                                "contents": {
                                
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcR_c8Ukb09wElphX3Wclyp9hxFw-QyXXnqSew&usqp=CAU",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "SELFBOT TEMPLATE V3",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "8px"
              }
            ],
            "cornerRadius": "5px",
            "width": "145px",
            "height": "20px",
            "position": "absolute",
            "borderWidth": "1px",
            "borderColor": "#FF0000",
            "offsetStart": "5px",
            "offsetTop": "3px",
            "backgroundColor": "#800080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#00FF7F",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "position": "absolute",
            "width": "60px",
            "height": "70px",
            "offsetTop": "27px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "  "+ datetime.strftime(timeNow,'%H:%M:%S'),
                "color": "#FFFFFF",
                "size": "xxs",
                "offsetStart": "4px",
                "offsetTop": "3px"
              }
            ],
            "borderColor": "#00FF7F",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "position": "absolute",
            "width": "58px",
            "height": "25px",
            "offsetTop": "27px",
            "offsetStart": "3px",
            "backgroundColor": "#FF6347"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "  "+ datetime.strftime(timeNow,'%m-%y-%d'),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetStart": "2px",
                "offsetTop": "3px"
              }
            ],
            "borderColor": "#00FF7F",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "58px",
            "height": "25px",
            "offsetTop": "53px",
            "position": "absolute",
            "offsetStart": "3px",
            "backgroundColor": "#191970"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "CREATOR",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "2px",
                "action": {
                  "type": "uri",
                  "label": "action",
                  "uri": "http://line.me/ti/p/~linux.1"
                }
              }
            ],
            "borderColor": "#00FF7F",
            "cornerRadius": "5px",
            "width": "58px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "78px",
            "offsetStart": "3px",
            "borderWidth": "1px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#00FF7F",
            "position": "absolute",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "80px",
            "height": "70px",
            "offsetStart": "70px",
            "offsetTop": "27px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FF1493",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "position": "absolute",
            "width": "78px",
            "height": "68px",
            "offsetTop": "28px",
            "offsetStart": "71px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#FF1493",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "position": "absolute",
            "width": "148px",
            "height": "30px",
            "offsetTop": "100px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcR5eA6WWfVBgPkUBTWmoJAoWLc-Wd7H_X74yw&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "height": "20px",
            "width": "20px",
            "position": "absolute",
            "offsetTop": "105px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTrL6_OWpBPDFXt37Mu-tf-yN53HCcQwpmPHA&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "position": "absolute",
            "width": "20px",
            "height": "20px",
            "offsetTop": "105px",
            "offsetStart": "30px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i0.wp.com/gulangguling.com/wp-content/uploads/2016/07/gambar-akun-youtube.png?fit=1280%2C839&ssl=1",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "105px",
            "offsetStart": "55px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.pinimg.com/originals/d2/e5/35/d2e5359f8402cb8d3d7b22c463f9013b.png",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "105px",
            "offsetStart": "80px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRK_yDc42L7ssYuvce24MqTgvesOvYZgQIi8Q&usqp=CAU",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "position": "absolute",
            "width": "20px",
            "height": "20px",
            "offsetTop": "105px",
            "offsetStart": "105px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://siar.com/wp-content/uploads/2018/03/LINE-sebuah-aplikasi-media-sosial-yang-dimiliki-Line-Corp-yang-berbasis-di-Jepang-sumber-Line.jpg",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "position": "absolute",
            "width": "20px",
            "height": "20px",
            "offsetTop": "105px",
            "offsetStart": "128px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "➥  {} ".format(contact.displayName),
                "color": "#FFFFFF",
                "size": "xxs",
                "offsetStart": "3px",
                "offsetTop": "2px"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "148px",
            "position": "absolute",
            "height": "20px",
            "offsetTop": "133px",
            "offsetStart": "3px",
            "backgroundColor": "#191970"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "ASSALAMUALAIKUM",
                "color": "#FFFFFF",
                "size": "xxs",
                "offsetStart": "20px",
                "offsetTop": "2px"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "height": "20px",
            "width": "148px",
            "position": "absolute",
            "offsetTop": "156px",
            "offsetStart": "3px",
            "backgroundColor": "#663399"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": wait["Respontag2"],
                "wrap": True,
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetStart": "2px",
                "offsetTop": "5px"
              }
            ],
            "borderColor": "#00FF7F",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "150px",
            "height": "52px",
            "position": "absolute",
            "offsetTop": "180px",
            "offsetStart": "2px"
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#0000CD",
        "borderWidth": "2px",
        "cornerRadius": "10px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "line://nv/profilePopup/mid=u6459106c8251205f79c2f037cd99b6a4"
        }
      }
    }
  ]
}
}
                           cl.postTemplate(to, data)
                        #   cl.sendMessage(msg.to, None, contentMetadata={"STKID":"155808605","STKPKGID":"6700627","STKVER":"1"}, contentType=7)
                           break
#===============================➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  
                 if msg.contentMetadata and 'MENTION' in msg.contentMetadata.keys() != None:
                  if wait["detectMention3"] == True:
                   contact = cl.getContact(msg._from)
                   name = re.findall(r'@(\w+)', msg.text)
                   image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in Bots:
                           cl.sendMessage(msg.to, wait["Respontag"])
                           break
#===============================➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  
               if msg.contentMetadata and 'MENTION' in msg.contentMetadata.keys() != None:
                  if wait["detectMention4"] == True:
                   contact = cl.getContact(msg._from)
                   tz = pytz.timezone("Asia/Jakarta")
                   timeNow = datetime.now(tz=tz)
                   cover = cl.getProfileCoverURL(sender)
                   name = re.findall(r'@(\w+)', msg.text)
                   image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in mid:
                           data = {

  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://scontent.fsoc2-1.fna.fbcdn.net/v/t1.0-0/p180x540/90073376_210211183412154_6214009738129047552_o.jpg?_nc_cat=107&ccb=2&_nc_sid=8bfeb9&_nc_eui2=AeFGSy5XaY4VI0husIHXZZYAmqVB3cxXwDSapUHdzFfANG6QdarYoP3DlWnG1o7k8LykkWX2xWf83coEqbuPmyI4&_nc_ohc=mF6ZqV8ZvyAAX8dMz2X&_nc_ht=scontent.fsoc2-1.fna&tp=6&oh=75400ffd350a23e84a5e2a49f49ee927&oe=5FE59BD8",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:1",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "➥  {} ".format(contact.displayName),
                "color": "#FFFFFF",
                "size": "xxs",
                "offsetStart": "38px"
              }
            ],
            "borderColor": "#FF1493",
            "borderWidth": "2px",
            "cornerRadius": "10px",
            "width": "120px",
            "position": "absolute",
            "height": "20px",
            "offsetTop": "124px",
            "offsetStart": "8px",
            "backgroundColor": "#000080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FF1493",
            "borderWidth": "2px",
            "cornerRadius": "100px",
            "position": "absolute",
            "height": "40px",
            "width": "40px",
            "offsetTop": "106px",
            "offsetStart": "4px"
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#FF1493",
        "cornerRadius": "15px",
        "borderWidth": "2px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~linux.1"
        }
      }
    }
  ]
}
                           cl.postFlex(to, data)
                           break
#===============================➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  
               if msg.contentMetadata and 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["detectMention5"] == True:
                   contact = cl.getContact(msg._from)
                   tz = pytz.timezone("Asia/Jakarta")
                   timeNow = datetime.now(tz=tz)
                   cover = cl.getProfileCoverURL(sender)
                   name = re.findall(r'@(\w+)', msg.text)
                   image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in mid:
                           data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX 01",
                                       "contents": {
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTHx1sgLJhY1T4Kx_iEGgcP_23f7TufHQe1SQ&usqp=CAU",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                "size": "full",
                "aspectMode": "cover",
                "aspectRatio": "1:2"
              }
            ],
            "position": "absolute",
            "borderColor": "#FF6347",
            "cornerRadius": "5px",
            "borderWidth": "2px",
            "width": "130px",
            "height": "145px",
            "offsetStart": "12px",
            "offsetTop": "10px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "color": "#FFFFFF",
                "text": wait["Respontag5"],
                "wrap": True,
                "size": "xxs",
                "weight": "regular",
                "style": "italic",
                "position": "relative",
                "gravity": "top",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "borderColor": "#CD5C5C",
            "borderWidth": "2px",
            "cornerRadius": "5px",
            "offsetTop": "160px",
            "offsetStart": "12px",
            "width": "130px",
            "height": "35px",
            "backgroundColor": "#000080"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "CREATOR",
                "color": "#FFFFFF",
                "offsetStart": "25px",
                "action": {
                  "type": "uri",
                  "label": "action",
                  "uri": "http://line.me/ti/p/~linux.1"
                }
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "borderWidth": "2px",
            "cornerRadius": "5px",
            "offsetTop": "200px",
            "width": "130px",
            "offsetStart": "12px",
            "backgroundColor": "#4682B4"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "🔹{} ".format(contact.displayName),
                "color": "#FFFFFF",
                "size": "xxs",
                "offsetTop": "1px"
              }
            ],
            "position": "absolute",
            "borderColor": "#B22222",
            "borderWidth": "2px",
            "cornerRadius": "5px",
            "offsetTop": "135px",
            "offsetStart": "14px",
            "width": "126px",
            "backgroundColor": "#9400D3"
          }
        ],
        "paddingAll": "0px",
        "borderColor": "#AFEEEE",
        "borderWidth": "2px",
        "cornerRadius": "5px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "line://nv/profilePopup/mid=u6459106c8251205f79c2f037cd99b6a4"
        }
      }
    }
  ]
}
}
                           cl.postTemplate(to, data)
                        #   cl.sendMessage(msg.to, None, contentMetadata={"STKID":"155808605","STKPKGID":"6700627","STKVER":"1"}, contentType=7)
                           break

#===============================➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  
               if msg.contentType == 7:
                 if wait["sticker"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,"「Cek ID Sticker」\n°❂° STKID : " + msg.contentMetadata["STKID"] + "\n°❂° STKPKGID : " + msg.contentMetadata["STKPKGID"] + "\n°❂° STKVER : " + msg.contentMetadata["STKVER"]+ "\n\n「Link Sticker」" + "\nline://shop/detail/" + msg.contentMetadata["STKPKGID"])
               if msg.contentType == 13:
                 if wait["contact"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        path = cl.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        cl.sendMessage(msg.to,"°❂° Nama : " + msg.contentMetadata["displayName"] + "\n°❂° MID : " + msg.contentMetadata["mid"] + "\n°❂° Status Msg : " + contact.statusMessage + "\n°❂° Picture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        cl.sendImageWithURL(msg.to, image)
        if op.type == 25 or op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 and msg.toType == 2:
                if sender != cl.profile.mid:
                    to = sender
                else:
                    to = receiver
            elif msg.toType == 1:
                to = receiver
            elif msg.toType == 2:
                to = receiver
            if msg.contentType == 0:
                to = receiver
            if msg.contentType == 16:
              if settings["checkPost"] == True:
                contact = cl.getContact(msg._from)
                url = msg.contentMetadata["postEndUrl"]
                tz = pytz.timezone("Asia/Jakarta")
                timeNow = datetime.now(tz=tz)
                cl.likePost(url[25:58], url[66:], likeType=1004)
                cl.createComment(url[25:58], url[66:], wait["comment"])
                cover = cl.getProfileCoverURL(sender)
                data = {
                                "type": "flex",
                                "altText": "TEAM TERMUX 01",
                                "contents": {
"type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://mysmart1.files.wordpress.com/2017/08/cropped-wallpaper-keren-hd-untuk-android-dan-komputer-4.jpg",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "152px",
            "height": "40px",
            "offsetTop": "2px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#DC143C",
            "borderWidth": "1px",
            "cornerRadius": "10px",
            "width": "149px",
            "height": "36px",
            "position": "absolute",
            "offsetTop": "4px",
            "offsetStart": "4px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "borderColor": "#FF00FF",
            "cornerRadius": "10px",
            "borderWidth": "1px",
            "width": "145px",
            "position": "absolute",
            "height": "33px",
            "offsetTop": "6px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://scontent-cgk1-2.xx.fbcdn.net/v/t1.0-9/85106040_184561645977108_8424969923272376320_o.jpg?_nc_cat=105&ccb=2&_nc_sid=8bfeb9&_nc_eui2=AeGBKBifzBLzNE71hTzLNvAGbbBygnYDuvFtsHKCdgO68UA39j3uu-MqIXOwePcuAszI1esXeSt0V6wlceKLHDgH&_nc_ohc=cAi3ZKewnkoAX_Qg7Lr&_nc_ht=scontent-cgk1-2.xx&oh=088f9c37398ec074aa9346d465143e30&oe=6007FFCB",
                "size": "full",
                "aspectMode": "fit",
                "aspectRatio": "2:2"
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "cornerRadius": "5px",
            "borderWidth": "1px",
            "width": "50px",
            "height": "30px",
            "offsetTop": "8px",
            "offsetStart": "7px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "AUTOLIKE",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "6px",
                "offsetStart": "16px"
              }
            ],
            "position": "absolute",
            "borderColor": "#00FF00",
            "borderWidth": "1px",
            "cornerRadius": "10px",
            "width": "89px",
            "height": "29px",
            "offsetTop": "8px",
            "offsetStart": "59px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "79px",
            "height": "90px",
            "offsetTop": "44px",
            "offsetStart": "1px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "PROFILE",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "14px"
              }
            ],
            "borderColor": "#FF1493",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "position": "absolute",
            "width": "77px",
            "height": "20px",
            "offsetTop": "45px",
            "offsetStart": "2px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(sender).pictureStatus),
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "77px",
            "height": "67px",
            "offsetTop": "66px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "borderColor": "#FF0000",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "154px",
            "height": "20px",
            "offsetTop": "136px",
            "offsetStart": "1px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "color": "#FFFFFF",
                "size": "xxs",
                "offsetTop": "1px",
                "offsetStart": "2px",
                "text": "✬  {}".format(cl.getContact(mid).displayName),
              }
            ],
            "borderColor": "#00FF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "152px",
            "height": "17px",
            "position": "absolute",
            "offsetTop": "138px",
            "offsetStart": "2px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "JAM",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "25px"
              }
            ],
            "borderColor": "#00FF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "height": "20px",
            "width": "74px",
            "position": "absolute",
            "offsetTop": "44px",
            "offsetStart": "81px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": " "+ datetime.strftime(timeNow,'%H:%M:%S'),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "19px"
              }
            ],
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "74px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "66px",
            "offsetStart": "81px",
            "backgroundColor": "#000000",
            "borderColor": "#FF00FF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TANGGAL",
                "color": "#FFFFFF",
                "size": "xxs",
                "offsetTop": "3px",
                "offsetStart": "11px"
              }
            ],
            "borderColor": "#00FFFF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "position": "absolute",
            "width": "74px",
            "height": "22px",
            "offsetTop": "88px",
            "offsetStart": "81px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": " "+ datetime.strftime(timeNow,'%Y-%m-%d'),
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "3px"
              }
            ],
            "position": "absolute",
            "borderColor": "#FF1493",
            "borderWidth": "1px",
            "width": "74px",
            "height": "20px",
            "backgroundColor": "#000000",
            "cornerRadius": "5px",
            "offsetTop": "113px",
            "offsetStart": "81px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "width": "152px",
            "height": "55px",
            "borderColor": "#FF1493",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "offsetTop": "158px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♻ TEAM TERMUX 01™ ♻",
                "size": "xxs",
                "color": "#FFFFFF",
                "offsetTop": "2px",
                "offsetStart": "16px"
              }
            ],
            "position": "absolute",
            "offsetTop": "214px",
            "offsetStart": "1px",
            "width": "153px",
            "height": "20px",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "borderColor": "#00FFFF",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute",
            "borderColor": "#0000FF",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "offsetTop": "159px",
            "offsetStart": "3px",
            "width": "150px",
            "height": "53px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "position": "absolute"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "SUDAH KAMI LIKE BOSS",
                "size": "xxs",
                "color": "#FFD700",
                "offsetTop": "4px",
                "offsetStart": "7px"
              }
            ],
            "position": "absolute",
            "borderColor": "#00FF00",
            "borderWidth": "1px",
            "cornerRadius": "5px",
            "width": "148px",
            "height": "25px",
            "offsetTop": "161px",
            "offsetStart": "4px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co/ypkDngF/20190925-164247.png",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "20px",
            "height": "20px",
            "borderWidth": "1px",
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "offsetTop": "190px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co/F0yX5Yt/20190925-164610.png",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "offsetTop": "190px",
            "offsetStart": "35px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co/98RJkdy/20190925-164910.png",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "height": "20px",
            "width": "20px",
            "position": "absolute",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "borderColor": "#FFFF00",
            "offsetTop": "190px",
            "offsetStart": "68px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co/fvx0z0Q/20190925-164758.png",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "width": "20px",
            "height": "20px",
            "position": "absolute",
            "borderColor": "#FFFF00",
            "borderWidth": "1px",
            "cornerRadius": "100px",
            "offsetTop": "190px",
            "offsetStart": "100px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co/nRKcLQN/20190925-165015.png",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "width": "20px",
            "cornerRadius": "100px",
            "borderWidth": "1px",
            "borderColor": "#FFFF00",
            "offsetTop": "190px",
            "offsetStart": "130px",
            "height": "20px",
            "position": "absolute"
          }
        ],
        "paddingAll": "0px",
        "cornerRadius": "10px",
        "borderWidth": "2px",
        "borderColor": "#FF1493",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~linux.1"
        }
      }
    }
  ]
}
}
                cl.postTemplate(to, data)
                
            if msg.contentType == 0 or msg.toType == 2:
               if msg.toType == 0:
                    to = receiver
               elif msg.toType == 2:
                    to = receiver
               if msg.contentType == 7:
                 if wait["sticker"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,"STKID : " + msg.contentMetadata["STKID"] + "\nSTKPKGID : " + msg.contentMetadata["STKPKGID"] + "\nSTKVER : " + msg.contentMetadata["STKVER"]+ "\n\n「Link Sticker」" + "\nline://shop/detail/" + msg.contentMetadata["STKPKGID"])
               if msg.contentType == 13:
                 if wait["contact"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        path = cl.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        cl.sendMessage(msg.to,"Nama : " + msg.contentMetadata["displayName"] + "\nMID : " + msg.contentMetadata["mid"] + "\nStatus Msg : " + contact.statusMessage + "\nPicture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        cl.sendImageWithURL(msg.to, image)
               if msg.contentType == 13:
                if msg._from in admin:
                  if wait["invite"] == True:
                    msg.contentType = 0
                    contact = cl.getContact(msg.contentMetadata["mid"])
                    invite = msg.contentMetadata["mid"]
                    groups = cl.getGroup(msg.to)
                    pending = groups.invitee
                    targets = []
                    for s in groups.members:
                        if invite in wait["blacklist"]:
                            sendTextTemplate1(msg.to, "ʟɪsᴛ ʙʟ")
                            break
                        else:
                            targets.append(invite)
                    if targets == []:
                        pass
                    else:
                         for target in targets:
                             try:
                                  cl.findAndAddContactsByMid(target)
                                  cl.inviteIntoGroup(msg.to,[target])
                                  ryan = cl.getContact(target)
                                  zx = ""
                                  zxc = ""
                                  zx2 = []
                                  xpesan =  "「 sᴜᴋsᴇs ɪɴᴠɪᴛᴇ 」\nɴᴀᴍᴀ"
                                  ret_ = "ᴋᴇᴛɪᴋ ɪɴᴠɪᴛᴇ ᴏғғ ᴊɪᴋᴀ sᴜᴅᴀʜ ᴅᴏɴᴇ"
                                  ry = str(ryan.displayName)
                                  pesan = ''
                                  pesan2 = pesan+"@x\n"
                                  xlen = str(len(zxc)+len(xpesan))
                                  xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                  zx = {'S':xlen, 'E':xlen2, 'M':ryan.mid}
                                  zx2.append(zx)
                                  zxc += pesan2
                                  text = xpesan + zxc + ret_ + ""
                                  cl.sendMessage(msg.to, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                                  wait["invite"] = False
                                  break
                             except:
                                  sendTextTemplate1(msg.to,"➥   Akun Anda Terkena Limit")
                                  wait["invite"] = False
                                  break
                                  
               if msg.contentType == 13:
                 if wait["Invi"] == True:
                        _name = msg.contentMetadata["displayName"]
                        invite = msg.contentMetadata["mid"]
                        groups = cl.getGroup(msg.to)
                        pending = groups.invitee
                        targets = []
                        for s in groups.members:
                            if _name in s.displayName:
                                cl.sendMessage(msg.to,"-> " + _name + " was here")
                                wait["Invi"] = False
                                break         
                            else:
                                targets.append(invite)
                        if targets == []:
                            pass
                        else:
                            for target in targets:
                                cl.findAndAddContactsByMid(target)
                                cl.inviteIntoGroup(msg.to,[target])
                                cl.sendMessage(msg.to,"➥   ᴅᴏɴᴇ ᴊᴇᴘɪᴛ\n➡" + _name)
                                wait["Invi"] = False
                                break
#===============================

               if msg.contentType == 2:
                   if msg._from in admin:
                       if msg._from in settings["ChangeVideoProfilevid"]:
                            settings["ChangeVideoProfilePicture"][msg._from] = True
                            del settings["ChangeVideoProfilevid"][msg._from]
                            cl.downloadObjectMsg(msg_id,'path','video.mp4')
                            sendTextTemplate1(msg.to,"➥   Sillahkan Kirim Gambar nyah")
               if msg.contentType == 1:
                   if msg._from in admin:
                       if msg._from in settings["ChangeVideoProfilePicture"]:
                            del settings["ChangeVideoProfilePicture"][msg._from]
                            cl.downloadObjectMsg(msg_id,'path','image.jpg')
                            cl.nadyacantikimut('video.mp4','image.jpg')
                            sendTextTemplate1(msg.to,"➥   Vidio Profile Sukses Boss")
               if msg.contentType == 1:
                  if msg._from in admin:
                     if settings["Addimage"]["status"] == True:
                         path = cl.downloadObjectMsg(msg.id)
                         images[settings["Addimage"]["name"]] = str(path)
                         f = codecs.open("image.json","w","utf-8")
                         json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                         sendTextTemplate1(msg.to, "➥   ᴅᴏɴᴇ ɢᴀᴍʙᴀʀ {}".format(str(settings["Addimage"]["name"])))
                         settings["Addimage"]["status"] = False
                         settings["Addimage"]["name"] = ""
               if msg.contentType == 2:
                  if msg._from in admin:
                     if settings["Addvideo"]["status"] == True:
                         path = cl.downloadObjectMsg(msg.id)
                         videos[settings["Addvideo"]["name"]] = str(path)
                         f = codecs.open("video.json","w","utf-8")
                         json.dump(videos, f, sort_keys=True, indent=4, ensure_ascii=False)
                         sendTextTemplate1(msg.to, "➥   Berhasil menambahkan video {}".format(str(settings["Addvideo"]["name"])))
                         settings["Addvideo"]["status"] = False
                         settings["Addvideo"]["name"] = ""
               if msg.contentType == 7:
                  if msg._from in admin:
                     if settings["Addsticker"]["status"] == True:
                         stickers[settings["Addsticker"]["name"]] = {"STKID":msg.contentMetadata["STKID"],"STKPKGID":msg.contentMetadata["STKPKGID"]}
                         f = codecs.open("sticker.json","w","utf-8")
                         json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                         sendTextTemplate1(msg.to, "➥   ᴅᴏɴᴇ sᴛɪᴄᴋᴇʀ {}".format(str(settings["Addsticker"]["name"])))
                         settings["Addsticker"]["status"] = False
                         settings["Addsticker"]["name"] = ""
               if msg.contentType == 3:
                  if msg._from in admin:
                     if settings["Addaudio"]["status"] == True:
                         path = cl.downloadObjectMsg(msg.id)
                         audios[settings["Addaudio"]["name"]] = str(path)
                         f = codecs.open("audio.json","w","utf-8")
                         json.dump(audios, f, sort_keys=True, indent=4, ensure_ascii=False)
                         sendTextTemplate1(msg.to, "➥   Berhasil menambahkan mp3 {}".format(str(settings["Addaudio"]["name"])))
                         settings["Addaudio"]["status"] = False
                         settings["Addaudio"]["name"] = ""
               if msg.contentType == 0:
                  if settings["autoRead"] == True:
                      cl.sendChatChecked(msg.to, msg_id)
                  if text is None:
                      return
                  else:
                         for sticker in stickers:
                            if text.lower() == sticker:
                               sid = stickers[text.lower()]["STKID"]
                               spkg = stickers[text.lower()]["STKPKGID"]
                               cl.sendSticker(to, spkg, sid)
                         for image in images:
                            if text.lower() == image:
                               cl.sendImage(msg.to, images[image])
                         for audio in audios:
                            if text.lower() == audio:
                               cl.sendAudio(msg.to, audios[audio])
                         for video in videos:
                            if text.lower() == video:
                               cl.sendVideo(msg.to, videos[video])
               if msg.contentType == 13:
                 if msg._from in owner:
                  if wait["addbots"] == True:
                    if msg.contentMetadata["mid"] in Bots:
                        sendFooter(msg.to,"➥   Already in bot")
                        wait["addbots"] = True
                    else:
                        Bots.append(msg.contentMetadata["mid"])
                        wait["addbots"] = True
                        sendFooter(msg.to,"➥   Succes add bot")
                 if wait["dellbots"] == True:
                    if msg.contentMetadata["mid"] in Bots:
                        Bots.remove(msg.contentMetadata["mid"])
                        sendFooter(msg.to,"➥   Succes delete bot")
                    else:
                        wait["dellbots"] = True
                        sendFooter(msg.to,"➥ Nothing in bot")
#TEAM TERMUX 01
                 if msg._from in admin:
                  if wait["delFriend"] == True:
                      cl.deleteContact(msg.contentMetadata["mid"])
                      cl.sendReplyMention(msg_id, to, "➥ Udh Euyyy @!", [sender])

                 if msg._from in admin:
                  if wait["addstaff"] == True:
                    if msg.contentMetadata["mid"] in staff:
                        sendFooter(msg.to,"➥ ᴡᴇs ᴊᴀᴅɪ sᴛᴀғғ")
                        wait["addstaff"] = True
                    else:
                        staff.append(msg.contentMetadata["mid"])
                        wait["addstaff"] = True
                        sendFooter(msg.to,"➥ ᴅᴏɴᴇ ᴀᴅᴅsᴛᴀғғ")
                 if wait["dellstaff"] == True:
                    if msg.contentMetadata["mid"] in staff:
                        staff.remove(msg.contentMetadata["mid"])
                        sendFooter(msg.to,"➥ sᴛᴀғғ ᴅɪʜᴀᴘᴜs")
                        wait["dellstaff"] = True
                    else:
                        wait["dellstaff"] = True
                        sendFooter(msg.to,"➥ Contact itu bukan staff")
#TEAM TERMUX 01
                 if msg._from in admin:
                  if wait["addadmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        sendFooter(msg.to,"➥ Contact itu sudah jadi admin")
                        wait["addadmin"] = True
                    else:
                        admin.append(msg.contentMetadata["mid"])
                        wait["addadmin"] = True
                        sendFooter(msg.to,"➥ ᴅᴏɴᴇ ᴀᴅᴅᴀᴅᴍɪɴ")
                 if wait["delladmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        admin.remove(msg.contentMetadata["mid"])
                        sendFooter(msg.to,"➥ ᴀᴅᴍɪɴ ᴅɪʜᴀᴘᴜs")
                    else:
                        wait["delladmin"] = True
                        sendFooter(msg.to,"➥ Contact itu bukan admin")
#ʀɛʍǟռ ??𝓸➥ 𝓴 𝓑➥ 𝓽𝓼  ʀɛʍǟռ
                 if msg._from in admin:
                  if wait["wblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        sendTextTemplate1(msg.to,"Contact itu sudah ada di blacklist")
                        wait["wblacklist"] = True
                    else:
                        wait["blacklist"][msg.contentMetadata["mid"]] = True
                        wait["wblacklist"] = True
                        sendTextTemplate1(msg.to,"Berhasil menambahkan ke blacklist user")
                  if wait["dblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        del wait["blacklist"][msg.contentMetadata["mid"]]
                        sendTextTemplate1(msg.to,"Berhasil menghapus dari blacklist user")
                    else:
                        wait["dblacklist"] = True
                        sendTextTemplate1(msg.to,"Contact itu tidak ada di blacklist")
#ʀɛʍǟռ ➥ 𝓸𝓻𝓴 ʀɛʍǟռ  ʀɛʍǟռ
                 if msg._from in admin:
                  if wait["Talkwblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                        sendTextTemplate1(msg.to,"Contact itu sudah ada di Talkban")
                        wait["Talkwblacklist"] = True
                    else:
                        wait["Talkblacklist"][msg.contentMetadata["mid"]] = True
                        wait["Talkwblacklist"] = True
                        sendTextTemplate2(msg.to,"Berhasil menambahkan ke Talkban user")
                  if wait["Talkdblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                        del wait["Talkblacklist"][msg.contentMetadata["mid"]]
                        sendTextTemplate2(msg.to,"Berhasil menghapus dari Talkban user")
                    else:
                        wait["Talkdblacklist"] = True
                        sendTextTemplate1(msg.to,"Contact itu tidak ada di Talkban")
#TEAM TERMUX 01
               if msg.contentType == 1:
                 if msg._from in owner:
                    if Setmain["Addimage"] == True:
                        msgid = msg.id
                        fotoo = "https://obs.line-apps.com/talk/m/download.nhn?oid="+msgid
                        headers = cl.Talk.Headers
                        r = requests.get(fotoo, headers=headers, stream=True)
                        if r.status_code == 200:
                            path = os.path.join(os.path.dirname(__file__), 'dataPhotos/%s.jpg' % Setmain["Img"])
                            with open(path, 'wb') as fp:
                                shutil.copyfileobj(r.raw, fp)
                            sendTextTemplate1(msg.to, "Succes add picture")
                        Setmain["Img"] = {}
                        Setmain["Addimage"] = False
               if msg.contentType == 2:
               	if settings["changevp"] == True:
               		contact = cl.getProfile()
               		path = cl.downloadFileURL("https://obs.line-scdn.net/{}".format(contact.pictureStatus))
               		path1 = cl.downloadObjectMsg(msg_id)
               		settings["changevp"] = False
               		changeVideoAndPictureProfile(path, path1)
               		sendTextTemplate1(to, "➥ Sukses Ganti Photo")
               if msg.contentType == 2:
                 if msg._from in owner or msg._from in admin or msg._from in staff:
                   if settings["groupPicture"] == True:
                     path = cl.downloadObjectMsg(msg_id)
                     settings["groupPicture"] = False
                     cl.updateGroupPicture(msg.to, path)
                     sendTextTemplate1(msg.to, "➥ Sukses Ganti Photo")

               if msg.contentType == 1:
                 if msg._from in admin:
                        if mid in Setmain["RAfoto"]:
                            path = cl.downloadObjectMsg(msg_id)
                            del Setmain["RAfoto"][mid]
                            cl.updateProfilePicture(path)
                            sendTextTemplate1(msg.to,"➥ Sukses Ganti Photo")
               if msg.contentType == 1:
                 if msg._from in admin:
                   if settings["changePicture"] == True:
                     path5 = cl.downloadObjectMsg(msg_id)
                     settings["changePicture"] = False
                     cl.updateProfilePicture(path)
                     cl.sendMessage(msg.to, "➥ Sukses Ganti Photo")
               if msg.contentType == 0:
                    if Setmain["autoRead"] == True:
                        cl.sendChatChecked(msg.to, msg_id)
                    if text is None:
                        return
                    else:
                        cmd = command(text)
                        if cmd == "keybot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               helpMessage = keybot()
                               sendTextTemplate25(msg.to, str(helpMessage))
                        if cmd == "notifsmule on":
                            if msg._from in admin:
                                wait["smule"] = True
                                sendTextTemplate1(msg.to, "➥ Share Notif Smule Diaktifkan")
                        elif cmd == "notifsmule off":
                            if msg._from in admin:
                                wait["smule"] = False
                                sendTextTemplate1(msg.to, "➥ Share Notif Smule Dimatikan")
                        if cmd == "notifcall on":
                            if msg._from in admin:
                                wait["responGc"] = True
                                wait["responGc1"] = True
                                wait["responGc2"] = True
                                wait["responGc3"] = True
                                wait["responGc4"] = True
                                wait["responGc5"] = True
                                sendTextTemplate1(msg.to, "➥ ɴᴏᴛɪꜰᴄᴀʟʟ ɢʀᴜᴘ ᴛᴇʟᴀʜ ᴅɪᴀᴋᴛɪꜰᴋᴀɴ")
                        elif cmd == "notifcall off":
                            if msg._from in admin:
                                wait["responGc"] = False
                                wait["responGc1"] = False
                                wait["responGc2"] = False
                                wait["responGc3"] = False
                                wait["responGc4"] = False
                                wait["responGc5"] = False
                                sendTextTemplate1(msg.to, "➥ ɴᴏᴛɪꜰᴄᴀʟʟ ɢʀᴜᴘ ᴛᴇʟᴀʜ ᴅɪᴍᴀᴛɪᴋᴀɴ")
                        if cmd == "notifyoutube on":
                            if msg._from in admin:
                                wait["ytube"] = True
                                sendTextTemplate1(msg.to, "➥ ɴᴏᴛɪꜰʏᴏᴜᴛᴜʙᴇ ᴛᴇʟᴀʜ ᴅɪᴀᴋᴛɪꜰᴋᴀɴ")
                        elif cmd == "notifyoutube off":
                            if msg._from in admin:
                                wait["ytube"] = False
                                sendTextTemplate1(msg.to, "➥ ɴᴏᴛɪꜰʏᴏᴜᴛᴜʙᴇ ᴛᴇʟᴀʜ ᴅɪᴍᴀᴛɪᴋᴀɴ")
                        elif cmd == "cvp":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                            	settings["changevp"] = True
                            	sendTextTemplate1(msg.to, "➥ ꜱʜᴀʀᴇ ᴘʜᴏᴛᴏ ᴘʀᴏꜰɪʟᴇ")
                                                    
                        elif cmd == "respon" or cmd == "rp":
                          if wait["selfbot"] == True:
                            #ifg._from in admin:
                               start = time.time()
                               cl.sendMessage(msg.to, "TEAM TERMUX 01")
                               elapsed_time = time.time() - start
                               cl.sendMessage(msg.to, "╚☆Ⓢⓘⓐⓟ☆╗\n╚Ⓚⓞⓜⓐⓝⓓⓝ╮╗".format(str(elapsed_time)))
                               
                        elif cmd == "order" or cmd == "limit":
                          #if msgfrom in admin:
                             cl.sendMessage(msg.to,"──────┅➥  ➥  ➥  ➥  ➥  ┅──────\nTEAM TERMUX 01\n────────┅┅───────\n➥   ORDERAN PROMO\n➥   ᴛᴏᴋᴇɴ ᴘʀɪᴍᴀʀʏ\n➥   ᴠᴘꜱ ʙᴜʟᴀɴᴀɴ\n➥   ʙᴏᴛ ᴡᴀʀ ɢᴏʟᴀɴɢ\n➥   ʙᴏᴛ ᴡᴀʀ ᴘᴜʀɢᴇ\n➥   ᴛᴇʀɪᴍᴀ ʙɪᴋɪɴ ꜱᴄ ʙᴏᴛ\n➥   ᴀᴘɪ ᴋᴇʏ ʙᴜʟᴀɴᴀɴ\n➥   ᴘʀᴏᴛᴇᴄᴛ ʏᴏᴜʀ ɢʀᴜᴘ\n➥   ʙᴏᴛ ᴄʜᴀᴛ ᴏꜰꜰɪᴄɪᴀʟ\n➥   ᴘᴇᴍʙᴀʏᴀʀᴀɴ ᴠɪᴀ ᴘᴜʟꜱᴀ&ʙᴀɴᴋ\n─────────┅┅─────────\n  ✯ꜱᴜᴘᴘᴏʀᴛ: ʀᴇᴍᴀɴ ʙᴏᴛꜱ✯\nhttp://line.me/ti/p/~linux.1\n➥  ᴡʜᴀᴛꜱᴀᴘᴘ: 085757076639\n────────┅➥  ➥  ➥  ➥  ➥  ┅────────")
                             msg.contentType = 13
                             msg.contentMetadata = {'mid': admin}
                             tanya = msg.text.replace("order ","")
                             jawab = ("──────┅➥  ➥  ➥  ➥  ➥  ┅──────\nTEAM TERMUX 01\n────────┅┅───────\n➥   ORDERAN PROMO\n➥   ᴛᴏᴋᴇɴ ᴘʀɪᴍᴀʀʏ\n➥   ᴠᴘꜱ ʙᴜʟᴀɴᴀɴ\n➥   ʙᴏᴛ ᴡᴀʀ ɢᴏʟᴀɴɢ\n➥   ʙᴏᴛ ᴡᴀʀ ᴘᴜʀɢᴇ\n➥   ᴛᴇʀɪᴍᴀ ʙɪᴋɪɴ ꜱᴄ ʙᴏᴛ\n➥   ᴀᴘɪ ᴋᴇʏ ʙᴜʟᴀɴᴀɴ\n➥   ᴘʀᴏᴛᴇᴄᴛ ʏᴏᴜʀ ɢʀᴜᴘ\n➥   ʙᴏᴛ ᴄʜᴀᴛ ᴏꜰꜰɪᴄɪᴀʟ\n➥   ᴘᴇᴍʙᴀʏᴀʀᴀɴ ᴠɪᴀ ᴘᴜʟꜱᴀ&ʙᴀɴᴋ\n─────────┅┅─────────\n  ✯ꜱᴜᴘᴘᴏʀᴛ: ʀᴇᴍᴀɴ ʙᴏᴛꜱ✯\nhttp://line.me/ti/p/~linux.1\n➥   ᴡʜᴀᴛꜱᴀᴘᴘ: 085757076639\n────────┅➥  ➥  ➥  ➥  ➥  ┅────────")
                             jawaban = random.choice(jawab)
                             tts = gTTS(text=jawaban, lang='id')
                             tts.save('tts.mp3')
                             cl.sendAudio(msg.to,'tts.mp3')
                             sendFooter(msg)         
                             sendFooter(msg.to,"Jika Berminat Langsung Hubungi Kami Ya Trima Kasih😊😊")
                        elif cmd.startswith("ambilqrdi "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                proses = text.split(" ")
                                key = text.replace(proses[0] + " ","")
                                keyy = key.split()
                                number = keyy[0]
                                g = cl.getGroupIdsJoined()
                                try:
                                    groups = g[int(number)-1]
                                    G = cl.getGroup(groups)
                                    G.preventedJoinByTicket = False
                                    cl.updateGroup(G)
                                    if G.preventedJoinByTicket == True:
                                        G.preventedJoinByTicket = False
                                    gurl = cl.reissueGroupTicket(groups)
                                    gTicket = "http://line.me/R/ti/g/{}".format(gurl)
                                    cl.sendMessage(msg.to,"Group {} \nLinkqr {}".format(G.name, gTicket))
                                except Exception as e:
                                    cl.sendText(msg.to," "+str(e))
                        elif cmd == "creator" or text.lower() == 'creator':
                            #if m_from in admin:
                                cl.sendText(msg.to,"♽ TEAM TERMUX 01 V 1 ♽") 
                                ma = "u6459106c8251205f79c2f037cd99b6a4"
                                for i in creator:
                                    ma = cl.getContact(i)
                                    cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)
                                                         
                        elif cmd == "help":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               contact = cl.getProfile()
                               mids = [contact.mid]
                               cover = cl.getProfileCoverURL(sender)
                               listTimeLiking = time.time()
                               tz = pytz.timezone("Asia/Jakarta")
                               timeNow = datetime.now(tz=tz)
                               data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX 01",
                                       "contents": 
{                                      
 "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co/sWq7Lzk/20200724-235608.jpg",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "1:2",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "SALE",
                "color": "#ffffff",
                "align": "center",
                "size": "xs",
                "offsetTop": "3px"
              },
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
                "position": "absolute",
                "align": "center",
                "gravity": "top",
                "aspectMode": "cover",
                "aspectRatio": "1:1",
                "action": {
                  "type": "uri",
                  "uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"
                }
              }
            ],
            "position": "absolute",
            "offsetTop": "22px",
            "offsetStart": "2px",
            "height": "53px",
            "width": "53px",
            "borderWidth": "1px",
            "borderColor": "#FFFFFF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "ʜᴇʟᴘ ᴄᴏᴍᴇɴᴅ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "align": "start",
                "offsetTop": "3px",
                "offsetStart": "14px"
              }
            ],
            "position": "absolute",
            "width": "146px",
            "height": "23px",
            "borderWidth": "1px",
            "borderColor": "#FFFFFF",
            "offsetTop": "74px",
            "offsetStart": "2px",
            "backgroundColor": "#880000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "hello, world",
                "color": "#808080"
              }
            ],
            "position": "absolute",
            "width": "93px",
            "height": "46px",
            "backgroundColor": "#808080",
            "offsetTop": "22px",
            "offsetStart": "55px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Z  U  L",
                "size": "xs",
                "color": "#FFFFFF",
                "weight": "bold",
                "align": "center",
                "gravity": "top",
                #"offsetTop": "1px"
              }
            ],
            "position": "absolute",
            "backgroundColor": "#880000",
            "width": "88px",
            "height": "18px",
            "offsetStart": "57px",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF",
            "offsetTop": "25px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEAM TERMUX 01",
                "size": "xxs",
                "color": "#000000",
                "weight": "bold",
                "align": "center",
                "offsetTop": "1px"
              }
            ],
            "position": "absolute",
            "width": "88px",
            "height": "18px",
            "backgroundColor": "#FFCC00",
            "offsetStart": "57px",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF",
            "offsetTop": "46px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♽ ᴜɴꜱᴇɴᴅᴍᴇ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "width": "105px",
            "height": "18px",
            "backgroundColor": "#880000",
            "offsetTop": "105px",
            "offsetStart": "2px",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "LOGO",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "align": "center",
                "offsetTop": "4px"
              }
            ],
            "position": "absolute",
            "width": "38px",
            "height": "23px",
            "borderWidth": "1px",
            "borderColor": "#FFFFFF",
            "offsetTop": "74px",
            "offsetStart": "110px",
            "backgroundColor": "#0000FF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♽ ꜱɪᴅᴇʀ ᴏɴ/ᴏꜰꜰ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "width": "105px",
            "height": "18px",
            "backgroundColor": "#880000",
            "offsetStart": "2px",
            "offsetTop": "125px",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♽ ʀᴇꜱᴘᴏɴ1 ᴏɴ/ᴏꜰꜰ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "width": "105px",
            "height": "18px",
            "backgroundColor": "#880000",
            "offsetTop": "145px",
            "offsetStart": "2px",
            "position": "absolute",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♽ ʀᴇꜱᴘᴏɴ2 ᴏɴ/ᴏꜰꜰ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "height": "18px",
            "width": "105px",
            "backgroundColor": "#880000",
            "offsetTop": "165px",
            "offsetStart": "2px",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "hello, world"
              }
            ],
            "position": "absolute",
            "width": "38px",
            "height": "156px",
            "borderWidth": "1px",
            "borderColor": "#FFFFFF",
            "offsetStart": "110px",
            "offsetTop": "96px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Line"
              },
              {
                "type": "image",
                "url": "https://i.ibb.co/pZzbq9q/20190726-210038.jpg",
                "position": "absolute",
                "gravity": "center",
                "size": "full",
                "aspectRatio": "1:1",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "30px",
            "height": "30px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "cornerRadius": "25px",
            "offsetStart": "114px",
            "offsetTop": "100px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Smule"
              },
              {
                "type": "image",
                "url": "https://i.ibb.co/wsb7Z81/20190726-205448.jpg",
                "position": "absolute",
                "gravity": "top",
                "size": "full",
                "aspectRatio": "1:1",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "30px",
            "height": "30px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "cornerRadius": "25px",
            "offsetStart": "114px",
            "offsetTop": "138px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Camera"
              },
              {
                "type": "image",
                "url": "https://i.ibb.co/SK6pL2H/20190726-211539.jpg",
                "position": "absolute",
                "gravity": "top",
                "size": "full",
                "aspectRatio": "1:1",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "30px",
            "height": "30px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "cornerRadius": "25px",
            "offsetStart": "114px",
            "offsetTop": "176px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Crome"
              },
              {
                "type": "image",
                "url": "https://i.ibb.co/NSZ7rWy/20190726-205849.jpg",
                "position": "absolute",
                "size": "full",
                "gravity": "center",
                "aspectRatio": "1:1",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "30px",
            "height": "30px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "cornerRadius": "25px",
            "offsetStart": "114px",
            "offsetTop": "215px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": ".",
                "color": "#880000",
                "position": "absolute",
                "offsetTop": "50px"
              }
            ],
            "width": "34px",
            "height": "35px",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "position": "absolute",
            "offsetStart": "112px",
            "offsetTop": "98px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "http://line.me/ti/p/~linux.1"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": ".",
                "color": "#990000",
                "position": "absolute",
                "offsetTop": "50px"
              }
            ],
            "width": "34px",
            "height": "35px",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "position": "absolute",
            "offsetStart": "112px",
            "offsetTop": "135px",
            "action": {
              "type": "uri",
              "uri": "http://line.me/ti/p/~linux.1"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": ".",
                "color": "#990000",
                "position": "absolute",
                "offsetTop": "30px"
              }
            ],
            "position": "absolute",
            "width": "34px",
            "height": "37px",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "offsetStart": "112px",
            "action": {
              "type": "uri",
              "uri": "http://line.me/ti/p/~linux.1"
            },
            "offsetTop": "172px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": ".",
                "color": "#990000",
                "offsetTop": "40px"
              }
            ],
            "position": "absolute",
            "width": "34px",
            "height": "37px",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "offsetStart": "112px",
            "action": {
              "type": "uri",
              "uri": "http://line.me/ti/p/~linux.1"
            },
            "offsetTop": "211px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "CREATOR BY : Zulkifli",
                "size": "xxs",
                "color": "#000000",
                "weight": "bold",
                "align": "center",
                "offsetTop": "3px"
              }
            ],
            "position": "absolute",
            "offsetTop": "251px",
            "borderColor": "#000000",
            "borderWidth": "1px",
            "width": "155px",
            "height": "22px",
            "backgroundColor": "#FFCC00",
            "action": {
              "type": "uri",
              "uri": "http://line.me/ti/p/~linux.1"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♽ ʀᴇꜱᴘᴏɴ3 ᴏɴ/ᴏꜰꜰ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "width": "105px",
            "height": "18px",
            "backgroundColor": "#880000",
            "position": "absolute",
            "offsetTop": "185px",
            "offsetStart": "2px",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♽ ʀᴇꜱᴘᴏɴ4 ᴏɴ/ᴏꜰꜰ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "width": "105px",
            "height": "18px",
            "backgroundColor": "#880000",
            "offsetTop": "205px",
            "offsetStart": "2px",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♽ ʀᴇꜱᴘᴏɴᴘᴍ ᴏɴ/ᴏꜰꜰ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "width": "105px",
            "height": "18px",
            "backgroundColor": "#880000",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF",
            "offsetTop": "225px",
            "offsetStart": "2px"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "5px",
        "borderColor": "#FFCc00",
        "cornerRadius": "10px"
      }
    },
     {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co/sWq7Lzk/20200724-235608.jpg",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "1:2",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "SALE",
                "color": "#ffffff",
                "align": "center",
                "size": "xs",
                "offsetTop": "3px"
              },
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
                "position": "absolute",
                "align": "center",
                "gravity": "top",
                "aspectMode": "cover",
                "aspectRatio": "1:1",
                "action": {
                  "type": "uri",
                  "uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"
                }
              }
            ],
            "position": "absolute",
            "offsetTop": "22px",
            "offsetStart": "2px",
            "height": "53px",
            "width": "53px",
            "borderWidth": "1px",
            "borderColor": "#FFFFFF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "ʜᴇʟᴘ ᴄᴏᴍᴇɴᴅ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "align": "start",
                "offsetTop": "3px",
                "offsetStart": "14px"
              }
            ],
            "position": "absolute",
            "width": "146px",
            "height": "23px",
            "borderWidth": "1px",
            "borderColor": "#FFFFFF",
            "offsetTop": "74px",
            "offsetStart": "2px",
            "backgroundColor": "#880000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "hello, world",
                "color": "#808080"
              }
            ],
            "position": "absolute",
            "width": "93px",
            "height": "46px",
            "backgroundColor": "#808080",
            "offsetTop": "22px",
            "offsetStart": "55px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Z  U  L",
                "size": "xs",
                "color": "#FFFFFF",
                "weight": "bold",
                "align": "center",
                "gravity": "top",
                #"offsetTop": "1px"
              }
            ],
            "position": "absolute",
            "backgroundColor": "#880000",
            "width": "88px",
            "height": "18px",
            "offsetStart": "57px",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF",
            "offsetTop": "25px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEAM TERMUX 01",
                "size": "xxs",
                "color": "#000000",
                "weight": "bold",
                "align": "center",
                "offsetTop": "1px"
              }
            ],
            "position": "absolute",
            "width": "88px",
            "height": "18px",
            "backgroundColor": "#FFCC00",
            "offsetStart": "57px",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF",
            "offsetTop": "46px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♽ ᴄᴠᴘ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "width": "105px",
            "height": "18px",
            "backgroundColor": "#880000",
            "offsetTop": "105px",
            "offsetStart": "2px",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "LOGO",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "align": "center",
                "offsetTop": "4px"
              }
            ],
            "position": "absolute",
            "width": "38px",
            "height": "23px",
            "borderWidth": "1px",
            "borderColor": "#FFFFFF",
            "offsetTop": "74px",
            "offsetStart": "110px",
            "backgroundColor": "#0000FF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♽ ᴍʏꜰᴏᴛᴏ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "width": "105px",
            "height": "18px",
            "backgroundColor": "#880000",
            "offsetStart": "2px",
            "offsetTop": "125px",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♽ ꜱᴀɴᴛᴇᴛ ᴍᴀɴᴛᴀɴ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "width": "105px",
            "height": "18px",
            "backgroundColor": "#880000",
            "offsetTop": "145px",
            "offsetStart": "2px",
            "position": "absolute",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♽ ꜱᴘ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "height": "18px",
            "width": "105px",
            "backgroundColor": "#880000",
            "offsetTop": "165px",
            "offsetStart": "2px",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "hello, world"
              }
            ],
            "position": "absolute",
            "width": "38px",
            "height": "156px",
            "borderWidth": "1px",
            "borderColor": "#FFFFFF",
            "offsetStart": "110px",
            "offsetTop": "96px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Line"
              },
              {
                "type": "image",
                "url": "https://i.ibb.co/pZzbq9q/20190726-210038.jpg",
                "position": "absolute",
                "gravity": "center",
                "size": "full",
                "aspectRatio": "1:1",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "30px",
            "height": "30px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "cornerRadius": "25px",
            "offsetStart": "114px",
            "offsetTop": "100px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Smule"
              },
              {
                "type": "image",
                "url": "https://i.ibb.co/wsb7Z81/20190726-205448.jpg",
                "position": "absolute",
                "gravity": "top",
                "size": "full",
                "aspectRatio": "1:1",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "30px",
            "height": "30px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "cornerRadius": "25px",
            "offsetStart": "114px",
            "offsetTop": "138px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Camera"
              },
              {
                "type": "image",
                "url": "https://i.ibb.co/SK6pL2H/20190726-211539.jpg",
                "position": "absolute",
                "gravity": "top",
                "size": "full",
                "aspectRatio": "1:1",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "30px",
            "height": "30px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "cornerRadius": "25px",
            "offsetStart": "114px",
            "offsetTop": "176px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Crome"
              },
              {
                "type": "image",
                "url": "https://i.ibb.co/NSZ7rWy/20190726-205849.jpg",
                "position": "absolute",
                "size": "full",
                "gravity": "center",
                "aspectRatio": "1:1",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "30px",
            "height": "30px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "cornerRadius": "25px",
            "offsetStart": "114px",
            "offsetTop": "215px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": ".",
                "color": "#880000",
                "position": "absolute",
                "offsetTop": "50px"
              }
            ],
            "width": "34px",
            "height": "35px",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "position": "absolute",
            "offsetStart": "112px",
            "offsetTop": "98px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "http://line.me/ti/p/~linux.1"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": ".",
                "color": "#990000",
                "position": "absolute",
                "offsetTop": "50px"
              }
            ],
            "width": "34px",
            "height": "35px",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "position": "absolute",
            "offsetStart": "112px",
            "offsetTop": "135px",
            "action": {
              "type": "uri",
              "uri": "http://line.me/ti/p/~linux.1"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": ".",
                "color": "#990000",
                "position": "absolute",
                "offsetTop": "30px"
              }
            ],
            "position": "absolute",
            "width": "34px",
            "height": "37px",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "offsetStart": "112px",
            "action": {
              "type": "uri",
              "uri": "http://line.me/ti/p/~linux.1"
            },
            "offsetTop": "172px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": ".",
                "color": "#990000",
                "offsetTop": "40px"
              }
            ],
            "position": "absolute",
            "width": "34px",
            "height": "37px",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "offsetStart": "112px",
            "action": {
              "type": "uri",
              "uri": "http://line.me/ti/p/~linux.1"
            },
            "offsetTop": "211px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "CREATOR BY : Zulkifli",
                "size": "xxs",
                "color": "#000000",
                "weight": "bold",
                "align": "center",
                "offsetTop": "3px"
              }
            ],
            "position": "absolute",
            "offsetTop": "251px",
            "borderColor": "#000000",
            "borderWidth": "1px",
            "width": "155px",
            "height": "22px",
            "backgroundColor": "#FFCC00",
            "action": {
              "type": "uri",
              "uri": "http://line.me/ti/p/~linux.1"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♽ ɴᴏᴛɪꜰᴄᴀʟʟ ᴏɴ/ᴏꜰꜰ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "width": "105px",
            "height": "18px",
            "backgroundColor": "#880000",
            "position": "absolute",
            "offsetTop": "185px",
            "offsetStart": "2px",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♽ ɴᴏᴛɪꜰꜱᴍᴜʟᴇ ᴏɴ/ᴏꜰꜰ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "width": "105px",
            "height": "18px",
            "backgroundColor": "#880000",
            "offsetTop": "205px",
            "offsetStart": "2px",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♽ ɴᴏᴛɪꜰʏᴏᴜᴛᴜʙᴇ ᴏɴ/ᴏꜰꜰ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "width": "105px",
            "height": "18px",
            "backgroundColor": "#880000",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF",
            "offsetTop": "225px",
            "offsetStart": "2px"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "5px",
        "borderColor": "#FFCc00",
        "cornerRadius": "10px"
      }
    },
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co/sWq7Lzk/20200724-235608.jpg",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "1:2",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "SALE",
                "color": "#ffffff",
                "align": "center",
                "size": "xs",
                "offsetTop": "3px"
              },
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
                "position": "absolute",
                "align": "center",
                "gravity": "top",
                "aspectMode": "cover",
                "aspectRatio": "1:1",
                "action": {
                  "type": "uri",
                  "uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"
                }
              }
            ],
            "position": "absolute",
            "offsetTop": "22px",
            "offsetStart": "2px",
            "height": "53px",
            "width": "53px",
            "borderWidth": "1px",
            "borderColor": "#FFFFFF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "ʜᴇʟᴘ ᴄᴏᴍᴇɴᴅ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "align": "start",
                "offsetTop": "3px",
                "offsetStart": "14px"
              }
            ],
            "position": "absolute",
            "width": "146px",
            "height": "23px",
            "borderWidth": "1px",
            "borderColor": "#FFFFFF",
            "offsetTop": "74px",
            "offsetStart": "2px",
            "backgroundColor": "#880000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "hello, world",
                "color": "#808080"
              }
            ],
            "position": "absolute",
            "width": "93px",
            "height": "46px",
            "backgroundColor": "#808080",
            "offsetTop": "22px",
            "offsetStart": "55px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Z  U  L",
                "size": "xs",
                "color": "#FFFFFF",
                "weight": "bold",
                "align": "center",
                "gravity": "top",
                #"offsetTop": "1px"
              }
            ],
            "position": "absolute",
            "backgroundColor": "#880000",
            "width": "88px",
            "height": "18px",
            "offsetStart": "57px",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF",
            "offsetTop": "25px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEAM TERMUX 01",
                "size": "xxs",
                "color": "#000000",
                "weight": "bold",
                "align": "center",
                "offsetTop": "1px"
              }
            ],
            "position": "absolute",
            "width": "88px",
            "height": "18px",
            "backgroundColor": "#FFCC00",
            "offsetStart": "57px",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF",
            "offsetTop": "46px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♽ ʟɪꜱᴛᴠɪᴅᴇᴏ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "width": "105px",
            "height": "18px",
            "backgroundColor": "#880000",
            "offsetTop": "105px",
            "offsetStart": "2px",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "LOGO",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "align": "center",
                "offsetTop": "4px"
              }
            ],
            "position": "absolute",
            "width": "38px",
            "height": "23px",
            "borderWidth": "1px",
            "borderColor": "#FFFFFF",
            "offsetTop": "74px",
            "offsetStart": "110px",
            "backgroundColor": "#0000FF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♽ ᴅᴇʟʟᴠɪᴅᴇᴏ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "width": "105px",
            "height": "18px",
            "backgroundColor": "#880000",
            "offsetStart": "2px",
            "offsetTop": "125px",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♽ ᴀᴅᴅᴠɪᴅᴇᴏ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "width": "105px",
            "height": "18px",
            "backgroundColor": "#880000",
            "offsetTop": "145px",
            "offsetStart": "2px",
            "position": "absolute",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♽ ʟɪꜱᴛɪᴍᴀɢᴇ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "height": "18px",
            "width": "105px",
            "backgroundColor": "#880000",
            "offsetTop": "165px",
            "offsetStart": "2px",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "hello, world"
              }
            ],
            "position": "absolute",
            "width": "38px",
            "height": "156px",
            "borderWidth": "1px",
            "borderColor": "#FFFFFF",
            "offsetStart": "110px",
            "offsetTop": "96px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Line"
              },
              {
                "type": "image",
                "url": "https://i.ibb.co/pZzbq9q/20190726-210038.jpg",
                "position": "absolute",
                "gravity": "center",
                "size": "full",
                "aspectRatio": "1:1",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "30px",
            "height": "30px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "cornerRadius": "25px",
            "offsetStart": "114px",
            "offsetTop": "100px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Smule"
              },
              {
                "type": "image",
                "url": "https://i.ibb.co/wsb7Z81/20190726-205448.jpg",
                "position": "absolute",
                "gravity": "top",
                "size": "full",
                "aspectRatio": "1:1",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "30px",
            "height": "30px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "cornerRadius": "25px",
            "offsetStart": "114px",
            "offsetTop": "138px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Camera"
              },
              {
                "type": "image",
                "url": "https://i.ibb.co/SK6pL2H/20190726-211539.jpg",
                "position": "absolute",
                "gravity": "top",
                "size": "full",
                "aspectRatio": "1:1",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "30px",
            "height": "30px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "cornerRadius": "25px",
            "offsetStart": "114px",
            "offsetTop": "176px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Crome"
              },
              {
                "type": "image",
                "url": "https://i.ibb.co/NSZ7rWy/20190726-205849.jpg",
                "position": "absolute",
                "size": "full",
                "gravity": "center",
                "aspectRatio": "1:1",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "30px",
            "height": "30px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "cornerRadius": "25px",
            "offsetStart": "114px",
            "offsetTop": "215px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": ".",
                "color": "#880000",
                "position": "absolute",
                "offsetTop": "50px"
              }
            ],
            "width": "34px",
            "height": "35px",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "position": "absolute",
            "offsetStart": "112px",
            "offsetTop": "98px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "http://line.me/ti/p/~linux.1"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": ".",
                "color": "#990000",
                "position": "absolute",
                "offsetTop": "50px"
              }
            ],
            "width": "34px",
            "height": "35px",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "position": "absolute",
            "offsetStart": "112px",
            "offsetTop": "135px",
            "action": {
              "type": "uri",
              "uri": "http://line.me/ti/p/~linux.1"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": ".",
                "color": "#990000",
                "position": "absolute",
                "offsetTop": "30px"
              }
            ],
            "position": "absolute",
            "width": "34px",
            "height": "37px",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "offsetStart": "112px",
            "action": {
              "type": "uri",
              "uri": "http://line.me/ti/p/~linux.1"
            },
            "offsetTop": "172px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": ".",
                "color": "#990000",
                "offsetTop": "40px"
              }
            ],
            "position": "absolute",
            "width": "34px",
            "height": "37px",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "offsetStart": "112px",
            "action": {
              "type": "uri",
              "uri": "http://line.me/ti/p/~linux.1"
            },
            "offsetTop": "211px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "CREATOR BY : Zulkifli",
                "size": "xxs",
                "color": "#000000",
                "weight": "bold",
                "align": "center",
                "offsetTop": "3px"
              }
            ],
            "position": "absolute",
            "offsetTop": "251px",
            "borderColor": "#000000",
            "borderWidth": "1px",
            "width": "155px",
            "height": "22px",
            "backgroundColor": "#FFCC00",
            "action": {
              "type": "uri",
              "uri": "http://line.me/ti/p/~linux.1"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♽ ᴅᴇʟʟɪᴍɢ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "width": "105px",
            "height": "18px",
            "backgroundColor": "#880000",
            "position": "absolute",
            "offsetTop": "185px",
            "offsetStart": "2px",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♽ ᴀᴅᴅɪᴍɢ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "width": "105px",
            "height": "18px",
            "backgroundColor": "#880000",
            "offsetTop": "205px",
            "offsetStart": "2px",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♽ ᴄᴇᴋ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "width": "105px",
            "height": "18px",
            "backgroundColor": "#880000",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF",
            "offsetTop": "225px",
            "offsetStart": "2px"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "5px",
        "borderColor": "#FFCc00",
        "cornerRadius": "10px"
      }
    },
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co/sWq7Lzk/20200724-235608.jpg",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "1:2",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "SALE",
                "color": "#ffffff",
                "align": "center",
                "size": "xs",
                "offsetTop": "3px"
              },
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
                "position": "absolute",
                "align": "center",
                "gravity": "top",
                "aspectMode": "cover",
                "aspectRatio": "1:1",
                "action": {
                  "type": "uri",
                  "uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"
                }
              }
            ],
            "position": "absolute",
            "offsetTop": "22px",
            "offsetStart": "2px",
            "height": "53px",
            "width": "53px",
            "borderWidth": "1px",
            "borderColor": "#FFFFFF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "ʜᴇʟᴘ ᴄᴏᴍᴇɴᴅ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "align": "start",
                "offsetTop": "3px",
                "offsetStart": "14px"
              }
            ],
            "position": "absolute",
            "width": "146px",
            "height": "23px",
            "borderWidth": "1px",
            "borderColor": "#FFFFFF",
            "offsetTop": "74px",
            "offsetStart": "2px",
            "backgroundColor": "#880000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "hello, world",
                "color": "#808080"
              }
            ],
            "position": "absolute",
            "width": "93px",
            "height": "46px",
            "backgroundColor": "#808080",
            "offsetTop": "22px",
            "offsetStart": "55px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Z  U  L",
                "size": "xs",
                "color": "#FFFFFF",
                "weight": "bold",
                "align": "center",
                "gravity": "top",
                #"offsetTop": "1px"
              }
            ],
            "position": "absolute",
            "backgroundColor": "#880000",
            "width": "88px",
            "height": "18px",
            "offsetStart": "57px",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF",
            "offsetTop": "25px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEAM TERMUX 01",
                "size": "xxs",
                "color": "#000000",
                "weight": "bold",
                "align": "center",
                "offsetTop": "1px"
              }
            ],
            "position": "absolute",
            "width": "88px",
            "height": "18px",
            "backgroundColor": "#FFCC00",
            "offsetStart": "57px",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF",
            "offsetTop": "46px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♽ ꜱᴍᴜʟᴇ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "width": "105px",
            "height": "18px",
            "backgroundColor": "#880000",
            "offsetTop": "105px",
            "offsetStart": "2px",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "LOGO",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "align": "center",
                "offsetTop": "4px"
              }
            ],
            "position": "absolute",
            "width": "38px",
            "height": "23px",
            "borderWidth": "1px",
            "borderColor": "#FFFFFF",
            "offsetTop": "74px",
            "offsetStart": "110px",
            "backgroundColor": "#0000FF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♽ ʙʏᴇᴍᴇ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "width": "105px",
            "height": "18px",
            "backgroundColor": "#880000",
            "offsetStart": "2px",
            "offsetTop": "125px",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♽ ꜱᴇᴛ ᴍᴇɴᴛɪᴏɴ:",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "width": "105px",
            "height": "18px",
            "backgroundColor": "#880000",
            "offsetTop": "145px",
            "offsetStart": "2px",
            "position": "absolute",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♽ ꜱᴇᴛ ʀᴇꜱᴘᴏɴ:",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "height": "18px",
            "width": "105px",
            "backgroundColor": "#880000",
            "offsetTop": "165px",
            "offsetStart": "2px",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "hello, world"
              }
            ],
            "position": "absolute",
            "width": "38px",
            "height": "156px",
            "borderWidth": "1px",
            "borderColor": "#FFFFFF",
            "offsetStart": "110px",
            "offsetTop": "96px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Line"
              },
              {
                "type": "image",
                "url": "https://i.ibb.co/pZzbq9q/20190726-210038.jpg",
                "position": "absolute",
                "gravity": "center",
                "size": "full",
                "aspectRatio": "1:1",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "30px",
            "height": "30px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "cornerRadius": "25px",
            "offsetStart": "114px",
            "offsetTop": "100px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Smule"
              },
              {
                "type": "image",
                "url": "https://i.ibb.co/wsb7Z81/20190726-205448.jpg",
                "position": "absolute",
                "gravity": "top",
                "size": "full",
                "aspectRatio": "1:1",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "30px",
            "height": "30px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "cornerRadius": "25px",
            "offsetStart": "114px",
            "offsetTop": "138px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Camera"
              },
              {
                "type": "image",
                "url": "https://i.ibb.co/SK6pL2H/20190726-211539.jpg",
                "position": "absolute",
                "gravity": "top",
                "size": "full",
                "aspectRatio": "1:1",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "30px",
            "height": "30px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "cornerRadius": "25px",
            "offsetStart": "114px",
            "offsetTop": "176px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Crome"
              },
              {
                "type": "image",
                "url": "https://i.ibb.co/NSZ7rWy/20190726-205849.jpg",
                "position": "absolute",
                "size": "full",
                "gravity": "center",
                "aspectRatio": "1:1",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "30px",
            "height": "30px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "cornerRadius": "25px",
            "offsetStart": "114px",
            "offsetTop": "215px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": ".",
                "color": "#880000",
                "position": "absolute",
                "offsetTop": "50px"
              }
            ],
            "width": "34px",
            "height": "35px",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "position": "absolute",
            "offsetStart": "112px",
            "offsetTop": "98px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "http://line.me/ti/p/~linux.1"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": ".",
                "color": "#990000",
                "position": "absolute",
                "offsetTop": "50px"
              }
            ],
            "width": "34px",
            "height": "35px",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "position": "absolute",
            "offsetStart": "112px",
            "offsetTop": "135px",
            "action": {
              "type": "uri",
              "uri": "http://line.me/ti/p/~linux.1"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": ".",
                "color": "#990000",
                "position": "absolute",
                "offsetTop": "30px"
              }
            ],
            "position": "absolute",
            "width": "34px",
            "height": "37px",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "offsetStart": "112px",
            "action": {
              "type": "uri",
              "uri": "http://line.me/ti/p/~linux.1"
            },
            "offsetTop": "172px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": ".",
                "color": "#990000",
                "offsetTop": "40px"
              }
            ],
            "position": "absolute",
            "width": "34px",
            "height": "37px",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "offsetStart": "112px",
            "action": {
              "type": "uri",
              "uri": "http://line.me/ti/p/~linux.1"
            },
            "offsetTop": "211px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "CREATOR BY : Zulkifli",
                "size": "xxs",
                "color": "#000000",
                "weight": "bold",
                "align": "center",
                "offsetTop": "3px"
              }
            ],
            "position": "absolute",
            "offsetTop": "251px",
            "borderColor": "#000000",
            "borderWidth": "1px",
            "width": "155px",
            "height": "22px",
            "backgroundColor": "#FFCC00",
            "action": {
              "type": "uri",
              "uri": "http://line.me/ti/p/~linux.1"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♽ ᴡᴇʟᴄᴏᴍᴇ ᴏɴ/ᴏꜰꜰ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "width": "105px",
            "height": "18px",
            "backgroundColor": "#880000",
            "position": "absolute",
            "offsetTop": "185px",
            "offsetStart": "2px",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♽ ᴀʟʟ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "width": "105px",
            "height": "18px",
            "backgroundColor": "#880000",
            "offsetTop": "205px",
            "offsetStart": "2px",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♽ ᴍʏɴᴀᴍᴇ:",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "width": "105px",
            "height": "18px",
            "backgroundColor": "#880000",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF",
            "offsetTop": "225px",
            "offsetStart": "2px"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "5px",
        "borderColor": "#FFCc00",
        "cornerRadius": "10px"
      }
    },
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co/sWq7Lzk/20200724-235608.jpg",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "1:2",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "SALE",
                "color": "#ffffff",
                "align": "center",
                "size": "xs",
                "offsetTop": "3px"
              },
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
                "position": "absolute",
                "align": "center",
                "gravity": "top",
                "aspectMode": "cover",
                "aspectRatio": "1:1",
                "action": {
                  "type": "uri",
                  "uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"
                }
              }
            ],
            "position": "absolute",
            "offsetTop": "22px",
            "offsetStart": "2px",
            "height": "53px",
            "width": "53px",
            "borderWidth": "1px",
            "borderColor": "#FFFFFF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "ʜᴇʟᴘ ᴄᴏᴍᴇɴᴅ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "align": "start",
                "offsetTop": "3px",
                "offsetStart": "14px"
              }
            ],
            "position": "absolute",
            "width": "146px",
            "height": "23px",
            "borderWidth": "1px",
            "borderColor": "#FFFFFF",
            "offsetTop": "74px",
            "offsetStart": "2px",
            "backgroundColor": "#880000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "hello, world",
                "color": "#808080"
              }
            ],
            "position": "absolute",
            "width": "93px",
            "height": "46px",
            "backgroundColor": "#808080",
            "offsetTop": "22px",
            "offsetStart": "55px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Z  U  L",
                "size": "xs",
                "color": "#FFFFFF",
                "weight": "bold",
                "align": "center",
                "gravity": "top",
                #"offsetTop": "1px"
              }
            ],
            "position": "absolute",
            "backgroundColor": "#880000",
            "width": "88px",
            "height": "18px",
            "offsetStart": "57px",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF",
            "offsetTop": "25px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEAM TERMUX 01",
                "size": "xxs",
                "color": "#000000",
                "weight": "bold",
                "align": "center",
                "offsetTop": "1px"
              }
            ],
            "position": "absolute",
            "width": "88px",
            "height": "18px",
            "backgroundColor": "#FFCC00",
            "offsetStart": "57px",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF",
            "offsetTop": "46px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♽ ᴋᴀʟᴇɴᴅᴇʀ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "width": "105px",
            "height": "18px",
            "backgroundColor": "#880000",
            "offsetTop": "105px",
            "offsetStart": "2px",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "LOGO",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "align": "center",
                "offsetTop": "4px"
              }
            ],
            "position": "absolute",
            "width": "38px",
            "height": "23px",
            "borderWidth": "1px",
            "borderColor": "#FFFFFF",
            "offsetTop": "74px",
            "offsetStart": "110px",
            "backgroundColor": "#0000FF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♽ ɢʀᴜᴘʟɪꜱᴛ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "width": "105px",
            "height": "18px",
            "backgroundColor": "#880000",
            "offsetStart": "2px",
            "offsetTop": "125px",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♽ ᴏᴘᴇɴ Qʀ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "width": "105px",
            "height": "18px",
            "backgroundColor": "#880000",
            "offsetTop": "145px",
            "offsetStart": "2px",
            "position": "absolute",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♽ ᴀᴜᴛᴏᴊᴏɪɴ ᴏɴ/ᴏꜰꜰ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "height": "18px",
            "width": "105px",
            "backgroundColor": "#880000",
            "offsetTop": "165px",
            "offsetStart": "2px",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "hello, world"
              }
            ],
            "position": "absolute",
            "width": "38px",
            "height": "156px",
            "borderWidth": "1px",
            "borderColor": "#FFFFFF",
            "offsetStart": "110px",
            "offsetTop": "96px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Line"
              },
              {
                "type": "image",
                "url": "https://i.ibb.co/pZzbq9q/20190726-210038.jpg",
                "position": "absolute",
                "gravity": "center",
                "size": "full",
                "aspectRatio": "1:1",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "30px",
            "height": "30px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "cornerRadius": "25px",
            "offsetStart": "114px",
            "offsetTop": "100px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Smule"
              },
              {
                "type": "image",
                "url": "https://i.ibb.co/wsb7Z81/20190726-205448.jpg",
                "position": "absolute",
                "gravity": "top",
                "size": "full",
                "aspectRatio": "1:1",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "30px",
            "height": "30px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "cornerRadius": "25px",
            "offsetStart": "114px",
            "offsetTop": "138px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Camera"
              },
              {
                "type": "image",
                "url": "https://i.ibb.co/SK6pL2H/20190726-211539.jpg",
                "position": "absolute",
                "gravity": "top",
                "size": "full",
                "aspectRatio": "1:1",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "30px",
            "height": "30px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "cornerRadius": "25px",
            "offsetStart": "114px",
            "offsetTop": "176px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Crome"
              },
              {
                "type": "image",
                "url": "https://i.ibb.co/NSZ7rWy/20190726-205849.jpg",
                "position": "absolute",
                "size": "full",
                "gravity": "center",
                "aspectRatio": "1:1",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "30px",
            "height": "30px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "cornerRadius": "25px",
            "offsetStart": "114px",
            "offsetTop": "215px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": ".",
                "color": "#880000",
                "position": "absolute",
                "offsetTop": "50px"
              }
            ],
            "width": "34px",
            "height": "35px",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "position": "absolute",
            "offsetStart": "112px",
            "offsetTop": "98px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "http://line.me/ti/p/~linux.1"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": ".",
                "color": "#990000",
                "position": "absolute",
                "offsetTop": "50px"
              }
            ],
            "width": "34px",
            "height": "35px",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "position": "absolute",
            "offsetStart": "112px",
            "offsetTop": "135px",
            "action": {
              "type": "uri",
              "uri": "http://line.me/ti/p/~linux.1"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": ".",
                "color": "#990000",
                "position": "absolute",
                "offsetTop": "30px"
              }
            ],
            "position": "absolute",
            "width": "34px",
            "height": "37px",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "offsetStart": "112px",
            "action": {
              "type": "uri",
              "uri": "http://line.me/ti/p/~linux.1"
            },
            "offsetTop": "172px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": ".",
                "color": "#990000",
                "offsetTop": "40px"
              }
            ],
            "position": "absolute",
            "width": "34px",
            "height": "37px",
            "borderWidth": "1px",
            "borderColor": "#FFCC00",
            "offsetStart": "112px",
            "action": {
              "type": "uri",
              "uri": "http://line.me/ti/p/~linux.1"
            },
            "offsetTop": "211px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "CREATOR BY : Zulkifli",
                "size": "xxs",
                "color": "#000000",
                "weight": "bold",
                "align": "center",
                "offsetTop": "3px"
              }
            ],
            "position": "absolute",
            "offsetTop": "251px",
            "borderColor": "#000000",
            "borderWidth": "1px",
            "width": "155px",
            "height": "22px",
            "backgroundColor": "#FFCC00",
            "action": {
              "type": "uri",
              "uri": "http://line.me/ti/p/~linux.1"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♽ ᴀᴜᴛᴏʙʟᴏᴄᴋ ᴏɴ/ᴏꜰꜰ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "width": "105px",
            "height": "18px",
            "backgroundColor": "#880000",
            "position": "absolute",
            "offsetTop": "185px",
            "offsetStart": "2px",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♽ ᴀᴜᴛᴏʀᴇᴀᴅ ᴏɴ/ᴏꜰꜰ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "width": "105px",
            "height": "18px",
            "backgroundColor": "#880000",
            "offsetTop": "205px",
            "offsetStart": "2px",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "♽ ᴘᴏꜱᴛ ᴏɴ/ᴏꜰꜰ",
                "size": "xxs",
                "color": "#FFFFFF",
                "weight": "bold",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "width": "105px",
            "height": "18px",
            "backgroundColor": "#880000",
           "borderWidth": "1px",
           "borderColor": "#FFFFFF",
            "offsetTop": "225px",
            "offsetStart": "2px"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "5px",
        "borderColor": "#FFCc00",
        "cornerRadius": "10px"
      }
    }
    ]
    }
    }
                               cl.postTemplate(to, data)
                               
                        elif text.lower() == "mymid":
                               sendFooter(msg.to, msg._from)

                        elif cmd == "setting":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                contact = cl.getProfile()
                                mids = [contact.mid]
                                cover = cl.getProfileCoverURL(sender)
                                listTimeLiking = time.time()
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                md = "╔════════════════\n"
                                if settings["checkPost"] == True: md+="╟◈  Autolike : ⦅✅⦆ \n"
                                else: md+="╟◈  Autolike : ⦅❎⦆ \n"
                                if wait["contact"] == True: md+="╟◈  Contact : ⦅✅⦆ \n"
                                else: md+="╟◈  Contact : ⦅❎⦆ \n"
                                if wait["Mentionkick"] == True: md+="╟◈  Notag : ⦅✅⦆ \n"
                                else: md+="╟◈  Notag : ⦅❎⦆ \n"
                                if wait["detectMention"] == True: md+="╟◈  Autorespon : ⦅✅⦆ \n"
                                else: md+="╟◈  Autorespon : ⦅❎⦆ \n"
                                if wait["detectMention2"] == True: md+="╟◈  Autorespon2 : ⦅✅⦆ \n"
                                else: md+="╟◈  Autorespon2 : ⦅❎⦆ \n"
                                if wait["detectMention3"] == True: md+="╟◈  Autorespon3 : ⦅✅⦆ \n"
                                else: md+="╟◈  Autorespon3 : ⦅❎⦆ \n"
                                if wait["detectMention4"] == True: md+="╟◈  Autorespon4 : ⦅✅⦆ \n"
                                else: md+="╟◈  Autorespon4 : ⦅❎⦆ \n"
                                if wait["detectMention5"] == True: md+="╟◈  Autorespon5 : ⦅✅⦆ \n"
                                else: md+="╟◈  Autorespon5 : ⦅❎⦆ \n"
                                if wait["Unsend"] == True: md+="╟◈  Unsend : ⦅✅⦆ \n"
                                else: md+="╟◈  Unsend : ⦅❎⦆ \n"
                                if wait["autoAdd"] == True: md+="╟◈  Autoadd : ⦅✅⦆ \n"
                                else: md+="╟◈  Autoadd : ⦅❎⦆ \n"
                                if wait["autoLeave"] == True: md+="╟◈  Autoleave : ⦅✅⦆ \n"
                                else: md+="╟◈  Autoleave : ⦅❎⦆ \n"
                                if wait["autoJoin"] == True: md+="╟◈  Autojoin : ⦅✅⦆ \n"
                                else: md+="╟◈  Autojoin : ⦅❎⦆ \n"
                                if wait["sticker"] == True: md+="╟◈  Sticker : ⦅✅⦆ \n"
                                else: md+="╟◈  Sticker : ⦅❎⦆ \n"
                                if settings["autoJoinTicket"] == True: md+="╟◈  Jointicket : ⦅✅⦆ \n"
                                else: md+="╟◈  Jointicket : ⦅❎⦆ \n"
                                if wait["autoReject"] == True: md+="╟◈  Autoreject : ⦅✅⦆ \n"
                                else: md+="╟◈  Autoreject : ⦅❎⦆ \n"
                                if wait["autoBlock"] == True: md+="╟◈ Autoblock : ⦅✅⦆ \n"
                                else: md+="╟◈  Autoblock : ⦅❎⦆ \n"
                                if wait["smule"] == True: md+="╟◈  NotifSmule : ⦅✅⦆ \n"
                                else: md+="╟◈  NotifSmule : ⦅❎⦆ \n"
                                if wait["responGc"] == True: md+="╟◈  NotifCall : ⦅✅⦆ \n"
                                else: md+="╟◈  NotifCall : ⦅❎⦆ \n"
                                if wait["ytube"] == True: md+="╟◈  notifyoutube : ⦅✅⦆ \n"
                                else: md+="╟◈  notifyoutube : ⦅❎⦆ \n"                             
                                if settings["welcome"] == True: md+="╟◈  Wellcome : ⦅✅⦆ \n"
                                else: md+="╟◈  Wellcome : ⦅❎⦆ \n╰──────────────╯"                         
                                sendTextTemplate23(msg.to, md+"\n📅 ᴛᴀɴɢɢᴀʟ : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\n⏰ ᴊᴀᴍ [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")
                     
#===========================================================
                        elif text.lower() == "mid":
                          if wait["selfbot"] == True:
                           if msg._from in owner or msg._from in admin:
                               middd = "Name : " +cl.getContact(msg._from).displayName + "\nMid : " +msg._from
                               sendFooter(msg.to,middd)
                         
                        elif cmd == "bot" or text.lower() == 'bot' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ɢᴜᴇ ʙᴜᴋᴀɴ ʙᴏᴛ ᴋᴜʏᴀ ʟᴏᴇ ʏᴀɴɢ ʙᴏᴛ")
                               
                        elif cmd == "pm" or text.lower() == 'pm' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ᴍᴀᴀꜰ ᴛɪᴅᴀᴋ ᴍᴇɴᴇʀɪᴍᴀ ᴘᴍ")
                               
                        elif cmd == "bang" or text.lower() == 'bang' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ᴀᴅᴀ ᴀᴘᴀ ꜱᴀʏᴀɴɢ ᴍᴀᴜ ᴍɪɴᴛᴀ ᴊᴀᴛᴀʜ ʏᴀʜ")
                               
                        elif cmd == "sepi" or text.lower() == 'sepi' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ꜱᴇᴘɪ ᴛɪᴅᴀᴋ ᴀᴅᴀ ᴏʀᴀɴɢ ʟᴀɢɪ ᴘᴀᴅᴀ ᴋᴇʟᴏɴ ᴍᴜɴɢᴋɪɴ")
                               
                        elif cmd == "kangen" or text.lower() == 'kangen' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ꜱᴀᴍᴀ ꜱᴀʏᴀɴɢ ᴀᴋᴜ ᴊᴜɢᴀ ᴋᴀɴɢᴇɴ ᴋᴀᴍᴜ ᴄɪᴜᴍ ᴅᴜʟᴜ ᴅᴏɴɢ")
                               
                        elif cmd == "selamat malam" or text.lower() == 'selamat malam' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ᴍᴀʟᴀᴍ ᴊᴜɢᴀ ꜱᴀʏᴀɴɢ ᴊᴀɴɢᴀɴ ʟᴜᴘᴀ ᴛɪᴅᴜʀ ʏᴀʜ")
                               
                        elif cmd == "selamat pagi" or text.lower() == 'selamat pagi' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ꜱᴇʟᴀᴍᴀᴛ ᴘᴀɢɪ ᴊᴜɢᴀ ꜱᴀʏᴀɴɢᴋᴜ ᴊᴀɴɢᴀɴ ʟᴜᴘᴀ ʙᴀʜᴀɢɪᴀ")
                               
                        elif cmd == "assalamualaikum" or text.lower() == 'as' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ُوَعَلَيْكُمْ السَّلاَمُ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ  ")
                               
                        elif cmd == "selamat siang" or text.lower() == 'selamat siang' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ꜱᴇʟᴀᴍᴀᴛ ꜱɪᴀɴɢ ꜱᴀʏᴀɴɢ ᴊᴀɴɢᴀɴ ʟᴜᴘᴀ ɴɢᴏᴘɪ ʙɪᴀʀ ʙᴀʜᴀɢɪᴀ")
                               
                        elif cmd == "selamat sore" or text.lower() == 'selamat sore' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ꜱᴇʟᴀᴍᴀᴛ ꜱᴏʀᴇ ᴊᴜɢᴀ ᴊᴀɴɢᴀɴ ʟᴜᴘᴀ ᴍᴀɴᴅɪ ʏᴀɴɢ ʙᴇʀꜱɪʜ")
                               
                        elif cmd == "pm mesla" or text.lower() == 'pm mesla' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ᴘᴍ ᴍᴇꜱʀᴀ ᴍᴀᴜ ᴘɪɴᴊᴇᴍ ᴅᴜɪᴛ ɴɪʜ ᴏʀᴀɴɢ")
                               
                        elif cmd == "kojom" or text.lower() == 'kojom' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ᴋᴏᴊᴏᴍ ᴍᴜʟᴜ ᴀᴡᴀꜱ ʜᴘ ɴʏᴀʜ ʙᴜɴᴛɪɴɢ")
                               
                        elif cmd == "bentar" or text.lower() == 'bentar' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ʙᴇɴᴛᴀʀ ᴀᴋᴜ ᴀᴅᴀ ᴛᴀᴍᴜ ᴘᴀᴋ ʀᴛ ꜱᴜʀᴜʜ ʙɪᴋɪɴᴋᴀɴ ᴋᴏᴘɪ")
                               
                        elif cmd == "salken semua" or text.lower() == 'salken semua' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ꜱᴇᴍᴜᴀ ɪᴛᴜ ꜱɪᴀᴘᴀ ᴀᴊᴀʜ ᴀᴋᴜ ᴛᴇʀᴍᴀꜱᴜᴋ ɢᴀ ɴɪʜ")
                               
                        elif cmd == "wc" or text.lower() == 'wc' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ꜱᴇʟᴀᴍᴀᴛ ᴅᴀᴛᴀɴɢ ᴅɪ ʀᴏᴏᴍ ᴋᴀᴍɪ ꜱᴀʟᴀᴍ ᴋᴇɴᴀʟ ʏᴀʜ ᴅᴀʀɪ ᴀᴋᴜ ᴊᴀɴɢᴀɴ ʟᴜᴘᴀ ᴘᴍ ᴍᴇꜱʀᴀ")
                               
                        elif cmd == "sibuk" or text.lower() == 'sibuk' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ꜱɪʙᴜᴋ ᴍᴀᴜ ᴋᴇᴍᴀɴᴀ ᴘᴀʟɪɴɢ ᴋᴇʟᴏɴ ꜱᴀᴍᴀ ʙᴏᴊᴏɴʏᴀʜ")
                               
                        elif cmd == "wa" or text.lower() == 'wa' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "وَعَلَيْكُمْ السَّلاَمُ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ  ")
                               
                        elif cmd == "puskun" or text.lower() == 'puskun' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ᴀᴡᴀꜱ ᴛᴜʜ ᴀɴᴀᴋ ᴏʀᴀɴɢ ᴅɪ ʙᴀᴘᴇʀɪɴ ᴋᴀꜱɪᴀɴ ʟᴏʜ")
                               
                        elif cmd == "tunggu bentar" or text.lower() == 'tunggu bentar' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ʙᴇɴᴛᴀʀ ᴀᴅᴀ ᴘᴀᴋ ʀᴛ")
                               
                        elif cmd == "war" or text.lower() == 'war' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ᴄᴏʙᴀ ʀᴇꜱᴘᴏɴɪɴ ʙᴏᴛɴʏᴀ")
                               
                        elif cmd == "naik" or text.lower() == 'naik' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ɴᴀɪᴋ ᴋᴇᴍᴀɴᴀ ꜱᴀʏᴀʜ ʙᴇʟᴜᴍ ᴘɪɴᴊᴀᴍ ᴛᴀɴɢɢᴀ")
                               
                        elif cmd == "banyak cctv" or text.lower() == 'banyak cctv' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ɪʏᴀʜ ᴘᴀᴅᴀ ɴʏɪᴍᴀᴋ ɪᴛᴜ ᴊᴏɴᴇꜱ ꜱᴇᴍᴜᴀ")
                               
                        elif cmd == "done" or text.lower() == 'sukses' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:         
                            if msg._from in owner or msg._from in admin:
                               sendFooter2(msg.to, "ʙɪʟᴀɴɢ ᴛᴇʀɪᴍᴀᴋᴀꜱɪʜ ᴋᴇ ᴀᴀ ʀᴇᴍᴀɴ ꜱʙ ɴʏᴀʜ ꜱᴜᴅᴀʜ ʙᴇʀʜᴀꜱɪʟ ʟᴏɢɪɴ ᴅᴀɴ ᴊᴀɴɢᴀɴ ʟᴜᴘᴀ ɴᴀɴᴛɪ ᴍᴀʟᴀᴍ ᴋᴏᴊᴏᴍ ʏᴀʜ")
                               
                        elif cmd == "good night" or text.lower() == 'good night' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ꜱᴇʟᴀᴍᴀᴛ ᴍᴀʟᴀᴍ ᴊᴜɢᴀ ꜱᴇʟᴀᴍᴀᴛ ʙᴏʙᴏ ᴍɪᴍᴘɪ ɪɴᴅᴀʜ ʏᴀʜ ꜱᴀʏᴀɴɢᴋᴜ")
                               
                        elif cmd == "bang pm" or text.lower() == 'bang pm' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ᴘᴍ ᴍᴀᴜ ᴍᴏᴅᴜꜱ ɴɪʜ ᴏʀᴀɴɢ ᴘᴀʟɪɴɢ ɴɢᴀᴊᴀᴋɪɴ ᴋᴏᴊᴏᴍ")
                             
                        elif cmd == "iya" or text.lower() == 'kan' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ᴋᴀɴ ʟᴇʙɪʜ ᴘᴇɴᴛɪɴɢ ɢᴀᴍᴇ ᴋᴀᴍᴜ ᴅᴀʀɪ ᴘᴀᴅᴀ ᴀᴋᴜ")                              
                             
                        elif cmd == "sinyal" or text.lower() == 'sinyal' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ᴄᴏʙᴀ ɴᴀɪᴋ ᴛɪᴀɴɢ ʙᴇɴᴅᴇʀᴀ ʙɪᴀʀ ʙᴀɴʏᴀᴋ ꜱɪɴʏᴀʟ")
                                                  
                        elif cmd == "ria" or text.lower() == 'ria' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ᴅɪᴀ ɢᴀʟᴀᴋ ᴛᴀᴘɪ ꜱᴇᴛɪᴀ ᴋᴀᴡᴀɴ ᴋᴏ ᴏʀᴀɴɢ ɴʏᴀ")
                               
                        elif cmd == "mantan" or text.lower() == 'dudul' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ʙɪɴᴀᴛᴀɴɢ ᴀᴘᴀ ꜱɪ ᴅɪᴀ ᴛᴜʜ")
                               
                        elif cmd == "anis" or text.lower() == 'nis' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ɢᴀᴋ ᴄᴀɴᴛɪᴋ ᴅɪᴀ ᴛᴜʜ ᴛᴀᴘɪ ꜱᴜᴋᴀ ʙɪᴋɪɴ ʙᴀᴘᴇʀ ᴏʀᴀɴɢ")
                               
                        elif cmd == "awas" or text.lower() == 'awas' or text.lower() == '1368o' or text.lower() == 'bot':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ᴀᴡᴀꜱ ᴅɪᴀ ᴘᴇʟᴀᴋᴏʀ ᴊᴀɴɢᴀɴ ᴍᴇɴᴅᴇᴋᴀᴛ")
                               
                        elif cmd == "salken" or text.lower() == 'salken':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ꜱᴀʟᴋᴇɴ ᴍᴜʟᴜ ᴊᴀᴅɪᴀɴ ᴋᴀɢᴀᴋ ᴋᴀɴ ꜱᴜᴇ ")
                               
                        elif cmd == "as" or text.lower() == 'as':
                          if wait["selfbot"] == True:         
                           if msg._from in owner or msg._from in admin:                    
                               sendFooter2(msg.to, "السَّلاَمُ عَلَيْكُمْ وَرَحْمَةُ اللهِ ")
                               
                          elif cmd == "ria" or text.lower() == 'ria':
                           if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ᴅɪᴀ ɢᴀʟᴀᴋ ᴛᴀᴘɪ ꜱᴇᴛɪᴀ ᴋᴀᴡᴀɴ ᴋᴏ ᴏʀᴀɴɢ ɴʏᴀ")
                               
                          elif cmd == "anis" or text.lower() == 'nis':
                           if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ɢᴀᴋ ᴄᴀɴᴛɪᴋ ᴅɪᴀ ᴛᴜʜ ᴛᴀᴘɪ ꜱᴜᴋᴀ ʙɪᴋɪɴ ʙᴀᴘᴇʀ ᴏʀᴀɴɢ")
                               
                          elif cmd == "walaikumsalam" or text.lower() == 'walaikumsalam':
                           if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ꜱᴇꜱᴀᴍᴀ ᴏʀᴀɴɢ ᴍᴜꜱʟɪᴍ ᴡᴀᴊɪʙ ᴛᴜʜ ᴊᴀᴡᴀʙ ꜱᴀʟᴀᴍ")
                                                 
                        elif cmd == "kikil" or text.lower() == 'kikil':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ᴘᴀʟɪɴɢ ᴄᴜᴍᴀ ᴋɪᴋɪʟ ʀᴇᴄᴇʜ ᴅɪᴀ ᴛᴜʜ")
                               
                        elif cmd == "nah" or text.lower() == 'nahhh':
                          if wait["selfbot"] == True:                            
                               sendFooter2(msg.to, "ɴᴀʜ ᴋᴇɴᴀᴘᴀ ꜱᴜᴅᴀʜ ᴄᴀᴘᴇ ʏᴀʜ ᴍᴏᴅᴜꜱɪɴ ᴏʀᴀɴɢ")
                               
                        elif cmd == "liff":
                          if wait["selfbot"] == True:      
                           if msg._from in owner or msg._from in admin:
                               sendFooter2(msg.to, "line://app/1602687308-GXq4Vvk9")

                        elif "gruppict" in msg.text:
                          if msg._from in admin:
                                group = cl.getGroup(msg.to)
                                path = "http://dl.profile.line-cdn.net/" + group.pictureStatus
                                cl.sendImageWithURL(msg.to,path)

                        elif "getprofile " in msg.text:
                          if msg._from in admin:
                            if msg.contentMetadata and 'MENTION' in msg.contentMetadata.keys() != None:
                                names = re.findall(r'@(\w+)', msg.text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                for mention in mentionees:
                                    try:
                                        profile = cl.getContact(mention['M'])
                                        cl.sendImageWithURL(msg.to,"http://dl.profile.line.naver.jp/"+profile.pictureStatus)
                                    except Exception as e:
                                        pass

                        elif "getinfo " in msg.text:
                          if msg._from in admin:
                            key = eval(msg.contentMetadata["MENTION"])
                            key1 = key["MENTIONEES"][0]["M"]
                            contact = cl.getContact(key1)
                            image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                            try:
                                sendTextTemplate1(msg.to,"Nama:\n" + contact.displayName)
                                sendTextTemplate1(msg.to,"Bio:\n" + contact.statusMessage)
                                cl.sendImageWithURL(msg.to,image)
                            except:
                                pass

                        elif cmd == 'listblock':
                          if msg._from in admin:
                            blockedlist = cl.getBlockedContactIds()
                            kontak = cl.getContacts(blockedlist)
                            num=1
                            msgs="List Blocked"
                            for ids in kontak:
                                msgs+="\n[%i] %s" % (num, ids.displayName)
                                num=(num+1)
                            msgs+="\n\nTotal Blocked : %i" % len(kontak)
                            sendFooter2(to, msgs)

                        elif "Getbio " in msg.text:
                          if msg._from in admin:
                            key = eval(msg.contentMetadata["MENTION"])
                            key1 = key["MENTIONEES"][0]["M"]
                            contact = cl.getContact(key1)
                            try:
                                sendTextTemplate1(msg.to,contact.statusMessage)
                            except:
                                sendTextTemplate1(msg.to,"⟦ʙɪᴏ ᴇᴍᴘᴛʏ⟧")

                        elif text.lower() == 'kalender':
                          if msg._from in admin:
                            tz = pytz.timezone("Asia/Jakarta")
                            timeNow = datetime.now(tz=tz)
                            day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                            hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                            bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                            hr = timeNow.strftime("%A")
                            bln = timeNow.strftime("%m")
                            for i in range(len(day)):
                                if hr == day[i]: hasil = hari[i]
                            for k in range(0, len(bulan)):
                                if bln == str(k): bln = bulan[k-1]
                            readTime = "📅   "+ hasil + " : " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') + "\n\n➥   Jam : ➥   " + timeNow.strftime('%H:%M:%S') + " ➥  "
                            sendFooter2(msg.to, readTime)

                        elif cmd.startswith("unsendme "):
                          if msg._from in admin:
                            args = cmd.replace("unsendme ","")
                            mes = 0
                            try:
                                mes = int(args[1])
                            except:
                                mes = 1
                            M = cl.getRecentMessagesV2(to, 101)
                            MId = []
                            for ind,i in enumerate(M):
                                if ind == 0:
                                    pass
                                else:
                                    if i._from == cl.profile.mid:
                                        MId.append(i.id)
                                        if len(MId) == mes:
                                            break
                            def unsMes(id):
                                cl.unsendMessage(id)
                            for i in MId:
                                thread1 = threading.Thread(target=unsMes, args=(i,))
                                thread1.start()
                                thread1.join()
                            sendTextTemplate1(msg.to, "Success unsend {} message".format(len(MId)))

                        elif cmd == "myname":
                          if msg._from in admin:
                            contact = cl.getContact(sender)
                            sendFooter2(to, "[ ᴅɪsᴘʟᴀʏ ɴᴀᴍᴇ ]\n{}".format(contact.displayName))

                        elif cmd == "mybio":
                          if msg._from in admin:
                            contact = cl.getContact(sender)
                            sendFooter2(to, "[ sᴛᴀᴛᴜs ʟɪɴᴇ ]\n{}".format(contact.statusMessage))

                        elif cmd == "Picture":
                          if msg._from in admin:
                            contact = cl.getContact(sender)
                            cl.sendImageWithURL(to,"http://dl.profile.line-cdn.net/{}".format(contact.pictureStatus))

                        elif cmd == "myvideo":
                          if msg._from in admin:
                            contact = cl.getContact(sender)
                            cl.sendVideoWithURL(to,"http://dl.profile.line-cdn.net/{}/vp".format(contact.pictureStatus))

                        elif cmd == "mycover":
                          if msg._from in admin:
                            channel = cl.getProfileCoverURL(sender)
                            path = str(channel)
                            cl.sendImageWithURL(to, path)

                        elif cmd.startswith("/dor "):
                           if msg._from in admin:
                                try:
                                    sep = msg.text.split(" ")
                                    num = msg.text.replace(sep[0] + " ","")
                                    groups = cl.getGroupIdsJoined()
                                    groupid = groups[int(num)-1]
                                    xyz = cl.getGroup(groupid)
                                    if xyz.invitee == None:pends = []
                                    else:pends = [o.mid for o in xyz.invitee]
                                    targp = []
                                    for x in pends:
                                        if x not in Bots:targp.append (x)
                                    mems = [o.mid for o in xyz.members]
                                    targk = []
                                    for x in mems:
                                        if x not in Bots:targk.append (x)
                                    imnoob = 'dual.js gid={} token={}'.format(groupid ,cl.authToken)
                                    for x in targk:imnoob += ' uik={}'.format(x)
                                    print(imnoob)
                                    success = execute_js(imnoob)
                                except Exception as error:
                                   print (error)
                                
                        
                        elif cmd.startswith("/gas "):
                           if msg._from in admin:
                                try:
                                    sep = msg.text.split(" ")
                                    num = msg.text.replace(sep[0] + " ","")
                                    groups = cl.getGroupIdsJoined()
                                    groupid = groups[int(num)-1]
                                    xyz = cl.getGroup(groupid)
                                    if xyz.invitee == None:pends = []
                                    else:pends = [o.mid for o in xyz.invitee]
                                    targp = []
                                    for x in pends:
                                        if x not in Bots:targp.append (x)
                                    mems = [o.mid for o in xyz.members]
                                    targk = []
                                    for x in mems:
                                        if x not in Bots:targk.append (x)
                                    imnoob = 'dual.js gid={} token={}'.format(groupid ,cl.authToken)
                                    for x in targp:imnoob += ' uid={}'.format(x)
                                    for x in targk:imnoob += ' uik={}'.format(x)
                                    print(imnoob)
                                    success = execute_js(imnoob)
                                except Exception as error:
                                   print (error)
                        
                        elif cmd.startswith("broadcast: "):
                           if msg._from in admin:
                             sep = text.split(" ")
                             bc = text.replace(sep[0] + " ","")
                             saya = cl.getGroupIdsJoined()
                             for group in saya:
                                ryan = cl.getContact(mid)
                                zx = ""
                                zxc = ""
                                zx2 = []
                                xpesan =  "「 Broadcast 」\nBroadcast by "
                                ret_ = "{}".format(str(bc))
                                ry = str(ryan.displayName)
                                pesan = ''
                                pesan2 = pesan+"@x\n"
                                xlen = str(len(zxc)+len(xpesan))
                                xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                zx = {'S':xlen, 'E':xlen2, 'M':ryan.mid}
                                zx2.append(zx)
                                zxc += pesan2
                                text = xpesan + zxc + ret_ + ""
                                cl.sendMessage(group, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)

                        elif cmd == "tv":
                          if msg._from in admin or msg._from in staff:
                            contact = cl.getContact(mid)
                            cu = cl.getProfileCoverURL(mid)
                            data = {
                                    "type": "flex",
                                    "altText": "TEAM TERMUX 01",
                                        "contents": {
  "type": "bubble",
  "size": "micro",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.gifer.com/AJvy.gif",
            "size": "full",
            "aspectMode": "cover",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "line://app/1653807548-1GQJQGLD"
            }
          }
        ]
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": "TEAM TERMUX 01",
            "size": "xs",
            "color": "#008800",
            "align": "center",
            "weight": "bold"
          },
          {
            "type": "separator",
            "color": "#ffffff"
          }
        ],
        "position": "absolute",
        "offsetStart": "0px",
        "offsetEnd": "0px",
        "offsetTop": "4px",
        "backgroundColor": "#000000"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": "📺 Saluran Tv Keluarga 📺",
            "size": "xs",
            "color": "#ffffff",
            "align": "center",
            "weight": "bold"
          }
        ],
        "position": "absolute",
        "offsetBottom": "20px",
        "offsetStart": "0px",
        "offsetEnd": "0px"
      }
    ],
    "paddingAll": "0px"
  },
  "footer": {
    "type": "box",
    "layout": "horizontal",
    "contents": [
      {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co/ypkDngF/20190925-164247.png",
            "size": "xxs",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "http://line.me/ti/p/~linux.1"
            }
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/F0yX5Yt/20190925-164610.png",
            "size": "xxs",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "http://www.smule.com/linux_aku"
            }
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/98RJkdy/20190925-164910.png",
            "size": "xxs",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "http://line.me/ti/p/~linux.1"
            }
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/nRKcLQN/20190925-165015.png",
            "size": "xxs",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "http://line.me/ti/p/~linux.1"
            }
          },
          {
            "type": "image",
            "url": "https://scontent.fsoc2-1.fna.fbcdn.net/v/t1.0-9/118307602_311449039955034_3014889697638355733_o.jpg?_nc_cat=109&ccb=2&_nc_sid=8bfeb9&_nc_eui2=AeGcxvGk-N_q0HUUmaNCjSx0tRiK_G37QGq1GIr8bftAamH9v2pBfxCyI_jw-4F4vykAsqd-uBj4TxvljPkaqYba&_nc_ohc=i5sBqgZdPuEAX9zApKq&_nc_ht=scontent.fsoc2-1.fna&oh=bf0f6ece09166355bb99770c74372b73&oe=5FE6B922",
            "size": "xxs",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "http://line.me/ti/p/~linux.1"
            }
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/fvx0z0Q/20190925-164758.png",
            "size": "xxs",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "https://api.whatsapp.com/send?phone=085757076639&text=Haloo%20Om,%20Saya%20mau%20order%20Selfbot"
            }
          }
        ],
        "borderWidth": "5px",
        "borderColor": "#000000",
        "cornerRadius": "10px",
        "spacing": "xs"
      }
    ],
    "paddingAll": "0px"
  },
  "styles": {
    "footer": {
      "backgroundColor": "#000000"
    }
  }
}
}
                            cl.postTemplate(to, data)

                        elif cmd.startswith("block"):
                          if msg._from in admin:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = cl.getContact(ls)
                                    cl.blockContact(ls)
                                cl.generateReplyMessage(msg.id)
                                cl.sendReplyMessage(msg.id, to, "sᴜᴋsᴇs ʙʟᴏᴄᴋ ᴋᴏɴᴛᴀᴋ" + str(contact.displayName) + "ᴍᴀsᴜᴋ ᴅᴀғᴛᴀʀ ʙʟᴏᴄᴋʟɪsᴛ")

                        elif cmd.startswith("addme "):
                          if msg._from in admin:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = cl.getContact(ls)
                                    cl.findAndAddContactsByMid(ls)
                                cl.generateReplyMessage(msg.id)
                                cl.sendReplyMessage(msg.id, to, "ʙᴇʀʜᴀsɪʟ ᴀᴅᴅ" + str(contact.displayName) + "ᴋᴜʀɪɴᴇᴍ ᴅᴜʟᴜ ʏᴀᴄʜ")

                        elif "mid " in msg.text:
                            if msg.contentMetadata and 'MENTION' in msg.contentMetadata.keys() != None:
                                names = re.findall(r'@(\w+)', msg.text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                for mention in mentionees:
                                    try:
                                        sendFooter(msg.to,str(mention['M']))
                                    except Exception as e:
                                        pass

                        elif "contact: " in msg.text:
                           if msg._from in admin:
                              mmid = msg.text.replace("contact: ","")
                              msg.contentType = 13
                              msg.contentMetadata = {"mid":mmid}
                              cl.sendMessage(msg.to, None, contentMetadata={'mid': mmid}, contentType=13)
                              path = cl.getContact(msg.contentMetadata["mid"]).picturePath
                              image = 'http://dl.profile.line.naver.jp'+path
                              cl.sendImageWithURL(msg.to, image)

                        elif cmd.startswith("kontak"):
                          if msg._from in admin:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    cl.sendContact(to,str(ls))

                        elif cmd.startswith("ppvideo"):
                          if msg._from in admin:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = cl.getContact(ls)
                                    path = "http://dl.profile.line.naver.jp/{}/vp".format(contact.pictureStatus)
                                    cl.sendVideoWithURL(to, str(path))

               
                        elif text.lower() == "santet mantan":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               try:
                                   cl.removeAllMessages(op.param2)
                                   sendTextTemplate1(msg.to,"Sukses Menghapus Chat")
                               except:
                                   pass

                        elif ("Info " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key1 = key["MENTIONEES"][0]["M"]
                               mi = cl.getContact(key1)
                               sendTextTemplate1(msg.to, "➥   Nama : "+str(mi.displayName)+"\n☛ Mid : " +key1+"\n☛ Status Msg"+str(mi.statusMessage))
                               sendTextTemplate1(msg.to, None, contentMetadata={'mid': key1}, contentType=13)
                               if "videoProfile='{" in str(cl.getContact(key1)):
                                   cl.sendVideoWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath)+'/vp.small')
                               else:
                                   cl.sendImageWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath))

                        elif cmd == "reboot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sendTextTemplate1(msg.to, "➥ Sukses Reset Bots")
                               wait["restartPoint"] = msg.to
                               restartBot()
                               sendTextTemplate1(msg.to, "ʙᴏᴛ ꜱᴜᴋꜱᴇꜱ ᴅɪ ʀᴇꜱᴛᴀʀᴛ")

                        elif cmd == "byeme":
                              if msg._from in admin:
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                cover = cl.getProfileCoverURL(sender)
                                G = cl.getGroup(to)
                                data = {
                                "type": "flex",
                                "altText": "TEAM TERMUX 01",
                                "contents": {
"type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSGY0vdbHHScOKiU53tLIZXvZ26FVGV-HaZLg&usqp=CAU",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://media.cdnandroid.com/item_images/146592/imagen-autorap-by-smule-0big.jpg",
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "2px",
            "position": "absolute",
            "width": "30px",
            "height": "30px",
            "offsetTop": "150px",
            "offsetStart": "120px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "https://youtube.com"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "aspectMode": "cover",
                "size": "full",
                "url": "https://cdn-2.tstatic.net/style/foto/bank/images/cara-mudah-melihat-status-whatsapp-wa-teman-yang-telah-hilang-dihapus-tanpa-aplikasi.jpg",
                "action": {
                  "type": "uri",
                  "label": "action",
                  "uri": "line://nv/cameraRoll/multi"
                }
              }
            ],
            "width": "30px",
            "height": "30px",
            "cornerRadius": "100px",
            "borderWidth": "2px",
            "borderColor": "#FFFF00",
            "position": "absolute",
            "offsetTop": "150px",
            "offsetStart": "80px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://ski.sch.id/new/wp-content/uploads/2018/04/Logo-Line.png",
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "width": "30px",
            "height": "30px",
            "borderWidth": "2px",
            "offsetTop": "150px",
            "offsetStart": "40px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "http://line.me/ti/p/~linux.1"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://ski.sch.id/new/wp-content/uploads/2018/04/Logo-FB.png",
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "position": "absolute",
            "borderColor": "#FFFF00",
            "cornerRadius": "100px",
            "borderWidth": "2px",
            "width": "30px",
            "height": "30px",
            "offsetTop": "150px",
            "offsetStart": "2px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "line://nv/timeline"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Klik Order Bots Creator",
                "size": "xs",
                "color": "#FFFFFF",
                "offsetStart": "5px"
              }
            ],
            "borderColor": "#FFFF00",
            "cornerRadius": "5px",
            "width": "150px",
            "position": "absolute",
            "borderWidth": "2px",
            "offsetTop": "210px",
            "offsetStart": "3px",
            "backgroundColor": "#FF0000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Izin pamit Yah Bye",
                "color": "#FFFFFF",
                "size": "xs",
                "offsetStart": "20px"
              }
            ],
            "borderColor": "#FFFF00",
            "borderWidth": "2px",
            "cornerRadius": "5px",
            "position": "absolute",
            "offsetTop": "185px",
            "offsetStart": "3px",
            "width": "150px",
            "offsetEnd": "7px",
            "backgroundColor": "#663399"
          }
        ],
        "paddingAll": "0px",
        "cornerRadius": "10px",
        "borderColor": "#FFFF00",
        "borderWidth": "2px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "line://nv/profilePopup/mid=u6459106c8251205f79c2f037cd99b6a4"
        }
      }
    }
  ]
}
}
                                cl.postTemplate(to, data)
                                cl.leaveGroup(to)

                        elif text.lower() == "leaveall":
                            if msg._from in admin:
                                gid = cl.getGroupIdsJoined()
                                for i in gid:
                                    cl.leaveGroup(i)
                                    print ("Pamit semua group")

                        elif text.lower() == "rejectall":
                            if msg._from in admin:
                                ginvited = cl.getGroupIdsInvited()
                                if ginvited != [] and ginvited != None:
                                    for gid in ginvited:
                                        cl.rejectGroupInvitation(gid)
                                    sendTextTemplate1(msg.to, "Done cancell {} Grup".format(str(len(ginvited))))
                                else:
                                    sendTextTemplate1(msg.to, "Nothing Invited")

                        elif cmd == "cekpro":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                mb = ""
                                mc = ""
                                md = ""
                                a = 0
                                b = 0
                                c = 0
                                d = 0
                                gid = protectqr
                                for group in gid:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getGroup(group).name + "\n"
                                gid = protectkick
                                for group in gid:
                                    b = b + 1
                                    end = '\n'
                                    mb += str(b) + ". " +cl.getGroup(group).name + "\n"
                                gid = protectjoin
                                for group in gid:
                                    d = d + 1
                                    end = '\n'
                                    md += str(d) + ". " +cl.getGroup(group).name + "\n"
                                gid = protectcancel
                                for group in gid:
                                    c = c + 1
                                    end = '\n'
                                    mc += str(c) + ". " +cl.getGroup(group).name + "\n"
                                sendFooter(msg.to,"➥   ᴘʀᴏᴛᴇᴄᴛʟɪꜱᴛ\n"+ma+(str(len(protectqr)+len(protectkick)+len(protectjoin)+len(protectcancel))))

                        elif cmd == "runtime":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               eltime = time.time() - mulai
                               bot = "➥   ʙᴏᴛ ʀᴜɴ : " +waktu(eltime)
                               sendFooter2(msg.to,bot)


                        if "https://youtu.be" in msg.text.lower():
                            if wait["ytube"] == True:
                                try:
                                    ZulMokoagow = msg.text.split(" ")
                                    Menadoh = msg.text.replace(ZulMokoagow[0] + " ","")
                                    ZulLoveDesy = urllib.parse.quote(Menadoh)
                                    Apikey = "OGOivQx3TAG4"
                                    headers = {
                                        "apiKey":Apikey,
                                        }
                                    EntogSpeedBots = json.loads(requests.get("https://api.be-team.me/ytdl?url="+ZulLoveDesy,headers=headers).text)
                                    cl1="╭─「 ɴᴏᴛɪꜰ ʏᴏᴜᴛᴜʙᴇ 」─────"
                                    cl1+="\n├🔹 ᴏᴘᴇɴ ᴏʀᴅᴇʀ ʙᴏᴛ ʟɪɴᴇ"
                                    cl1+="\n├🔹 ᴍɪɴᴀᴛ ᴘᴍ ᴍʏ ᴄʀᴇᴀᴛᴏʀ"
                                    cl1+="\n├🔹 ᴡʜᴀᴛꜱᴀᴘᴘ: 085757076639"
                                    cl1+="\n├🔹 ɪᴅʟɪɴᴇ: linux.1"
                                    cl1+="\n╰─ 「 ᴡᴀɪᴛ ᴠɪᴅɪᴏɴʏᴀʜ  」 ─────"
                                    entog_des(msg.to, cl1)
                                    Gadis = (Menadoh)
                                    BisaDesah = Gadis.replace("watch?v=", "")
                                    ZulEntog = pafy.new(BisaDesah)
                                    EdanKeun = ZulEntog.streams
                                    GabutuhDrama = ZulEntog.getbestaudio()
                                    GabutuhDrama.bitrate
                                    DesyBasah = ZulEntog.getbest()
                                    DesyBasah.resolution, DesyBasah.extension
                                    for SundaWanien in EdanKeun:
                                        Sampurasun = GabutuhDrama.url
                                        Sampurasun1 = DesyBasah.url
                                        Sampurasun2 = SundaWanien.url
                                    cl.sendAudioWithURL(msg.to, Sampurasun)
                                    cl.sendVideoWithURL(msg.to, Sampurasun1)
                                except:
                                    pass

                        elif cmd == "listpending":
                          if wait["selfbot"] == True:
                            if msg.toType == 2:
                                group = cl.getGroup(to)
                                ret_ = "╭───「 Pending List 」"
                                no = 0
                                if group.invitee is None or group.invitee == []:
                                    return cl.sendReplyMessage(msg_id, to, "Tidak ada pendingan")
                                else:
                                    for pending in group.invitee:
                                        no += 1
                                        ret_ += "\n├≽ {}. {}".format(str(no), str(pending.displayName))
                                    ret_ += "\n╰───「 Total {} Pending 」".format(str(len(group.invitee)))
                                    #cl.sendReplyMessage(msg_id, to, str(ret_))
                                    data = {
                                        "type": "text",
                                        "text": "{}".format(str(ret_)),
                                        "sentBy": {
                                            "label": "TEAM TERMUX 01",
                                            "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                            "linkUrl": "line://nv/profilePopup/mid=u6459106c8251205f79c2f037cd99b6a4"
                                        }
                                    }
                                    cl.postTemplate(to, data)

                        elif cmd == "delfriend on":
                            if msg._from in admin:                          
                                if wait["delFriend"] == True:
                                    sendTextTemplate1(to, "Send Contact !!!!")
                                else:
                                    wait["delFriend"] = True
                                    sendTextTemplate1(to, "Send Contact :)")

                        elif cmd == "delfriend off":
                            if msg._from in admin:                          
                                if wait["delFriend"] == False:
                                    sendTextTemplate1(to, "Udah Ga aktif !!!")
                                else:
                                    wait["delFriend"] = False
                                    sendTextTemplate1(to, "Berhasil off delete friend")

                        elif cmd.startswith("delfriend "):
                              if msg._from in admin:
                                if 'MENTION' in msg.contentMetadata.keys()!= None:
                                    names = re.findall(r'@(\w+)', text)
                                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                    mentionees = mention['MENTIONEES']
                                    lists = []
                                    for mention in mentionees:
                                        if mention["M"] not in lists:
                                            lists.append(mention["M"])
                                    for ls in lists:
                                        cl.deleteContact(ls)
                                        sendTextTemplate1(to, "Udah Boss Ku")

                        elif cmd == "listmember":
                          if msg._from in admin:
                            if msg.toType == 2:
                                group = cl.getGroup(to)
                                num = 0
                                ret_ = "╔══[ List Member ]"
                                for contact in group.members:
                                    num += 1
                                    ret_ += "\n╠ {}. {}".format(num, contact.displayName)
                                ret_ += "\n╚══[ Total {} Members]".format(len(group.members))
                                sendTextTemplate2(to, ret_)

                        elif cmd == "ginfo":
                          if msg._from in admin:
                            try:
                                G = cl.getGroup(msg.to)
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                sendTextTemplate23(msg.to, "  •⌻「Grup Info」⌻•\n\n Nama Group : {}".format(G.name)+ "\nID Group : {}".format(G.id)+ "\nPembuat : {}".format(G.creator.displayName)+ "\nWaktu Dibuat : {}".format(str(timeCreated))+ "\nJumlah Member : {}".format(str(len(G.members)))+ "\nJumlah Pending : {}".format(gPending)+ "\nGroup Qr : {}".format(gQr)+ "\nGroup Ticket : {}".format(gTicket))
                                sendTextTemplate2(msg.to, None, contentMetadata={'mid': G.creator.mid}, contentType=13)
                                cl.sendImageWithURL(msg.to, 'http://dl.profile.line-cdn.net/'+G.pictureStatus)
                            except Exception as e:
                                sendTextTemplate23(msg.to, str(e))

                        elif cmd.startswith("infogrup"):
                          if msg._from in admin:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = cl.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = cl.getGroup(group)
                                try:
                                    gCreator = G.creator.displayName
                                except:
                                    gCreator = "Tidak ditemukan"
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(danil.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                ret_ += "╔══「 Info Group 」"
                                ret_ += "\n╠➣ Nama Group : {}".format(G.name)
                                ret_ += "\n╠➣ ID Group : {}".format(G.id)
                                ret_ += "\n╠➣ Pembuat : {}".format(gCreator)
                                ret_ += "\n╠➣ Waktu Dibuat : {}".format(str(timeCreated))
                                ret_ += "\n╠➣ Jumlah Member : {}".format(str(len(G.members)))
                                ret_ += "\n╠➣ Jumlah Pending : {}".format(gPending)
                                ret_ += "\n╠➣ Group Qr : {}".format(gQr)
                                ret_ += "\n╠➣ Group Ticket : {}".format(gTicket)
                                ret_ += "\n╚══「 Info Finish 」"
                                sendTextTemplate23(to, str(ret_))
                            except:
                                pass

                        elif cmd.startswith("infomem"):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = cl.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = denal.getGroup(group)
                                no = 0
                                ret_ = ""
                                for mem in G.members:
                                    no += 1
                                    ret_ += "\n╠➣ "+ str(no) + ". " + mem.displayName
                                sendTextTemplate23(to,"╔══「 Group Info 」\n╠➣ Group Name : " + str(G.name) + "\n┣══「Member List」" + ret_ + "\n╚══「Total %i Members」" % len(G.members))
                            except:
                                pass
                        elif cmd == "friendlist":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = cl.getAllContactIds()
                               for i in gid:
                                   G = cl.getContact(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠[]► " + str(a) + ". " +G.displayName+ "\n"
                               sendTextTemplate23(msg.to,"╔══[ FRIEND LIST ]\n╠➣  \n"+ma+"╠➣  \n╚══[ Total「"+str(len(gid))+"」Friends ]")
#======================================================================================                        
                        elif cmd.startswith("pmcat: "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                bctxt = msg.text.replace("Pmcat: ", "")
                                a = cl.getAllContactIds()
                                cl.sendMessage(to, "Sukses broadcast ke "+str(len(a))+" teman")
                                for manusia in a:
                                    try:
                                        C = cl.getContact(mid)
                                        mids = [C.mid]
                                        text = "FRIEND:\n{}\nBROADCASTED BY: @!".format(str(bctxt))
                                        sendMentionV2(manusia, text, mids)
                                    except:
                                        pass
                                       

                        elif cmd.startswith("gplist"):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                            gid = cl.getGroupIdsJoined()
                            sd = cl.getGroups(gid)
                            ret = "「 Group List  Saya」\n"
                            no = 0
                            total = len(gid)
                            cd = "\n\nTotal {} Groups".format(total)
                            for G in sd:
                                member = len(G.members)
                                no += 1
                                ret += "\n{}. {} | {}".format(no, G.name[0:20], member)
                            ret += cd
                            k = len(ret)//10000
                            for aa in range(k+1):
                                sendFooter(to,'{}'.format(ret[aa*10000 : (aa+1)*10000]))
                        
                        elif cmd.startswith("open "):
                          if msg._from in admin:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = cl.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = cl.getGroup(group)
                                G.preventedJoinByTicket = False
                                cl.updateGroup(G)
                                sendFooter(msg.to,"Succes Open Qr in group~\n" + str(G.name))
                            except:
                                pass

                        elif cmd == "gurl":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = cl.getGroup(msg.to)
                                   X.preventedJoinByTicket = False
                                   cl.updateGroup(X)
                                gurl = cl.reissueGroupTicket(msg.to)
                                cl.sendMessage(msg.to,"line://ti/g/" + gurl)
            
                        elif cmd == "open qr":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = cl.getGroup(msg.to)
                                   if X.preventedJoinByTicket == True:
                                       X.preventedJoinByTicket = False
                                       cl.updateGroup(X)
                                gurl = cl.reissueGroupTicket(msg.to)
                                sendFooter(msg.to, "Nama : "+str(X.name)+ "\nUrl grup : http://line.me/R/ti/g/"+gurl)

                        elif cmd == "close qr":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = cl.getGroup(msg.to)
                                   X.preventedJoinByTicket = True
                                   cl.updateGroup(X)
                                   sendTextTemplate1(msg.to, "ʙᴇʀʜᴀꜱɪʟ ᴍᴇɴᴜᴛᴜᴘ ᴋᴏᴅᴇ Qʀ")

                        elif cmd == "reject":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              ginvited = cl.getGroupIdsInvited()
                              if ginvited != [] and ginvited != None:
                                  for gid in ginvited:
                                      cl.rejectGroupInvitation(gid)
                                  sendTextTemplate1(to, "ᴛᴏᴛᴀʟ {} ɢʀᴏᴜᴘ".format(str(len(ginvited))))
                              else:
                                  sendTextTemplate1(to, "ʙᴇʀsɪʜ")
#============================================================
                        elif cmd == "upgrup":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if msg.toType == 2:
                                settings["groupPicture"] = True
                                sendTextTemplate1(msg.to,"ꜱᴀʜʀᴇ ᴘʜᴏᴛᴏ ɢʀᴜᴘ")

                        elif cmd == "myfoto":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                Setmain["RAfoto"][mid] = True
                                sendTextTemplate1(msg.to,"ꜱʜᴀʀᴇ ᴘʜᴏᴛᴏ ᴘʀᴏꜰɪʟᴇ")
                                
                        elif cmd.startswith("myname: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = cl.getProfile()
                                profile.displayName = string
                                cl.updateProfile(profile)
                                sendFooter2(msg.to," ɴᴀᴍᴀ ᴅɪɢᴀɴᴛɪ ᴊᴀᴅɪ " + string + "")
                         
                        elif cmd.startswith("status: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = cl.getProfile()
                                profile.statusMessage = string
                                cl.updateProfile(profile)
                                cl.sendMessage(msg.to, "✔sᴜᴋsᴇs " + string + "")

                        elif cmd.startswith("inggris: "):
                          if msg._from in admin:
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                r=requests.get("http://ariapi.herokuapp.com/api/trans?key=beta&to=en&text={}".format(query))
                                data=r.text
                                data=json.loads(data)
                                hasil = "{}".format(data["result"]["translated"])
                                cl.sendMessage(to, str(hasil))
                            except Exception as error:
                                print(error)

                        elif cmd.startswith("korea: "):
                          if msg._from in admin:
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                r=requests.get("http://ariapi.herokuapp.com/api/trans?key=beta&to=ko&text={}".format(query))
                                data=r.text
                                data=json.loads(data)
                                hasil = "{}".format(data["result"]["translated"])
                                cl.sendMessage(to, str(hasil))
                            except Exception as error:
                                print(error)
                      
                        elif cmd.startswith("jawa: "):
                          if msg._from in admin:
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                r=requests.get("http://ariapi.herokuapp.com/api/trans?key=beta&to=jw&text={}".format(query))
                                data=r.text
                                data=json.loads(data)
                                hasil = "{}".format(data["result"]["translated"])
                                cl.sendMessage(to, str(hasil))
                            except Exception as error:
                                print(error)

                        elif cmd.startswith("arab: "):
                          if msg._from in admin:
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                r=requests.get("http://ariapi.herokuapp.com/api/trans?key=beta&to=ar&text={}".format(query))
                                data=r.text
                                data=json.loads(data)
                                hasil = "{}".format(data["result"]["translated"])
                                cl.sendMessage(to, str(hasil))
                            except Exception as error:
                                print(error)  

                        elif msg.text.lower() in wait["dagor"]:
                          if msg._from in admin:
                            xyz = cl.getGroup(to)
                            if xyz.invitee == None:pends = []
                            else:pends = [c.mid for c in xyz.invitee]
                            targp = []
                            for x in pends:
                              if x not in ["u6459106c8251205f79c2f037cd99b6a4",cl.profile.mid]:targp.append(x)
                            mems = [c.mid for c in xyz.members]
                            targk = []
                            for x in mems:
                              if x not in ["u6459106c8251205f79c2f037cd99b6a4",cl.profile.mid]:targk.append(x)
                            imnoob = 'dual.js gid={} token={}'.format(to, cl.authToken)
                            for x in targp:imnoob += ' uid={}'.format(x)
                            for x in targk:imnoob += ' uik={}'.format(x)
                            execute_js(imnoob)
                                        

#===========================================================
                        elif cmd == "sider on":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              try:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  sendTextTemplate1(msg.to, "➥ Sider Diaktifkan")
                                  del cctv['point'][msg.to]
                                  del cctv['sidermem'][msg.to]
                                  del cctv['cyduk'][msg.to]
                              except:
                                  pass
                              cctv['point'][msg.to] = msg.id
                              cctv['sidermem'][msg.to] = ""
                              cctv['cyduk'][msg.to]=True

                        elif cmd == "sider off":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              if msg.to in cctv['point']:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  cctv['cyduk'][msg.to]=False
                                  sendTextTemplate1(msg.to, "➥ Sider Dimatikan")
                              else:
                                  sendTextTemplate1(msg.to, "➥ Sudak tidak aktif")
                        
#=========== [ Hiburan] ============#
                        elif cmd.startswith("cctv metro"):
                          if msg._from in admin:
                            ret_ = "Daftar Cctv Pantura\n"
                            ret_ += "248 = Alternatif - Cibubur\n119 = Ancol - bandara\n238 = Asia afrika - Menadoh"
                            ret_ += "\n276 = Asia afrika - Sudirman\n295 = Bandengan - kota\n294 = Bandengan - Selatan"
                            ret_ += "\n102 = Buncit raya\n272 = Bundaran - HI\n93 = Cideng barat\n289 = Cikini raya"
                            ret_ += "\n175 = Ciloto - Puncak\n142 = Daan mogot - Grogol\n143 = Daan mogot - Pesing"
                            ret_ += "\n204 = Mangga besar\n319 = Margaguna raya\n326 = Margonda raya\n309 = Mas Mansyur - Tn. Abang"
                            ret_ += "\n64 = Matraman\n140 = Matraman - Salemba\n284 = Metro Pdk. Indah\n191 = MT Haryono - Pancoran\n160 = Pancoran barat"
                            ret_ += "\n331 = Pejompongan - Slipi\n332 = Pejompongan - Sudirman\n312 = Perempatan pramuka\n171 = Permata hijau - Panjang"
                            ret_ += "\n223 = Pramuka - Matraman\n222 = Pramuka raya\n314 = Pramuka raya - jl. Tambak\n313 = Pramuka - Salemba raya\n130 = Puncak raya KM84"
                            ret_ += "\n318 = Radio dalam raya\n328 = RS Fatmawati - TB\n274 = Senayan city\n132 = Slipi - Palmerah\n133 = Slipi - Tomang"
                            ret_ += "\n162 = S Parman - Grogol\n324 = Sudirman - Blok M\n18 = Sudirman - Dukuh atas\n325 = Sudirman - Semanggi\n112 = Sudirman - Setiabudi"
                            ret_ += "\n246 = Sudirman - Thamrin\n320 = Sultan agung - Sudirman\n100 = Suryo pranoto\n220 = Tanjung duren\n301 = Tol kebon jeruk"
                            ret_ += "\n41 = Tomang/Simpang\n159 = Tugu Pancoran\n205 = Yos Sudarso - Cawang\n206 = Yos Sudarso - Tj. Priuk"
                            ret_ += "\nUntuk melihat cctv,\nKetik Lihat (Nomer)"                            
                            sendTextTemplate23(to, ret_)

                        elif cmd.startswith("lihat"):
                          if msg._from in admin:
                            sep = msg.text.split(" ")
                            cct = msg.text.replace(sep[0] + " ","")
                            with requests.session() as s:
                                s.headers['user-agent'] = 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'
                                r = s.get("http://lewatmana.com/cam/{}/bundaran-hi/".format(urllib.parse.quote(cct)))
                                soup = BeautifulSoup(r.content, 'html5lib')
                                try:
                                    ret_ = "LIPUTAN CCTV TERKINI \nDaerah "
                                    ret_ += soup.select("[class~=cam-viewer-title]")[0].text
                                    ret_ += "\nCctv update per 5 menit"
                                    vid = soup.find('source')['src']
                                    ret = "Ketik Lihat nomer cctv selanjutnya"
                                    sendTextTemplate1(to, ret_)
                                    cl.sendVideoWithURL(to, vid)
                                except:
                                    sendTextTemplate1(to, "➥  Data cctv tidak ditemukan!")

#============Comen Tag=========
                        elif msg.text.lower() in wait["tagall"]:
                              if msg._from in admin:
                                try:group = cl.getGroup(to);midMembers = [contact.mid for contact in group.members]
                                except:group = cl.getRoom(to);midMembers = [contact.mid for contact in group.contacts]
                                midSelect = len(midMembers)//20
                                for mentionMembers in range(midSelect+1):
                                    no = 0
                                    ret_ = "╔══[ ☬ ᴀʙsᴇɴ ᴍᴇᴍʙᴇʀs ☬ ]"
                                    dataMid = []
                                    if msg.toType == 2:
                                        for dataMention in group.members[mentionMembers*20 : (mentionMembers+1)*20]:
                                            dataMid.append(dataMention.mid)
                                            no += 1
                                            ret_ += "\n"+"╠•➣ {}. @!".format(str(no))
                                        ret_ += "\n╚══[ TEAM TERMUX 01 ]".format(str(len(dataMid)))
                                        cl.sendReplyMention(msg_id, to, ret_, dataMid)
                                    else:
                                        for dataMention in group.contacts[mentionMembers*20 : (mentionMembers+1)*20]:
                                            dataMid.append(dataMention.mid)
                                            no += 1
                                            ret_ += "\n"+"╠•➣ {}. @!".format(str(no))
                                        ret_ += "\n╚══[ TEAM TERMUX 01 ]".format(str(len(dataMid)))
                                        cl.sendReplyMention(msg_id, to, ret_, dataMid)

                        elif cmd == "speed" or cmd == "sp":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               start = time.time()
                               cl.sendMessage(msg.to, "TEAM TERMUX 01")
                               elapsed_time = time.time() - start
                               sendFooter(msg.to, "{} %ꜱᴅᴇᴛɪᴋ".format(str(elapsed_time)))
                               

                        elif cmd.startswith("get-xxx "):
                          if msg._from in admin:
                            proses = text.split(" ")
                            urutan = text.replace(proses[0] + " ","")
                            count = urutan.split("|")
                            search = str(count[0])
                            r = requests.get("https://api.avgle.com/v1/search/{}/1?limit=10".format(str(search)))
                            data = json.loads(r.text)
                            if len(count) == 1:
                                no = 0
                                hasil = "「 Pencarian Video 18+ 」\n"
                                for aa in data["response"]["videos"]:
                                    no += 1
                                    hasil += "\n"+str(no)+". "+str(aa["title"])+"\nDurasi : "+str(aa["duration"])
                                    ret_ = "\n\nSelanjutnya Get-xxx {} | angka\nuntuk melihat detail video".format(str(search))
                                cl.sendText(msg.to,hasil+ret_)
                            elif len(count) == 2:
                                try:
                                    num = int(count[1])
                                    b = data["response"]["videos"][num - 1]
                                    c = str(b["vid"])
                                    d = requests.get("https://api.avgle.com/v1/video/"+str(c))
                                    data1 = json.loads(d.text)
                                    hasil = "Judul "+str(data1["response"]["video"]["title"])
                                    hasil += "\n\nDurasi : "+str(data1["response"]["video"]["duration"])
                                    hasil += "\nKualitas HD : "+str(data1["response"]["video"]["hd"])
                                    hasil += "\nDitonton "+str(data1["response"]["video"]["viewnumber"])
                                    e = requests.get("https://api-ssl.bitly.com/v3/shorten?access_token=c52a3ad85f0eeafbb55e680d0fb926a5c4cab823&longUrl="+str(data1["response"]["video"]["video_url"]))
                                    data2 = json.loads(e.text)
                                    hasil += "\nLink video : "+str(data1["response"]["video"]["video_url"])
                                    hasil += "\nLink embed : "+str(data1["response"]["video"]["embedded_url"])
                                    hasil += "\n\nKalau tidak bisa jangan lupa pakai vpn kesayangan anda"
                                    cl.sendText(msg.to,hasil)
                                    anuanu = str(data1["response"]["video"]["preview_url"])
                                    path = cl.downloadFileURL(anuanu)
                                    cl.sendImage(msg.to,path)
                                    cl.sendVideoWithURL(msg.to, data["data"]["url"])
                                except Exception as e:
                                    cl.sendText(msg.to," "+str(e))
                        
                        elif cmd.startswith("mp3: "):
                        #  if msg._from in admin:
                            try:
                                sep = msg.text.split(" ")
                                textToSearch = msg.text.replace(sep[0] + " ","")
                                query = urllib.parse.quote(textToSearch)
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                search_url="https://www.youtube.com/results?search_query="
                                mozhdr = {'User-Agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'}
                                sb_url = search_url + query
                                sb_get = requests.get(sb_url, headers = mozhdr)
                                soupeddata = BeautifulSoup(sb_get.content, "html.parser")
                                yt_links = soupeddata.find_all("a", class_ = "yt-uix-tile-link")
                                x = (yt_links[1])
                                yt_href =  x.get("href")
                                yt_href = yt_href.replace("watch?v=", "")
                                qx = "https://youtu.be" + str(yt_href)
                                vid = pafy.new(qx)
                                stream = vid.streams
                                best = vid.getbest()
                                best.resolution, best.extension
                                for s in stream:
                                    me = best.url
                                    hasil = ""
                                sendTextTemplate10(msg.to, "➥   ᴍᴜsɪᴋ ᴀᴜᴅɪᴏ")
                                cl.sendAudioWithURL(msg.to, me)
                            except Exception as e:
                                cl.sendMessage(msg.to,str(e))
                        elif cmd.startswith("clone "):
                           if msg._from in admin:
                             if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                for mention in mentionees:
                                    contact = mention["M"]
                                    break
                                try:
                                    cl.cloneContactProfile(contact)
                                    ryan = cl.getContact(contact)
                                    zx = ""
                                    zxc = ""
                                    zx2 = []
                                    xpesan =  "「 Clone Profile 」\nTarget nya "
                                    ret_ = "Berhasil clone profile target"
                                    ry = str(ryan.displayName)
                                    pesan = ''
                                    pesan2 = pesan+"@x \n"
                                    xlen = str(len(zxc)+len(xpesan))
                                    xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                    zx = {'S':xlen, 'E':xlen2, 'M':ryan.mid}
                                    zx2.append(zx)
                                    zxc += pesan2
                                    text = xpesan + zxc + ret_ + ""
                                    cl.sendMessage(to, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                                except:
                                    cl.sendMessage(msg.to, "Gagal clone profile")
                        elif text.lower() == 'restore':
                           if msg._from in admin:
                              try:
                                  clProfile.displayName = str(myProfile["displayName"])
                                  clProfile.statusMessage = str(myProfile["statusMessage"])
                                  clProfile.pictureStatus = str(myProfile["pictureStatus"])
                                  cl.updateProfileAttribute(8, clProfile.pictureStatus)
                                  cl.updateProfile(clProfile)
                                  cl.sendMessage(msg.to, sender, "「 Restore Profile 」\nNama ", " \nBerhasil restore profile")
                              except:
                                  cl.sendMessage(msg.to, "Gagal restore profile")
                           
                        elif cmd.startswith("smule "):
                          if msg._from in admin:
                            proses = text.split(" ")
                            urutan = text.replace(proses[0] + " ","")
                            count = urutan.split(" ")
                            search = str(count[0])
                            r = requests.get("https://www.smule.com/"+search+"/performances/json")
                            data = json.loads(r.text)
                            if len(count) == 1:
                                no = 0
                                ret_ = "╔══[➥   ʟɪsᴛsᴍᴜʟᴇ ➥  ]"
                                for aa in data["list"]:
                                    no += 1
                                    ret_ += "\n╠➥  " + str(no) + ". " + str(aa["title"])
                                ret_ += "\n╚══[➥   ʟɪsᴛsᴍᴜʟᴇ ➥  ]"
                                ret_ += "\nᴋᴇᴛɪᴋ: sᴍᴜʟᴇ{}ɴᴏᴍᴏʀ".format(str(search))
                                sendTextTemplate23(msg.to,ret_)
                            elif len(count) == 2:
                                try:
                                    num = int(count[1])
                                    b = data["list"][num - 1]
                                    smule = str(b["web_url"])
                                    c = "\n╠➥   ᴊᴜᴅᴜʟ ʟᴀɢᴜ: "+str(b["title"])
                                    c += "\n╠➥   ᴄʀᴇᴀᴛᴏʀ: "+str(b["owner"]["handle"])
                                    c += "\n╠➥   ʟɪᴋᴇ: "+str(b["stats"]["total_loves"])+" like"
                                    c += "\n╠➥   ᴄᴏᴍᴍᴇɴᴛ: "+str(b["stats"]["total_comments"])+" comment"
                                    c += "\n╠➥   sᴛᴀᴛᴜs ᴏᴄ: "+str(b["message"])
                                    c += "\n╠➥   ᴅɪ ᴅᴇɴɢᴀʀᴋᴀɴ: {}".format(b["stats"]["total_listens"])+" orang"
                                    c += "\n╚══[➥   ᴡᴀɪᴛ ᴀᴜᴅɪᴏ ᴏʀ ᴠɪᴅᴇᴏ ➥  ]"
                                    hasil = "╔══[➥   ᴅᴇᴛᴀɪʟsᴍᴜʟᴇ ➥  ]"+str(c)
                                    dl = str(b["cover_url"])
                                    data = {
                                        "type": "flex",
                                        "altText": "TEAM TERMUX 01",
                                        "contents": {
  "styles": {
    "body": {
      "backgroundColor": "#000000" #999999"
    },
    "footer": {
      "backgroundColor": "#0000ff" #2f2f4f" #0000" #cc9999"
    }
  },
  "type": "bubble",
  "size": "micro",
      "body": {
  "contents": [
      {
        "contents": [                   
            {            
            "type": "separator",
            "color": "#33ffff"            
      },
      {
        "type": "separator",
        "color": "#33ffff"      
      },
      {         
         "contents": [
          {   
          "type": "separator",
          "color": "#33ffff"
          },{
            "contents": [
              {
            "text": "TEAM TERMUX 01",
           "size": "xxs",
           "align": "center",
           "color": "#ffff00",
           "wrap": True,
           "weight": "bold",
           "type": "text"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#33ffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#33ffff"
         },
         {
       "contents": [         
              {
            "type": "separator",
            "color": "#33ffff"
 },
{
"type": "image",
            "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQtKJ9DZZjfaSZtDWapDmdO1bVccjThrGsrLARUW0ZVu2SqHTTI",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "http://line.me/ti/p/~linux.1",             
           }, 
            "flex": 1   
            },
            {
     "type": "separator",
           "color": "#33ffff"
           },
           {
            "contents": [
            {           
           "type": "separator",
           "color": "#33ffff"
           },
           {
            "type": "image",
            "url": dl, #"https://i.ibb.co/CntKh4x/20190525-152240.png", #smule
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "Https://smule.com/linux_aku",
            },         
            "flex": 1
}
],
   "type": "box",
   "spacing": "xs",
   "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#33ffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#33ffff"
         },
         {
"contents": [{"type":"separator","color": "#33ffff"},{"contents": [{"text": "🎙️ᴊᴇᴍᴘᴏʟ: "+str(b["stats"]["total_loves"])+" like","size": "xxs","color": "#00ff00","wrap": True,"weight": "bold","type": "text"},{"text": "🎙️ɴʏɪᴍᴀᴋ: {}".format(b["stats"]["total_listens"])+" orang","size": "xxs","color": "#00ff00","wrap": True,"weight": "bold","type": "text"},{"text": "🎙️ᴠᴏᴄᴀʟ: "+str(b["owner"]["handle"]),"size": "xxs","color": "#00ff00","wrap": True,"weight": "bold","type": "text"},{"text": "🎙️"+str(b["title"]),"size": "xxs","color": "#00ff00","wrap": True,"weight": "bold","type": "text"}],"type": "box","spacing": "xs","layout": "vertical"    
},{"type": "separator","color": "#33ffff"}],"type": "box","spacing": "xs","layout": "horizontal"   },{"type": "separator","color": "#33ffff"},{
"contents": [         
          {
            "type": "separator",
            "color": "#33ffff"
            },
             {
            "type": "image",
            "url": "https://i.ibb.co/XWQd8rj/20190625-201419.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "https://youtube.com"
            },
            "flex": 1
          },
          {
          "type": "image",
            "url": "https://i.ibb.co/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "http://line.me/ti/p/~linux.1",             
           }, 
            "flex": 1            
          },
          {
        "type": "image",
            "url": "https://i.ibb.co/kSMSnWn/20190427-191235.png", #camerahttps://i.ibb.co/hVWDsp8/20190428-232907.png", #smulehttps://i.ibb.co/8YfQVtr/20190427-185626.png", #callinghttps://kepriprov.go.id/assets/img/icon/phone.png", #phone
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/camera/"
          },
            "flex": 1
            },
          {
          "type": "image",
            "url": "https://i.ibb.co/CntKh4x/20190525-152240.png", #smule
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "Https://smule.com/linux_aku",
            },         
            "flex": 1          
          },
          {
          "type": "image",
            "url": "https://i.ibb.co/Wf8bQ2Z/20190625-105354.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/cameraRoll/multi"
            },
            "flex": 1
            },
            {
            "contents": [
            {
            "type": "image",
            "url": "https://i.ibb.co/1sGhJdC/20190428-232658.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/timeline"
            },
            "flex": 1
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#33ffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#33ffff"
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "xs",
    "layout": "vertical"
  }
}
}
                                    cl.postTemplate(to, data)
                                    with requests.session() as s:
                                        s.headers['user-agent'] = 'Mozilla/5.0'
                                        r = s.get("https://sing.salon/smule-downloader/?url=https://www.smule.com{}".format(urllib.parse.quote(smule)))
                                        data = BeautifulSoup(r.content, 'html5lib')
                                        get = data.select("a[href*=https://www.smule.com/redir?]")[0]
                                        title = data.findAll('h2')[0].text
                                        imag = data.select("img[src*=https://www.smule.com/redir?]")[0]
                                        if 'Smule.m4a' in get['download']:
                                            cl.sendAudioWithURL(msg.to, get['href'])
                                        else:
                                            cl.sendVideoWithURL(msg.to, get['href'])
                                except Exception as e:
                                    cl.sendMessage(msg.id,msg.to,"Result Error:\n"+str(e))


                          elif "https://www.smule.com" in msg.text.lower():
                           if wait["selfbot"] == True:
                                try:
                                    result = json.loads(requests.get("https://api.boteater.us/smule?url="+msg.text+"&auth="+"OGOivQx3TAG4 ").text)
                                    cl.sendAudioWithURL(to, result["result"]["download_link"])
                                    time.sleep(0.1)
                                    cl.sendVideoWithURL(to, result["result"]["download_link"])
                                except:pass
#===========COMEN PANGGILAN======
    #                    elif "https://www.smule.com" in msg.text.lower():
      #                      if wait["smule"] == True:
       #                          ZulMokoagow = r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
         #                       BossZul = re.findall(zulMokoagow, text)
              #                  EntogBot = []
         #                       for Ainx in BossZul:
             #                       if Ainx not in EntogBot:
              #                          EntogBot.append(Ainx)
            #                    for TeamBot in EntogBot:
            #                        AnakGadis = TeamBot
              #                      Apikey = "OGOivQx3TAG4"
              #                      headers = {
                #                        "apiKey":Apikey,
                #                        }
                #                    GadisDesah = json.loads(requests.get("https://api.be-team.me/smule?url="+AnakGadis,headers=headers).text)
                 #                   PerawanBasah="╭──「TEAM TERMUX 01」─────"
                  #                  PerawanBasah+="\n├♽   Song : " +GadisDesah["result"]["artist"]
                   #                 PerawanBasah+="\n├♽   Judul : " +GadisDesah["result"]["title"]
                     #               PerawanBasah+="\n├♽   ID Smule : " +GadisDesah["result"]["owner"]["handle"]
                     #               PerawanBasah+="\n├♽   Status :  " +GadisDesah["result"]["message"]
                      #              PerawanBasah+="\n╰──「♽ ᴄʀᴇᴀᴛᴏʀ: TEAM TERMUX 01 ʙᴏᴛꜱ ♽」─────"
                   #                 sendTextZul(msg.to, PerawanBasah)
                      #              cl.sendAudioWithURL(msg.to, GadisDesah["result"]["download_link"])
                         #           cl.sendVideoWithURL(msg.to, GadisDesah["result"]["download_link"])

                        elif text.lower() == "cek api":
                            if msg._from in admin:
                                try:
                                    headers = {"apiKey": "OGOivQx3TAG4"}
                                    main = json.loads(requests.get("https://api.be-team.me/apikey",headers=headers).text)
                                    a = "╭─[ ᴄᴇᴋ ᴀᴘɪᴋᴇʏ ]"
                                    a += "\n├♽  ᴇxᴘ: "+str(main["result"]["expired"])
                                    a += "\n├♽  ᴜꜱᴀɢᴇ: "+str(main["result"]["usage"])
                                    a += "\n├♽  ᴀᴄᴛɪᴠᴇ: "+str(main["result"]["isActive"])
                                    a += "\n├♽  ʟɪᴍɪᴛ: "+str(main["result"]["isLimit"])
                                    a += "\n├♽  ᴠɪᴘ: "+str(main["result"]["isVIP"])
                                    a += "\n╰[♽ ᴄʀᴇᴀᴛᴏʀ: TEAM TERMUX 01 ♽]"
                                    hasil = str(a)
                                    sendFooter(to, hasil)
                                except Exception as error:
                                    print (error)
                                                            
                                                          
                        elif cmd.startswith("spamtag: "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                proses = text.split(":")
                                strnum = text.replace(proses[0] + ":","")
                                num =  int(strnum)
                                Setmain["RAlimit"] = num
                                sendFooter2(msg.to,"「 Status Spamtag 」\nBerhasil diubah jadi {} kali".format(str(strnum)))
                                
                        elif cmd.startswith("spamtag "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                if 'MENTION' in msg.contentMetadata.keys()!=None:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    key1 = key["MENTIONEES"][0]["M"]
                                    zx = ""
                                    zxc = " "
                                    zx2 = []
                                    pesan2 = "@a"" "
                                    xlen = str(len(zxc))
                                    xlen2 = str(len(zxc)+len(pesan2)-1)
                                    zx = {'S':xlen, 'E':xlen2, 'M':key1}
                                    zx2.append(zx)
                                    zxc += pesan2
                                    msg.contentType = 0
                                    msg.text = zxc
                                    lol = {'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}
                                    msg.contentMetadata = lol
                                    jmlh = int(Setmain["RAlimit"])
                                    if jmlh <= 1000:
                                        for x in range(jmlh):
                                            try:
                                                cl.sendMessage1(msg)
                                            except Exception as e:
                                                cl.sendText(msg.to,str(e))
                                    else:
                                        cl.sendText(msg.to,"Jumlah melebihi 1000")
                                        
                        elif cmd == "kibar":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               cl.sendContact(to, mid)
                               cl.sendMessage(msg.to, "█░░╦─╦╔╗╦─╔╗╔╗╔╦╗╔╗░░█\n█░░║║║╠─║─║─║║║║║╠─░░█\n█░░╚╩╝╚╝╚╝╚╝╚╝╩─╩╚╝░░█\n"
 "ᴀꜱꜱᴀʟᴀᴍᴜᴀʟᴀɪᴋᴜᴍ\n"
"  ╭━Ⓔ✒Ⓝ✒Ⓣ✒Ⓞⓖ✒\n"
"  ╰╮┏━┳┳┓┏┳┳┓┏┳┳┳┓\n"
"  ┏┻╋━┻┻┫┣┻┻┫┣┻┻┻┫\n"
"  ┃HLO▪┃KMI DTANG LGI┃\n"
"  ┗Ⓑ┻┻ⓞ━━Ⓣ┻┻Ⓢ━╯\n"
"ᴜɴᴛᴜᴋ ᴍᴇɴɢɢᴜꜱᴜʀ\nʀᴏᴏᴍ ᴋᴀʟɪᴀɴ\n"
"..  (҂`_´)\n"
   " <,︻╦̵̵̿╤━ ҉     ~  •"
"█۞███████]▄▄▄▄▄▄▃●●\n"
"▂▄▅█████████▅▄▃▂…"
"[██████████████████]\n"
"◥⊙⊙▲⊙▲⊙▲⊙▲⊙▲⊙\n"
"╭━╮╭━╮\n"
"┃┃╰╯┃┃\n"
"┃╭╮╭╮┣┳━╮╭━━┳━━┳┳━╮\n"
"┃┃┃┃┃┣┫╭╮┫╭╮┃╭╮┣┫╭╯\n"
"┃┃┃┃┃┃┃┃┃┃╰╯┃╰╯┃┃┃\n"
"╰╯╰╯╰┻┻╯╰┻━╮┣━╮┣┻╯\n"
"╱╱╱╱╱╱╱╱╱╭━╯┣━╯┃\n"
"╱╱╱╱╱╱╱╱╱╰━━┻━━╯\n"
"🖕━━━━━━━━━━━━━🖕\n"
	"╔══╗╔═╗╔══╗╔═╦═╗\n"
	"╚╗╔╝║╦╝║╔╗║║║║║║\n"
	"━║║━║╩╗║╠╣║║║║║║\n"
	"━╚╝━╚═╝╚╝╚╝╚╩═╩╝\n"
"🖕━━━━━━━━━━━━━🖕\n"        
"TEAM TERMUX 01 ⓢⓟⓔⓔⓓ ⓑⓞⓣⓢ\n"
		"╔═╗╔══╗╔══╗╔══╗\n"
		"║╬║║╔╗║╚╗╔╝║╔╗║\n"
		"║╗╣║╠╣║━║║━║╠╣║\n"
		"╚╩╝╚╝╚╝━╚╝━╚╝╚╝\n"
		"━━━━━━━━━━━━━━━\n"
">>>Ⓕⓤⓒⓚ ⓐⓝⓙⓘⓝⓖ>><\nⓂⓨ ⓒⓡⓔⓐⓣⓞⓡ\n<<<<<<<<<>>\nhttp://line.me/ti/p/~linux.1\nhttp://line.me/ti/p/~linux.1")
                               cl.sendMessage(msg.to, None, contentMetadata={"STKID":"15996978","STKPKGID":"1416471","STKVER":"1"}, contentType=7)
                                         
                        elif cmd.startswith("spamcall: "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                proses = text.split(":")
                                strnum = text.replace(proses[0] + ":","")
                                num =  int(strnum)
                                wait["limit"] = num
                                sendFooter2(msg.to,"Total Spamcall Diubah Menjadi " +strnum)

                        elif msg.text.lower().startswith("naik "):
                          if msg._from in admin:
                           if 'MENTION' in msg.contentMetadata.keys()!= None:
                               names = re.findall(r'@(\w+)', text)
                               mention = eval(msg.contentMetadata['MENTION'])
                               mentionees = mention['MENTIONEES']
                               lists = []
                               for mention in mentionees:
                                   if mention["M"] not in lists:
                                       lists.append(mention["M"])
                               for ls in lists:
                                   contact = cl.getContact(ls)                          
                                   jmlh = int(wait["limit"])
                                   sendFooter2(msg.to, "Succes {} Call Grup".format(str(wait["limit"])))
                                   if jmlh <= 1000:
                                     for x in range(jmlh):
                                         try:
                                             mids = [contact.mid]
                                             cl.acquireGroupCallRoute(msg.to)
                                             cl.inviteIntoGroupCall(msg.to,mids)
                                         except Exception as e:
                                             cl.sendMessage(msg.to,str(e))
                                     else:
                                         sendFooter2(msg.to,"")

                        elif cmd == "spamcall":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                             if msg.toType == 2:
                                group = cl.getGroup(to)
                                members = [mem.mid for mem in group.members]
                                jmlh = int(wait["limit"])
                                sendFooter2(msg.to, "Sukses Call {} diGrup".format(str(wait["limit"])))
                                if jmlh <= 1000:
                                  for x in range(jmlh):
                                     try:
                                        call.acquireGroupCallRoute(to)
                                        call.inviteIntoGroupCall(to, contactIds=members)
                                     except Exception as e:
                                        cl.sendText(msg.to,str(e))
                                else:
                                    sendFooter2(msg.to,"Jumlah melebihi batas")
            
#================================================================
                        elif 'Welcome ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Welcome ','')
                              if spl == 'on':
                                  if msg.to in welcome:
                                       msgs = "Welcome Msg sudah aktif"
                                  else:
                                       welcome.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Welcome Msg diaktifkan\nDi Group : " +str(ginfo.name)
                                  sendFooter2(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in welcome:
                                         welcome.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Welcome Msg dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Welcome Msg sudah tidak aktif"
                                    sendFooter2(msg.to, "「Dinonaktifkan」\n" + msgs)

                        if text.lower() == "tagnote":
                            if msg._from in admin:
                                NoteCreate(to,cmd,msg)

                        elif ("tiup" in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in admin:
                                       try:
                                       	cl.kickoutFromGroup(msg.to,[target])
                                       except:
                                           sendFooter(msg.to,"➥ Maff Sayah Limit Kick Boss")
           
                        elif msg.text.lower().startswith("tagremot: "):
                            	separate = msg.text.split(":")
                            	number = msg.text.replace(separate[0] + ":"," ")
                            	groups = cl.getGroupIdsJoined()
                            	gid = groups[int(number)-1]                                                            
                            	group = cl.getGroup(gid)                                                            
                            	nama = [contact.mid for contact in group.members]
                            	k = len(nama)//19
                    	        for a in range(k+1):
                            		txt = u''
                    		        s=0
                            		b=[]
                            		for i in group.members[a*19 : (a+1)*19]:
                            			b.append(i.mid)
                            		RmentionMembers(gid, b)                            
                    		        sendFooter(msg.to, "Berhasil Mention Member di Group: \n " + str(group.name))
 #================================================================                                
                        elif cmd == "respon on" or text.lower() == 'respon on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention"] = True
                                wait["detectMention2"] = False
                                sendTextTemplate1(msg.to,"➥ Autorespon 1 ON")

                        elif cmd == "respon2 on" or text.lower() == 'respon2 on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention2"] = True
                                wait["detectMention"] = False
                                sendTextTemplate1(msg.to,"➥ Autorespon 2 ON")
#================================================================
                        elif cmd == "respon5 on" or text.lower() == 'respon5 on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention5"] = True
                                sendTextTemplate1(msg.to,"➥ Autorespon 5 ON")

                        elif cmd == "respon5 off" or text.lower() == 'respon5 off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention5"] = False
                                sendTextTemplate1(msg.to,"➥ Autorespon 5 OFF")          
#================================================================
                        elif cmd == "respon3 on" or text.lower() == 'respon3 on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention3"] = True
                                wait["detectMention"] = False
                                sendTextTemplate1(msg.to,"➥ Autorespon 3 ON")

                        elif cmd == "respon4 on" or text.lower() == 'respon4 on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention4"] = True
                                wait["detectMention"] = False
                                sendTextTemplate1(msg.to,"➥ Autorespon 4 ON")
#================================================================
                        elif cmd == "respon off" or text.lower() == 'respon off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention"] = False
                                sendTextTemplate1(msg.to,"➥ Autorespon 1 Off")

                        elif cmd == "respon3 off" or text.lower() == 'respon3 off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention3"] = False
                                sendTextTemplate1(msg.to,"➥ Autorespon 3 OFF")
#================================================================
                        elif cmd == "respon2 off" or text.lower() == 'respon2 off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention2"] = False
                                sendTextTemplate1(msg.to,"➥ Autorespon 2 Off")

                        elif cmd == "respon4 off" or text.lower() == 'respon4 OFF':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention4"] = False
                                sendTextTemplate1(msg.to,"❐ Autorespon 4 Off")
#================================================================
                        elif cmd == "notag on" or text.lower() == 'notag on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Mentionkick"] = True
                                sendTextTemplate1(msg.to,"➥  ᴀᴜᴛᴏ ᴋɪᴄᴋ ᴅɪᴀᴋᴛɪꜰᴋᴀɴ")

                        elif cmd == "notag off" or text.lower() == 'notag off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Mentionkick"] = False
                                sendTextTemplate1(msg.to,"➥  ᴀᴜᴛᴏ ᴋɪᴄᴋ ᴅɪɴᴏɴᴀᴋᴛɪꜰᴋᴀɴ")

                        elif cmd == "contact on" or text.lower() == 'contact on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["contact"] = True
                                sendTextTemplate1(msg.to,"➥  ꜱʜᴀʀᴇ ᴄᴏɴᴛᴀᴄᴛ ᴅɪᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        elif cmd == "contact off" or text.lower() == 'contact off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["contact"] = False
                                sendTextTemplate1(msg.to,"➥  ꜱʜᴀʀᴇ ᴄᴏɴᴛᴀᴄᴛ ᴅɪɴᴏɴᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        elif cmd == "autojoin on" or text.lower() == 'autojoin on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoin"] = True
                                sendTextTemplate1(msg.to,"➥  ᴀᴜᴛᴏᴊᴏɪɴ ᴅɪᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        elif cmd == "autojoin off" or text.lower() == 'autojoin off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoin"] = False
                                sendTextTemplate1(msg.to,"➥  ᴀᴜᴛᴏᴊᴏɪɴ ᴅɪɴᴏɴᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        elif cmd == "autoleave on" or text.lower() == 'autoleave on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoLeave"] = True
                                sendTextTemplate1(msg.to,"➥  ᴀᴜᴛᴏʟᴇᴀᴠᴇ ᴅɪᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        elif cmd == "autoleave off" or text.lower() == 'autoleave off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoLeave"] = False
                                sendTextTemplate1(msg.to,"➥  ᴀᴜᴛᴏʟᴇᴀᴠᴇ ᴅɪɴᴏɴᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        elif cmd == "autoadd on" or text.lower() == 'autoadd on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoAdd"] = True
                                sendTextTemplate1(msg.to,"➥  ᴀᴜᴛᴏᴀᴅᴅ ᴅɪᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        elif cmd == "autoadd off" or text.lower() == 'autoadd off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoAdd"] = False
                                sendTextTemplate1(msg.to,"➥  ᴀᴜᴛᴏᴀᴅᴅ ᴅɪɴᴏɴᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        elif cmd == "sticker on" or text.lower() == 'sticker on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["sticker"] = True
                                sendFooter(msg.to,"➥  sᴛɪᴄᴋᴇʀ ᴅɪᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        elif cmd == "sticker off" or text.lower() == 'sticker off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["sticker"] = False
                                sendTextTemplate1(msg.to,"➥  sᴛɪᴄᴋᴇʀ ᴅɪɴᴏɴᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        elif cmd == "jointicket on" or text.lower() == 'jointicket on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["autoJoinTicket"] = True
                                sendTextTemplate1(msg.to,"➥  ᴊᴏɪɴᴛɪᴄᴋᴇᴛ ᴅɪᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        elif cmd == "jointicket off" or text.lower() == 'jointicket off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["autoJoinTicket"] = False
                                sendTextTemplate1(msg.to,"➥  ᴊᴏɪɴᴛɪᴄᴋᴇᴛ ᴅɪɴᴏɴᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        elif cmd == "autoblock on" or text.lower() == 'autoblock on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoBlock"] = True
                                sendTextTemplate1(msg.to,"➥  ᴀᴜᴛᴏʙʟᴏᴄᴋ ᴅɪᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        elif cmd == "autoblock off" or text.lower() == 'autoblock off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoBlock"] = False
                                sendTextTemplate1(msg.to,"➥  ᴀᴜᴛᴏʙʟᴏᴄᴋ ᴅɪɴᴏɴᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        elif cmd == "post on" or text.lower() == 'post on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["checkPost"] = True
                                sendTextTemplate1(msg.to,"❐ ᴛɪᴍᴇʟɪɴᴇ ᴅɪᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        elif cmd == "post off" or text.lower() == 'post off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["checkPost"] = False
                                sendTextTemplate1(msg.to,"❐ ᴛɪᴍᴇʟɪɴᴇ ᴅɪɴᴏɴᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        elif cmd == "like on" or text.lower() == 'like on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["likeon"] = True
                                sendTextTemplate1(msg.to,"❐ ʟɪᴋᴇ ᴘᴏsᴛ ᴍᴏᴅᴇ ᴏɴ")
                                
                        elif cmd == "like off" or text.lower() == 'like off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["likeon"] = False
                                sendTextTemplate1(msg.to,"❐ ʟɪᴋᴇ ᴘᴏsᴛ ᴍᴏᴅᴇ ᴏғғ")
                                
                        elif cmd == "invite on" or text.lower() == 'invite on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["invite"] = True
                                sendTextTemplate1(msg.to, "❐ ᴋɪʀɪᴍ ᴋᴏɴᴛᴀᴋ'ɴʏᴀ")
                                
                        elif cmd == "invite off" or text.lower() == 'invite off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["invite"] = False
                                sendTextTemplate1(msg.to,"❐ ɪɴᴠɪᴛᴇ ᴠɪᴀ ᴄᴏɴᴛᴀᴄᴛ ᴏɴ")
                                                    
                           
                        if cmd == "unsend on":
                            if msg._from in admin:
                                wait["Unsend"] = True
                                sendTextTemplate1(msg.to, "❐ ᴜɴꜱᴇɴᴅ ᴅɪᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        if cmd == "unsend off":
                            if msg._from in admin:
                                wait["Unsend"] = False
                                sendTextTemplate1(msg.to, "❐ ᴜɴꜱᴇɴᴅ ᴅɪɴᴏɴᴀᴋᴛɪꜰᴋᴀɴ")
                                
                        elif "autoreject " in msg.text.lower():
                            xpesan = msg.text.lower()
                            xres = xpesan.replace("autoreject ","")
                            if xres == "off":
                                wait['autoReject'] = False
                                sendTextTemplate1(msg.to,"➥   Auto Reject already Off")
                            elif xres == "on":
                                wait['autoReject'] = True
                                sendFooter1(msg.to,"➥   Auto Reject already On")
                                
                        elif cmd == "autoread on":
                            if msg._from in admin:
                                if settings["autoRead"] == True:
                                    sendTextTemplate1(to, "❐ ᴀᴜᴛᴏʀᴇᴀᴅ ᴅɪᴀᴋᴛɪꜰᴋᴀɴ")
                                else:
                                    settings["autoRead"] = True
                                    sendTextTemplate1(to, "❐ ᴀᴜᴛᴏʀᴇᴀᴅ ᴅɪᴀᴋᴛɪꜰᴋᴀɴ")

                        elif cmd == "autoread off":
                            if msg._from in admin:
                                if settings["autoRead"] == False:
                                    sendTextTemplate1(to, "°❐ ᴀᴜᴛᴏʀᴇᴀᴅ ᴅɪɴᴏɴᴀᴋᴛɪꜰᴋᴀɴ")
                                else:
                                    settings["autoRead"] = False
                                    sendTextTemplate1(to, "❐ ᴀᴜᴛᴏʀᴇᴀᴅ ᴅɪɴᴏɴᴀᴋᴛɪꜰᴋᴀɴ")
#============================================================                                       
                        elif cmd.startswith("ytsearch: "):
                            if msg._from in admin:
                              #if Notif["YouTube"] == True:
                                try:
                                    x = text.split(" ")
                                    y = text.replace(x[0] + " ","")
                                    headers = {"apiKey": "B7BKKdWt4Lqd"}
                                    main = json.loads(requests.get("https://api.be-team.me/ytdl?search={}"+y,headers=headers).text)
                                    data = main["result"]
                                    a = ""+str(data["webpage_url"])
                                    cl.sendMessage(msg.to, a)
                                except Exception as error:
                                    cl.sendReplyMessage(msg.id, to, str(error))
                                    
                        elif cmd.startswith("spamtag "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                if 'MENTION' in msg.contentMetadata.keys()!=None:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    key1 = key["MENTIONEES"][0]["M"]
                                    zx = ""
                                    zxc = " "
                                    zx2 = []
                                    pesan2 = "@a"" "
                                    xlen = str(len(zxc))
                                    xlen2 = str(len(zxc)+len(pesan2)-1)
                                    zx = {'S':xlen, 'E':xlen2, 'M':key1}
                                    zx2.append(zx)
                                    zxc += pesan2
                                    msg.contentType = 0
                                    msg.text = zxc
                                    lol = {'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}
                                    msg.contentMetadata = lol
                                    jmlh = int(Setmain["ARlimit"])
                                    if jmlh <= 1000:
                                        for x in range(jmlh):
                                            try:
                                                cl.sendMessage1(msg)
                                            except Exception as e:
                                                cl.sendText(msg.to,str(e))
                                    else:
                                        cl.sendText(msg.to,"Jumlah melebihi 1000")                            
                    
                          elif cmd.startswith("jumlah: "):
                                if wait["selfbot"] == True:
                                  if msg._from in admin:
                                    proses = text.split(":")
                                    strnum = text.replace(proses[0] + ":","")
                                    num =  int(strnum)
                                    Setmain["ARlimit"] = num
                                    sendFooter1(msg.to,"Total Spamtag Diubah Menjadi " +strnum)

#===============================➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  
                        
                        elif ("Admin " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           admin.append(target)
                                           sendTextTemplate1(msg.to,"➥   ᴅᴏɴᴇ ᴀᴅᴅᴀᴅᴍɪɴ")
                                       except:
                                           pass
                        elif ("Staff " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           staff.append(target)
                                           sendFooter(msg.to,"➥   Telah Diangkat Menjadi Staff Bot")
                                       except:
                                           pass
                        elif ("Admindell " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Saints:
                                       try:
                                           admin.remove(target)
                                           sendFooter(msg.to,"➥   Telah Dihapus Menjadi Admin Bot")
                                       except:
                                           pass
                        elif ("Staffdell " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Saints:
                                       try:
                                           staff.remove(target)
                                           sendFooter(msg.to,"➥   Telah Dihapus Menjadi Staff Bot")
                                       except:
                                           pass
#===============================
                        elif ("Ban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           wait["blacklist"][target] = True
                                           sendFooter(msg.to,"➥   Berhasil menambahkan blacklist")
                                       except:
                                           pass
                                           
                        elif 'Protecturl ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protecturl ','')
                              if spl == 'on':
                                  if msg.to in protectqr:
                                       msgs = "⌬ Protect url sudah aktif"
                                  else:
                                       protectqr.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "⌬ Protect url diaktifkan\nDi Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectqr:
                                         protectqr.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Protect url dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "⌬ Protect url sudah tidak aktif"
                                    cl.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)

                        elif 'Protectkick ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protectkick ','')
                              if spl == 'on':
                                  if msg.to in protectkick:
                                       msgs = "⌬ Protect kick sudah aktif"
                                  else:
                                       protectkick.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "⌬ Protect kick diaktifkan\nDi Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectkick:
                                         protectkick.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "⌬Protect kick dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "⌬Protect kick sudah tidak aktif"
                                    cl.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)

                        elif 'Protectjoin ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protectjoin ','')
                              if spl == 'on':
                                  if msg.to in protectjoin:
                                       msgs = "⌬ Protect join sudah aktif"
                                  else:
                                       protectjoin.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "⌬ Protect join diaktifkan\nDi Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectjoin:
                                         protectjoin.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "⌬ Protect join dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "⌬ Protect join sudah tidak aktif"
                                    cl.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)

                        elif 'Protectcancel ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protectcancel ','')
                              if spl == 'on':
                                  if msg.to in protectcancel:
                                       msgs = "⌬ Protect cancel sudah aktif"
                                  else:
                                       protectcancel.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "⌬ Protect cancel diaktifkan\nDi Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectcancel:
                                         protectcancel.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "⌬Protect cancel dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "⌬Protect cancel sudah tidak aktif"
                                    cl.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)
                                    
                        elif 'Protectinvite ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protectinvite ','')
                              if spl == 'on':
                                  if msg.to in protectinvite:
                                       msgs = "⌬ Protect invite sudah aktif"
                                  else:
                                       protectinvite.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "⌬ Protect invite diaktifkan\nDi Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectinvite:
                                         protectinvite.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "⌬Protect invite dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "⌬Protect invite sudah tidak aktif"
                                    cl.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)                                                       
                                         
                        elif ("Unban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           del wait["blacklist"][target]
                                           sendFooter(msg.to,"➥   Berhasil menghapus blacklist")
                                       except:
                                           pass
                        elif cmd == "ban:on" or text.lower() == 'ban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["wblacklist"] = True
                                sendFooter(msg.to,"Kirim kontaknya...")
                        elif cmd == "unban:on" or text.lower() == 'unban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["dblacklist"] = True
                                sendFooter(msg.to,"Kirim kontaknya...")
                                
                        elif cmd.startswith("musik "):
                            if msg._from in admin:
                               sep = msg.text.split(" ")
                               query = msg.text.replace(sep[0] + " ","")
                               cond = query.split("-")
                               search = str(cond[0])
                               with requests.session() as web:
                                   web.headers["User-Agent"] = random.choice(settings["userAgent"])
                                   result = web.get("http://api.ntcorp.us/joox/search?q={}".format(str(search)))
                                   data = result.text
                                   data = json.loads(data)
                                   if len(cond) == 1:
                                      num = 0
                                      ret_ = "「 Pencarian Musik 」\n"
                                      for music in data["result"]:
                                          num += 1
                                          ret_ += "\n {}. {}".format(str(num), str(music["single"]))
                                      ret_ += "\n\n「 Total {} Pencarian 」".format(str(len(data["result"])))
                                      cl.sendMessage(to, str(ret_))
                                      sendMention(msg.to, msg._from,"","\nJika ingin menggunakan,\nSilahkan gunakan:\n\nMusik penyanyi-angka")
                                   if len(cond) == 2:
                                        num = int(cond[1])
                                        if num <= len(data["result"]):
                                               music = data["result"][num - 1]
                                               with requests.session() as web:
                                                    web.headers["User-Agent"] = random.choice(settings["userAgent"])
                                                    result = web.get("http://api.ntcorp.us/joox/song_info?sid={}".format(str(music["sid"])))
                                                    data = result.text
                                                    data = json.loads(data)
                                                    if data["result"] != []:
                                                         ret_ = "「 Pencarian Musik 」"
                                                         ret_ += "\n• Judul : {}".format(str(data["result"]["song"]))
                                                         ret_ += "\n• Album : {}".format(str(data["result"]["album"]))
                                                         ret_ += "\n• Ukuran : {}".format(str(data["result"]["size"]))
                                                         ret_ += " \n• Link Musik : {}".format(str(data["result"]["mp3"]))
                                                         ret_ += "\n「 Tunggu Musiknya Keluar 」"
                                                         cl.sendImageWithURL(to, str(data["result"]["img"]))
                                                         cl.sendMessage(to, str(ret_))
                                                         cl.sendAudioWithURL(to, str(data["result"]["mp3"][0]))

                        elif cmd == "bl" or text.lower() == 'banlist':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              tz = pytz.timezone("Asia/Jakarta")
                              timeNow = datetime.now(tz=tz)
                              if wait["blacklist"] == {}:
                                cl.sendMessage(msg.to,"Eweh Euy {}".format(cl.getContact("u6459106c8251205f79c2f037cd99b6a4").displayName))
                              else:
                                  mc = "🔰♻🔰ᴜsᴇ :\n                    TEAM TERMUX 01 V 1\n\n╭❍[🔰ʙʟᴀᴄᴋʟɪsᴛ ℬ❍tຮ͢⚓]❍─\n├────────────\n│• {}\n├────────────".format(str(cl.getGroup(msg.to).name))
                                  for mi_d in wait["blacklist"]:
                                      mc += "\n│• "+cl.getContact(mi_d).displayName
                                      md = "\n├────────\n├️ Total : 「%s」 ʙʟᴀᴄᴋʟɪsᴛ\n├────────" %(str(len(wait["blacklist"])))
                                  cl.sendMessage(msg.to,mc + md +"\n│• ᴛᴀɴɢɢᴀʟ : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\n│• ᴊᴀᴍ :"+ datetime.strftime(timeNow,'%H:%M:%S')+" WIB\n├────────────\n╰❍ ᴜsᴇʀ: {} ❍".format(cl.getContact("u6459106c8251205f79c2f037cd99b6a4").displayName))

                                        
                        elif cmd == "cb" or text.lower() == 'cban':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              ang = cl.getContacts(wait["blacklist"])
                              mc = " ❲%i❳ blacklist " % len(ang)
                              cl.sendMessage(msg.to,"╭─━══════════━─╮\n├✪➣ Musnah "+mc+"\n╰─━══════════━─╯")
                              wait["blacklist"] = {}
                                                   
#===============================
                        elif 'Set respon5: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set respon5: ','')
                              if spl in [""," ","\n",None]:
                                  sendFooter2(msg.to, "Gagal mengganti Respon Msg")
                              else:
                                  wait["Respontag5"] = spl
                                  sendFooter2(msg.to, "「Respon Msg」\nRespon Msg diganti jadi :\n\n「{}」".format(str(spl)))
                        elif 'Set welcome: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set welcome: ','')
                              if spl in [""," ","\n",None]:
                                  sendFooter2(msg.to, "Gagal mengganti Welcome Msg")
                              else:
                                  wait["welcome"] = spl
                                  sendFooter2(msg.to, "「Welcome Msg」\nWelcome Msg diganti jadi :\n\n「{}」".format(str(spl)))
                                  
                        elif 'Set mention: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set mention: ','')
                              if spl in [""," ","\n",None]:
                                  sendFooter2(msg.to, "Gagal mengganti Key mention all member")
                              else:
                                  wait["tagall"] = spl
                                  sendFooter2(msg.to, "➥  ᴋᴇʏ ᴍᴇɴᴛɪᴏɴ ᴍᴇᴍʙᴇʀ :\n\n{}".format(str(spl)))
                                                
                        elif 'Set autoleave: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set autoleave: ','')
                              if spl in [""," ","\n",None]:
                                  sendFooter2(msg.to, "Gagal mengganti Autoleave Msg")
                              else:
                                  wait["autoLave"] = spl
                                  sendFooter2(msg.to, "「Autoleave Msg」\nAutoleave Msg diganti jadi :\n\n「{}」".format(str(spl)))
                                  
                        elif 'Set respon: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set respon: ','')
                              if spl in [""," ","\n",None]:
                                  sendFooter2(msg.to, "Gagal mengganti Respon Msg")
                              else:
                                  wait["Respontag"] = spl
                                  sendFooter2(msg.to, "「Respon Msg」\nRespon Msg diganti jadi :\n\n「{}」".format(str(spl)))
                                  
                        elif 'Set respon3: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set respon3: ','')
                              if spl in [""," ","\n",None]:
                                  sendFooter2(msg.to, "Gagal mengganti Respon Msg")
                              else:
                                  wait["Respontag3"] = spl
                                  sendFooter2(msg.to, "「Respon Msg」\nRespon Msg diganti jadi :\n\n「{}」".format(str(spl)))
                        elif 'Set respon4: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set respon3: ','')
                              if spl in [""," ","\n",None]:
                                  sendFooter2(msg.to, "Gagal mengganti Respon Msg")
                              else:
                                  wait["Respontag4"] = spl
                                  sendFooter2(msg.to, "「Respon Msg」\nRespon Msg diganti jadi :\n\n「{}」".format(str(spl)))
                                  
                        elif 'Set respon2: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set respon2: ','')
                              if spl in [""," ","\n",None]:
                                  sendFooter2(msg.to, "Gagal mengganti Respon Msg")
                              else:
                                  wait["Respontag2"] = spl
                                  sendFooter2(msg.to, "「Respon Msg」\nRespon Msg diganti jadi :\n\n「{}」".format(str(spl)))
                        elif 'Set sider: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set sider: ','')
                              if spl in [""," ","\n",None]:
                                  sendFooter2(msg.to, "Gagal mengganti Sider Msg")
                              else:
                                  wait["mention"] = spl
                                  sendFooter2(msg.to, "「Sider Msg」\nSider Msg diganti jadi :\n\n「{}」".format(str(spl)))
                        elif 'Set byepass: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set byepass: ','')
                              if spl in [""," ","\n",None]:
                                  sendFooter1(msg.to, "Gagal mengganti Key ʙʏᴇᴘᴀꜱꜱ")
                              else:
                                  wait["dagor"] = spl
                                  sendFooter1(msg.to, "ᴋᴇʏ ʙʏᴇᴘᴀꜱꜱ :\n\n{}".format(str(spl)))
                        elif text.lower() == "cek welcome":
                            if msg._from in admin:
                               sendFooter1(msg.to, "「Welcome Msg」\nWelcome Msg mu :\n\n「 " + str(wait["welcome"]) + " 」")
                        elif text.lower() == "cek leave":
                            if msg._from in admin:
                               sendFooter1(msg.to, "「Autoleave Msg」\nAutoleave Msg mu :\n\n「 " + str(wait["autoleave"]) + " 」")
                        elif text.lower() == "cek respon":
                            if msg._from in admin:
                               sendFooter1(msg.to, "「Respon Msg」\nRespon Msg mu :\n\n「 " + str(wait["Respontag"]) + " 」")
                        elif text.lower() == "cek respon2":
                            if msg._from in admin:
                               sendFooter1(msg.to, "「Respon Msg」\nRespon Msg mu :\n\n「 " + str(wait["Respontag2"]) + " 」")
                        elif text.lower() == "cek respon3":
                            if msg._from in admin:
                               sendFooter1(msg.to, "「Respon Msg」\nRespon Msg mu :\n\n「 " + str(wait["Respontag3"]) + " 」")
                        elif text.lower() == "cek respon4":
                            if msg._from in admin:
                               sendFooter1(msg.to, "「Respon Msg」\nRespon Msg mu :\n\n「 " + str(wait["Respontag4"]) + " 」")
                        elif text.lower() == "cek mention":
                            if msg._from in admin:
                               sendFooter(msg.to, "ꜱᴇᴛ ᴍᴇɴᴛɪᴏɴ ᴋᴇʏ:\n\n" + str(wait["tagall"])) 
#===============================➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  ➥  
                        elif "youtube" in msg.text.lower():
                          if msg._from in admin:
                            try:
                                sep = msg.text.split(" ")
                                textToSearch = msg.text.replace(sep[0] + " ","")
                                query = urllib.parse.quote(textToSearch)
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                cover = cl.getProfileCoverURL(mid)
                                search_url="https://www.youtube.com/results?search_query="
                                mozhdr = {'User-Agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'}
                                sb_url = search_url + query
                                sb_get = requests.get(sb_url, headers = mozhdr)
                                soupeddata = BeautifulSoup(sb_get.content, "html.parser")
                                yt_links = soupeddata.find_all("a", class_ = "yt-uix-tile-link")
                                x = (yt_links[1])
                                yt_href =  x.get("href")
                                yt_href = yt_href.replace("watch?v=", "")
                                qx = "https://youtu.be" + str(yt_href)
                                vid = pafy.new(qx)
                                stream = vid.streams
                                best = vid.getbest()
                                best.resolution, best.extension
                                for s in stream:
                                    me = best.url
                                    data = {
                                "type": "flex",
                                "altText": "TEAM TERMUX 01",
                                "contents": {
"type": "carousel",
"contents": [
{
"type": "bubble",
"size": "nano",
"body": {
"backgroundColor": "#00ff00",
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "image", #Wall 1
"url": "https://content.skyscnr.com/m/7d3992c451e6cf6c/original/color.gif?imbypass=true",
"size": "full",
"aspectMode": "cover",
"aspectRatio": "4:5",
"gravity": "bottom",
"action": {
"uri": "line://nv/profilePopup/mid=u6459106c8251205f79c2f037cd99b6a4",
"type": "uri",
}
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "image", #Wall 2
"url": "https://content.skyscnr.com/m/7d3992c451e6cf6c/original/color.gif?imbypass=true",
"gravity": "bottom",
"size": "xxl",
"aspectMode": "cover",
"aspectRatio": "2:3",
"offsetTop": "0px",
"action": {
"uri": "line://nv/profilePopup/mid=u6459106c8251205f79c2f037cd99b6a4",
"type": "uri",
}
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "5px",
"offsetStart": "5px",
"height": "140px",
"width": "110px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "image", #Wall 2
"url": cover, #"https://obs.line-scdn.net/{}".format(cl.getContact(sender).pictureStatus),
"gravity": "bottom",
"size": "xxl",
"aspectMode": "cover",
"aspectRatio": "2:3",
"offsetTop": "0px",
"action": {
"uri": "line://nv/profilePopup/mid=u6459106c8251205f79c2f037cd99b6a4",
"type": "uri",
}
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "5px",
"offsetStart": "5px",
"height": "140px",
"width": "110px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "image", #Wall 2
"url": "https://obs.line-scdn.net/{}".format(cl.getContact(sender).pictureStatus),
"gravity": "bottom",
"size": "xxl",
"aspectMode": "cover",
"aspectRatio": "2:3",
"offsetTop": "0px",
"action": {
"uri": "line://nv/profilePopup/mid=u6459106c8251205f79c2f037cd99b6a4",
"type": "uri",
}
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "5px",
"offsetStart": "5px",
"height": "140px",
"width": "110px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": "ʏᴏuᴛᴜʙᴇ",
"align": "center",
"color": "#000000",
"weight": "bold",
"size": "xxs",
"weight": "bold",
"offsetTop": "1px"
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "7px",
"backgroundColor": "#ffd700",
"offsetStart": "7px",
"height": "15px",
"width": "45px"
},
{
"type": "box",
"layout": "vertical",
"contents": [ #====================================================== 
{
"type": "image",
"url": "https://thumbs.gfycat.com/DependentSleepyHusky-size_restricted.gif",
#======================================================  
"size": "xxl",
"action": {
"type": "uri",
"uri": "https://wa.me/+6285757076639",
},         
"flex": 0
}
],
"position": "absolute",
"offsetTop": "5px",
"offsetStart": "92px",
"height": "43px",
"width": "22px"
},
{
"type": "box",
"layout": "vertical",
"contents": [ #dsini
{
"type": "image",
"url": "https://thumbs.gfycat.com/DependentSleepyHusky-size_restricted.gif",
#====================================================== 
"size": "xxl",
"action": {
"type": "uri",
"uri": "https://youtube.com",
},         
"flex": 0
}
],
"position": "absolute",
"offsetTop": "5px",
"offsetStart": "67px",
"height": "43px",
"width": "22px"
},
{
"type": "box",
"layout": "vertical",
"contents": [ #======================================================  
{
"type": "image",
"url": "https://i.ibb.co/CntKh4x/20190525-152240.png", #smule
"size": "xl",
"action": {
"type": "uri",
"uri": "Https://smule.com/KSS_OFFICE",
},
"flex": 0
},{
"type": "image",
"url": "https://i.ibb.co/ZHtFDts/20190427-185307.png",
"size": "xl",
"action": {
"type": "uri",
"uri": "line://nv/chat",
},
"flex": 0
},{
"type": "image",
"url": "https://i.ibb.co/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
"size": "full",
"action": {
"type": "uri",
"uri": "http://line.me/ti/p/~linux.1",
},
"flex": 0
},{
"type": "image",
"url": "https://i.ibb.co/1sGhJdC/20190428-232658.png",
"size": "xl",
"action": {
"type": "uri",
"uri": "line://nv/timeline"
},
"flex": 0
}
],
"position": "absolute",
"offsetTop": "25px",
"offsetStart": "5px",
"height": "180px",
"width": "25px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": "➥   "+ datetime.strftime(timeNow,'%H:%M:%S'),
"weight": "bold",
"color": "#ffffff",
#"align": "center",
"size": "xxs",
"offsetTop": "0px"
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "98px",
"backgroundColor": "#ff0000",
"offsetStart": "50px",
"height": "16px",
"width": "63px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": "🎙️" + str(vid.author),
"weight": "bold",
"color": "#ffffff",
"size": "xxs",
"offsetTop": "0px"
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "115px",
"backgroundColor": "#0000ff",
"offsetStart": "33px",
"height": "16px",
"width": "80px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": "TEAM TERMUX 01",
"weight": "bold",
"color": "#00ff00",
"size": "xxs",
"offsetTop": "0px"
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "130px",
#===================================================== 
"offsetStart": "8px",
"height": "50px",
"width": "110px"
}
],
#======================================================
"paddingAll": "0px"
}
},
]
}
}
                                cl.postTemplate(to, data)
                                cl.sendVideoWithURL(msg.to, me)
                            except Exception as e:
                                cl.sendMessage(msg.to,str(e))

                        elif "yutube" in msg.text.lower():
                          if msg._from in admin:
                            try:
                                sep = msg.text.split(" ")
                                textToSearch = msg.text.replace(sep[0] + " ","")
                                query = urllib.parse.quote(textToSearch)
                                search_url="https://www.youtube.com/results?search_query="
                                mozhdr = {'User-Agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'}
                                sb_url = search_url + query
                                sb_get = requests.get(sb_url, headers = mozhdr)
                                soupeddata = BeautifulSoup(sb_get.content, "html.parser")
                                yt_links = soupeddata.find_all("a", class_ = "yt-uix-tile-link")
                                x = (yt_links[1])
                                yt_href =  x.get("href")
                                yt_href = yt_href.replace("watch?v=", "")
                                qx = "https://youtu.be" + str(yt_href)
                                vid = pafy.new(qx)
                                stream = vid.streams
                                best = vid.getbest()
                                best.resolution, best.extension
                                for s in stream:
                                    me = best.url
                                    data = {
                                        "type": "flex",
                                        "altText": "TEAM TERMUX 01",
                                        "contents": {
  "styles": {
    "body": {
      "backgroundColor": "#800000"
    },
    "footer": {
      "backgroundColor": "#800000"
    }
  },
  "type": "bubble",
 "size": "micro",
      "body": {
  "contents": [
      {
        "contents": [                   
            {            
            "type": "separator",
            "color": "#FFFFFF"            
      },
      {
        "type": "separator",
        "color": "#FFFFFF"  
      },
      {         
         "contents": [
          {
          "type": "separator",
          "color": "#FFFFFF"   
      },
      {
            "contents": [
              {
              "type": "image",
     "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
          },{
 "type": "text",
"text": "TEAM TERMUX 01",
"weight": "bold",
"color": "#FFFFFF",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "ɬɛąɱ",
"weight": "bold",
"color": "#FFFFFF",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "ცơɬʂ ☬",
"weight": "bold",
"color": "#FFFFFF",
"size": "xxs",
"flex": 0
      },
      {
    "type": "image",
     "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#33ffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#33ffff"
         },
         {
       "contents": [
         {
        "type": "separator",
        "color": "#FFFFFF"
         },
         {
            "text": "🎙🎙🎙",
            "size": "xxs",
            "color": "#FF9900",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#33ffff"
           },
             {
            "text": "🎙🎙🎙",
            "size": "xxs",
            "color": "#FF9900",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#33ffff"
           },
             {
            "text": "🎙🎙🎙",
            "size": "xxs",
            "color": "#FFFFFF",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"   
            },
         {
        "type": "separator",
        "color": "#33ffff"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#33ffff"
         },
         {
       "contents": [
          {
           "type": "separator",
           "color": "#33ffff"
          },
          {
          "type": "image",
            "url": "https://thumbs.gfycat.com/DependentSleepyHusky-max-1mb.gif", 
            "size": "xxs",
            "action": {
            "type": "uri",
            "uri": "https://youtube.com",
          },
            "flex": 0
          },
          {
        "type": "separator",
        "color": "#FFFFFF"
      },
      {      
       "contents": [              
          {
"type": "text",
"text": "TEAM TERMUX 01",
"weight": "bold",
"color": "#FFFFFF",
"align": "center",
"size": "xxs",
"flex": 0
},{
"type": "separator",
"color": "#FFFFFF"
},{
"type": "text",
"text": "➥   "+ str(vid.duration),
"weight": "bold",
"color": "#FFFFFF",
#"align": "center",
"size": "xxs",
"flex": 0
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"
      },
      {
        "type": "separator",
        "color": "#FFFFFF"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"
      },
      {
        "type": "separator",
         "color": "#FFFFFF"
       },
       {     
       "contents": [           
         { 
           "type": "separator",
           "color": "#FFFFFF"
            },
           {
            "contents": [
              {
              "type": "separator",
           "color": "#FFFFFF"
            },
           {
          "type": "text",
"text": "voc:" + str(vid.author),
"weight": "bold",
"color": "#FFFFFF",
"align": "center",
"size": "xxs",
"flex": 0
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#FFFFFF"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#FFFFFF"
         },
         {          
         "contents": [
         { 
           "type": "separator",
           "color": "#FFFFFF"
            },
           {
            "contents": [
              {
              "type": "separator",
           "color": "#FFFFFF"
            },
           {
          "text": "🎙ᴊᴜᴅᴜʟ🎙\n " + vid.title + " ",
           "size": "xxs",
          "align": "center",
           "color": "#FFFFFF",
           "wrap": True,
           "weight": "bold",
           "type": "text"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#FFFFFF"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#FFFFFF"
         },
         {
       "contents": [
         {
        "type": "separator",
        "color": "#FFFFFF"
         },
         {
            "text": "👨‍💻👨‍💻👨‍💻",
            "size": "xxs",
            "color": "#FF9900",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#33ffff"
           },
             {
            "text": "👨‍💻👨‍💻👨‍💻",
            "size": "xxs",
            "color": "#FF9900",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#33ffff"
           },
             {
            "text": "👨‍💻👨‍💻👨‍💻",
            "size": "xxs",
            "color": "#FF9900",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"   
          },
         {
        "type": "separator",
        "color": "#FFFFFF"
         }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#FFFFFF"
         },
         {
      "contents": [
          {
            "type": "separator",
            "color": "#33ffff"
            },
             {
            "type": "image",
            "url": "https://i.ibb.co/XWQd8rj/20190625-201419.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "https://youtube.com",
           }, 
            "flex": 1
          },
          {
          "type": "image",
            "url": "https://i.ibb.co/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "http://line.me/ti/p/~linux.1",             
           }, 
            "flex": 1            
          },
          {
          "type": "image",
            "url": "https://i.ibb.co/ZHtFDts/20190427-185307.png", #chathttps://i.ibb.co/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/chat" #"http://line.me/ti/p/~linux.1",
            },         
            "flex": 1          
            },
          {
          "type": "image",
            "url": "https://i.ibb.co/CntKh4x/20190525-152240.png", #smule
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "Https://smule.com/KSS_OFFICE",
            },         
            "flex": 1          
          },
          {
          "type": "image",
            "url": "https://i.ibb.co/Wf8bQ2Z/20190625-105354.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/cameraRoll/multi"
            },
            "flex": 1
            },
            {
            "contents": [
            {
            "type": "image",
            "url": "https://i.ibb.co/1sGhJdC/20190428-232658.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/timeline"
          },
            "flex": 1           
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#FFFFFF"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#FFFFFF"
        },{
        "contents": [         
              {
            "type": "separator",
            "color": "#FFFFFF"
            },
             {          
            "contents": [
               {
    "type": "image",
    "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
    },{
 "type": "text",
"text": "TEAM TERMUX 01",
"weight": "bold",
"color": "#FFFFFF",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "ɬɛąɱ",
"weight": "bold",
"color": "#FFFFFF",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "ცơɬʂ ☬",
"weight": "bold",
"color": "#FFFFFF",
"size": "xxs",
"flex": 0
      },
      {
    "type": "image",
    "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#FFFFFF"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#FFFFFF"     
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "xs",
    "layout": "vertical"
  }
}
}
                                cl.postTemplate(to, data)
                                cl.sendVideoWithURL(msg.to, me)
                            except Exception as e:
                                cl.sendMessage(msg.to,str(e))


#==============================================================
                        
                        elif cmd == "mempict":
                              if msg._from in admin:
                                  kontak = cl.getGroup(to)
                                  group = kontak.members
                                  picall = []
                                  for ids in group:
                                    if len(picall) >= 400:
                                      pass
                                    else:
                                      picall.append({
                                        "imageUrl": "https://os.line.naver.jp/os/p/{}".format(ids.mid),
                                        "action": {
                                          "type": "uri",
                                          "uri": "http://line.me/ti/p/~linux.1"
                                          }
                                        }
                                      )
                                  k = len(picall)//10
                                  for aa in range(k+1):
                                    data = {
                                      "type": "template",
                                      "altText": "{} membagikan janda".format(cl.getProfile().displayName),
                                      "template": {
                                        "type": "image_carousel",
                                        "columns": picall[aa*10 : (aa+1)*10]
                                      }
                                    }
                                    cl.postTemplate(to, data)

#======================================================================
                        elif "/ti/g/" in msg.text.lower():
                          #if wait["selfbot"] == True:
                            #if msg._from in admin or msg._from in owner:
                              if settings["autoJoinTicket"] == True:
                                 link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                                 links = link_re.findall(text)
                                 n_links = []
                                 for l in links:
                                     if l not in n_links:
                                        n_links.append(l)
                                 for ticket_id in n_links:
                                     group = cl.findGroupByTicket(ticket_id)
                                     cl.acceptGroupInvitationByTicket(group.id,ticket_id)
                                     sendFooter2(msg.to, "➥  ᴛᴇʟᴀʜ ʙᴇʀʜᴀꜱɪʟ ᴍᴀꜱᴜᴋ ᴋᴇ ɢʀᴜᴘ : %s" % str(group.name))
#======================================================================
                        elif text.lower() == "cek":
                            if msg._from in admin:
                               try:cl.inviteIntoGroup(to, ["u6459106c8251205f79c2f037cd99b6a4"]);has = "OK"
                               except:has = "NOT"
                               try:cl.kickoutFromGroup(to, ["u6459106c8251205f79c2f037cd99b6a4"]);has1 = "OK"
                               except:has1 = "NOT"
                               if has == "OK":sil = "☬ ɴᴏʀᴍᴀʟ ✅"
                               else:sil = "☬ ʟɪᴍɪᴛ ❎"
                               if has1 == "OK":sil1 = "☬ ɴᴏʀᴍᴀʟ ✅"
                               else:sil1 = "☬ ʟɪᴍɪᴛ ❎"
                               sendFooter(to, "☬ ᴋɪᴄᴋ: {} \n☬ ɪɴᴠɪᴛᴇ: {}".format(sil1,sil))
#=====================================================================
                        elif cmd.startswith("addmp3 "):
                            if msg._from in admin:
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                name = name.lower()
                                if name not in audios:
                                    settings["Addaudio"]["status"] = True
                                    settings["Addaudio"]["name"] = str(name.lower())
                                    audios[str(name.lower())] = ""
                                    f = codecs.open("audio.json","w","utf-8")
                                    json.dump(audios, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    sendFooter(msg.to,"Silahkan kirim mp3 nya...") 
                                else:
                                    sendFooter(msg.to, "Mp3 itu sudah dalam list") 
                                
                        elif cmd.startswith("dellmp3 "):
                            if msg._from in admin:
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                name = name.lower()
                                if name in audios:
                                    cl.deleteFile(audios[str(name.lower())])
                                    del audios[str(name.lower())]
                                    f = codecs.open("audio.json","w","utf-8")
                                    json.dump(audios, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    sendFooter(msg.to, "Done hapus mp3 {}".format( str(name.lower())))
                                else:
                                    sendFooter(msg.to, "Mp3 itu tidak ada dalam list") 
                                 
                        elif cmd == "listmp3":
                            if msg._from in admin:
                                no = 0
                                ret_ = "╔═══❲ My Music ❳════\n"
                                for audio in audios:
                                    ret_ += "┣➥   " + audio.title() + "\n"
                                ret_ += "╚═══❲ {} Record  ❳════".format(str(len(audios)))
                                sendFooter(to, ret_)

                        elif cmd.startswith("addsticker "):
                            if msg._from in admin:
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                name = name.lower()
                                if name not in stickers:
                                    settings["Addsticker"]["status"] = True
                                    settings["Addsticker"]["name"] = str(name.lower())
                                    stickers[str(name.lower())] = ""
                                    f = codecs.open("Sticker.json","w","utf-8")
                                    json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    sendFooter(to, "➥   Silahkan Kirim Sricker Nyah Yah") 
                                else:
                                    sendFooter(to, "➥   Sticker itu sudah dalam List") 
                                
                        elif cmd.startswith("dellsticker "):
                            if msg._from in admin:
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                name = name.lower()
                                if name in stickers:
                                    del stickers[str(name.lower())]
                                    f = codecs.open("sticker.json","w","utf-8")
                                    json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    sendFooter(to, "➥   Berhasil menghapus sticker {}".format( str(name.lower())))
                                else:
                                    sendFooter(to, "➥   Sticker ada di list") 
                                                   
                        elif cmd == "liststicker":
                            if msg._from in admin:
                                no = 0
                                ret_ = "╔═══❲ My Sticker ❳════\n"
                                for sticker in stickers:
                                    ret_ += "┣➥    " + sticker.title() + "\n"
                                ret_ += "╚═══❲  {} Stickers  ❳════".format(str(len(stickers)))
                                sendFooter(to, ret_)

                        elif cmd.startswith("addimg "):
                            if msg._from in admin:
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                name = name.lower()
                                if name not in images:
                                    settings["Addimage"]["status"] = True
                                    settings["Addimage"]["name"] = str(name.lower())
                                    images[str(name.lower())] = ""
                                    f = codecs.open("image.json","w","utf-8")
                                    json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    sendFooter(to, "Silahkan kirim fotonya")
                                else:
                                    sendFooter(to, "Foto Udah dalam list")

                        elif cmd.startswith("dellimg "):
                            if msg._from in admin:
                               sep = text.split(" ")
                               name = text.replace(sep[0] + " ","")
                               name = name.lower()
                               if name in images:
                                   cl.deleteFile(images[str(name.lower())])
                                   del images[str(name.lower())]
                                   f = codecs.open("image.json","w","utf-8")
                                   json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                                   sendFooter(to, "Berhasil menghapus {}".format( str(name.lower())))
                               else:
                                   sendFooter(to, "Foto ada dalam list")

                        elif cmd == "listimage":
                            if msg._from in admin:
                                no = 0
                                ret_ = "╭───「 Daftar Image 」\n"
                                for audio in audios:
                                    no += 1
                                    ret_ += str("├≽") + " " + audio.title() + "\n"
                                ret_ += "╰───「 Total {} Image 」".format(str(len(audios)))
                                sendFooter(to, ret_)
#===== [ ꜱᴜᴘᴘᴏʀᴛ ʙʏᴇ ᴛᴇᴀᴍ TEAM TERMUX 01
                        elif cmd.startswith("addvideo"):
                            if msg._from in admin:
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                name = name.lower()
                                if name not in images:
                                    settings["Addvideo"]["status"] = True
                                    settings["Addvideo"]["name"] = str(name.lower())
                                    images[str(name.lower())] = ""
                                    f = codecs.open("video.json","w","utf-8")
                                    json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    sendFooter(to, "Silahkan kirim video nya...")
                                else:
                                    sendFooter(to, "video sudah ada")
                        elif cmd.startswith("dellvideo "):
                            if msg._from in admin:
                               sep = text.split(" ")
                               name = text.replace(sep[0] + " ","")
                               name = name.lower()
                               if name in images:
                                   cl.deleteFile(images[str(name.lower())])
                                   del images[str(name.lower())]
                                   f = codecs.open("video.json","w","utf-8")
                                   json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                                   sendFooter(to, "Berhasil menghapus {}".format( str(name.lower())))
                               else:
                                   sendFooter(to, "video tidak ada")

                        elif cmd == "listvideo":
                            if msg._from in admin:
                                no = 0
                                ret_ = "╭───「 Daftar Video 」\n"
                                for audio in audios:
                                    no += 1
                                    ret_ += str("├≽") + " " + audio.title() + "\n"
                                ret_ += "╰───「 Total {} Video 」".format(str(len(audios)))
                                sendFooter(to, ret_)
    except Exception as error:
        print (error)


while True:
    try:
        ops = oepoll.singleTrace(count=50)
        if ops is not None:
            for op in ops:
                bot(op)
                # Don't remove this line, if you wan't get error soon!
                oepoll.setRevision(op.revision)
    except Exception as e:
    	logError(e)                      
